// 运行在页面主世界：记录页面请求的认证头，并复用页面自身的 fetch 下载文件
// 识别规则统一来自 scope.js（与 content.js / background.js 共用）
const S = (typeof globalThis !== "undefined" && globalThis.CDScope) || null;

// 当前框架是否处于课程学习页面上下文（跨域预览框靠 ancestorOrigins 判定）
function cdIsLearningHere() {
  if (!S) return false;
  let ao = [];
  let referrer = "";
  try { ao = Array.prototype.slice.call(location.ancestorOrigins || []); } catch (e) {}
  try { referrer = document.referrer || ""; } catch (e) {}
  return S.isLearningPage(location.href, ao, referrer, cdExtraHosts);
}

// 捕获范围设置（与后台/设置页/内容脚本共用同一组键）
// 注意：主世界没有 chrome.* API，故由内容脚本转发过来（见 CD_SETTINGS 消息）
let cdCaptureScoped = true;
let cdExtraHosts = "";
let cdStrict = true;
window.addEventListener("message", function (e) {
  if (e.source !== window || !e.data || e.data.type !== "CD_SETTINGS") return;
  const d = e.data;
  cdCaptureScoped = d.captureScoped !== false;
  cdExtraHosts = d.extraHosts || "";
  cdStrict = d.strictCapture !== false;
});

// 判定当前框架可捕获（供主世界各处捕获点统一调用）
function cdMayCapture() {
  if (!S) return false;
  return cdCaptureScoped ? cdIsLearningHere() : true;
}

const headerStore = new Map(); // url -> headers 对象
const MAX_STORE = 200;

function recordHeaders(url, headers) {
  if (!url || !headers) return;
  try {
    headerStore.set(url, headers);
    // 同时按去掉查询串的 key 记录，便于匹配
    const base = url.split("?")[0];
    if (base !== url) headerStore.set(base, headers);
    if (headerStore.size > MAX_STORE * 2) {
      headerStore.delete(headerStore.keys().next().value);
    }
    // 小雅 API 的最近请求头（主动拉取时复用其认证）
    if (/whut\.ai-augmented\.com\/api\//.test(url)) lastApiHeaders = headers;
  } catch (e) {}
}
let lastApiHeaders = {};

// 从原始文本提取 fileId → 名字（保精度）
function pairsFromText(text) {
  const pairs = new Map();
  const idRe = /"(?:fileId|resource_id|resourceId|file_id|materialId|attachId)"\s*:\s*"?(\d{10,})"?/gi;
  let m;
  while ((m = idRe.exec(text)) !== null) {
    const id = m[1];
    if (pairs.has(id)) continue;
    const w = text.slice(Math.max(0, m.index - 500), m.index + id.length + 500);
    const nRe = /"([^"]{0,40}(?:fileName|resourceName|name|title)[^"]{0,40})"\s*:\s*"([^"]{1,150})"/gi;
    let n;
    while ((n = nRe.exec(w)) !== null) {
      if (n[2] && !/^\d+$/.test(n[2])) { pairs.set(id, n[2]); break; }
    }
  }
  return pairs;
}

// 页面主世界带认证头重放小雅接口：拿资源名 + 真实下载地址
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function xyReplay(urls) {
  // 等页面自己发出 API 请求、认证头被记录（最多 8 秒）
  for (let i = 0; i < 27 && !Object.keys(lastApiHeaders).length; i++) await sleep(300);
  for (const u of urls) {
    try {
      let headers = headerStore.get(u) || headerStore.get(u.split("?")[0]) || lastApiHeaders || {};
      let r = await origFetch(u, { credentials: "include", headers });
      // 认证头可能还没就绪，401 时等 1.5 秒重试一次
      if (r.status === 401) {
        await sleep(1500);
        headers = headerStore.get(u) || headerStore.get(u.split("?")[0]) || lastApiHeaders || {};
        r = await origFetch(u, { credentials: "include", headers });
      }
      const t = await r.text();
      window.postMessage({
        type: "CD_NOTE",
        text: "主世界重放 " + u.split("?")[0].split("/").pop() + " → HTTP " + r.status + " · " + t.length + "字符",
      }, "*");
      if (!r.ok || t.length < 50) continue;
      harvestText(t);
      if (!/queryResource|queryCourseResources/.test(u)) continue;

      // 结构化解析：{id, name, quote_id, mimetype} —— 下载地址用 quote_id
      const recs = [];
      const walk = (o) => {
        if (!o || typeof o !== "object") return;
        if (Array.isArray(o)) { o.forEach(walk); return; }
        if (o.name && typeof o.name === "string" && /\.(pdf|docx?|pptx?|xlsx?|zip|mp4)$/i.test(o.name)) {
          recs.push({
            id: String(o.id || ""),
            qid: String(o.quote_id || o.fileId || o.file_id || ""),
            name: o.name,
            mime: o.mimetype || "",
          });
        }
        Object.values(o).forEach(walk);
      };
      try { walk(JSON.parse(t)); } catch (e) {}

      recs.forEach((x) => {
        if (/^\d{10,}$/.test(x.id)) nameMap.set(x.id, x.name);
        if (/^\d{10,}$/.test(x.qid)) nameMap.set(x.qid, x.name);
        window.postMessage({ type: "CD_NOTE", text: "文件名映射: " + (x.qid || x.id) + " → " + x.name }, "*");
      });
      // 映射表同步给后台（全局共享，供 iframe/其他捕获条目命名）
      pushMaps();
      if (!recs.length) {
        window.postMessage({ type: "CD_NOTE", text: "JSON结构示例: " + t.slice(0, 400) }, "*");
        continue;
      }

      // 不再构造 pdfv 地址（会话绑定，直接抓取会得到空响应/401）
      // 下载完全依赖预览时截获的字节（CD_CAPTURE → dataUrl 条目）
      window.postMessage({
        type: "CD_NOTE",
        text: "小雅映射完成: " + recs.length + " 个文件（下载请打开对应文件预览）",
      }, "*");
    } catch (e) {
      window.postMessage({ type: "CD_NOTE", text: "重放单接口异常 " + u.slice(0, 80) + " : " + (e && e.message || e) }, "*");
    }
  }
}

// 从页面 JSON 响应中收集 "ID → 文件名" 映射
const nameMap = new Map();
// 阿里云 videoId(32位hex) → 课程资源真名（HLS 源播放链路只出现 videoId，无资源 ID）
const videoIdMap = new Map();
// 视频转码文件名 → 课程资源真名（播放地址是 UUID 转码名，需配对）
const transMap = new Map();
// 最近的视频资源名（配对兜底：视频详情接口先返回 name，随后播放接口给出转码地址）
let pendingVideoName = "";
let pendingVideoT = 0;

// 统一把映射表同步给后台
function pushMaps() {
  try {
    window.postMessage({
      type: "CD_MAPS",
      maps: Object.fromEntries(nameMap),
      transMaps: Object.fromEntries(transMap),
      videoMaps: Object.fromEntries(videoIdMap),
    }, "*");
  } catch (e) {}
}

// 用原始文本提取（JSON.parse 会让超长数字 ID 丢失精度，无法匹配）
function harvestText(text) {
  // 找到所有长数字 ID，在其前后 300 字符内就近找 name/title 类字段的值
  const idRe = /\d{10,}/g;
  let m;
  while ((m = idRe.exec(text)) !== null) {
    const id = m[0];
    if (nameMap.has(id)) continue;
    const start = Math.max(0, m.index - 600);
    const window = text.slice(start, m.index + id.length + 600);
    const nRe = /"([^"]{1,40}(?:name|title)[^"]{0,40})"\s*:\s*"([^"]{1,120})"/gi;
    let n;
    let found = false;
    while ((n = nRe.exec(window)) !== null) {
      const val = n[2];
      if (val && !/^\d+$/.test(val) && !/^(ok|true|false|null|success)$/i.test(val)) {
        nameMap.set(id, val);
        reportMap(id, val);
        found = true;
        break;
      }
    }
    if (!found && noNameCount < 2) {
      noNameCount++;
      // 顺带报告 ID 附近的片段，便于确认字段名（限流，避免刷屏）
      reportMap(id, "【未找到name字段】附近文本: " + window.slice(0, 200));
    }
  }

  // 阿里云 videoId(16-40位hex) 收割：资源 JSON 里的 videoId 字段 → 就近找真名
  const hRe = /"(?:[^"]{0,30}(?:videoId|video_id|mediaId|media_id)[^"]{0,20})"\s*:\s*"([0-9a-f]{16,40})"/gi;
  while ((m = hRe.exec(text)) !== null) {
    const vid = m[1];
    if (videoIdMap.has(vid)) continue;
    const win = text.slice(Math.max(0, m.index - 600), m.index + m[0].length + 600);
    const nM = /"(?:[^"]{0,40}name[^"]{0,40}|title)"\s*:\s*"([^"]{1,120})"/i.exec(win);
    let nm = nM && !/^\d+$/.test(nM[1]) && !/^(ok|true|false|null|success)$/i.test(nM[1]) ? nM[1] : "";
    if (!nm) {
      // 兜底：同窗口内的 19 位资源 ID 查 nameMap
      const idM = /\d{19}/.exec(win);
      if (idM) nm = nameMap.get(idM[0]) || "";
    }
    if (nm) {
      videoIdMap.set(vid, nm);
      reportMap("videoId映射: " + vid.slice(0, 10) + "… → " + nm);
      pushMaps();
    }
  }

  // 视频播放地址收割：JSON 里的 mp4/m3u8 URL（转码名）→ 就近找真名 → transMap
  const vRe = /"(https?:[^"]*\.(?:mp4|m3u8)[^"]*)"/gi;
  while ((m = vRe.exec(text)) !== null) {
    let raw = m[1].replace(/\\u002F/gi, "/").replace(/\\\//g, "/");
    let tail = "";
    try { tail = decodeURIComponent(new URL(raw).pathname.split("/").pop() || ""); } catch (e) { tail = raw.split("/").pop(); }
    tail = (tail || "").split("?")[0];
    if (!/\.(mp4|m3u8)$/i.test(tail) || transMap.has(tail)) continue;
    const win = text.slice(Math.max(0, m.index - 600), m.index + m[1].length + 600);
    const idM = /\d{10,}/.exec(win);
    let nm = (idM && nameMap.get(idM[0])) || "";
    if (!nm) {
      const nM = /"(?:[^"]{0,40}name[^"]{0,40}|title)"\s*:\s*"([^"]{1,120})"/i.exec(win);
      if (nM && !/^\d+$/.test(nM[1]) && !/^(ok|true|false|null|success)$/i.test(nM[1])) nm = nM[1];
    }
    if (!nm && pendingVideoName && Date.now() - pendingVideoT < 8000) nm = pendingVideoName;
    if (nm) {
      transMap.set(tail, nm);
      reportMap("视频映射: " + tail.slice(0, 28) + "… → " + nm);
      pushMaps();
    }
  }

  // 原始文档直链收割：JSON 里出现的 ppt/doc/xls 直链（若平台返回原始文件地址则直接上报）
  const dRe = /"(https?:[^"]*\.(?:pptx?|docx?|xlsx?)[^"]*)"/gi;
  while ((m = dRe.exec(text)) !== null) {
    let raw = m[1].replace(/\\u002F/gi, "/").replace(/\\\//g, "/");
    if (raw.includes("ow365.cn") || raw.includes("file_url")) continue;
    const win = text.slice(Math.max(0, m.index - 600), m.index + m[1].length + 600);
    let nm = "";
    const idM = /\d{19}/.exec(win);
    if (idM) nm = nameMap.get(idM[0]) || "";
    if (!nm) {
      const nM = /"(?:[^"]{0,40}name[^"]{0,40}|title)"\s*:\s*"([^"]{1,120})"/i.exec(win);
      if (nM && !/^\d+$/.test(nM[1]) && !/^(ok|true|false|null|success)$/i.test(nM[1])) nm = nM[1];
    }
    if (!nm) {
      try { nm = decodeURIComponent(new URL(raw).pathname.split("/").pop() || ""); } catch (e) {}
    }
    window.postMessage({ type: "CD_REALFILE", url: raw, name: nm }, "*");
    reportMap("原始文档直链: " + (nm || raw.slice(0, 60)));
  }
}

// 把匹配结果发到调试面板，便于排查
let reportedMaps = new Set();
let noNameCount = 0;
function reportMap(id, name) {
  if (reportedMaps.has(id)) return;
  reportedMaps.add(id);
  try {
    window.postMessage({ type: "CD_NOTE", text: "文件名映射: " + id + " → " + name }, "*");
  } catch (e) {}
}

function harvestNames(obj) {
  const walk = (o) => {
    if (!o || typeof o !== "object") return;
    if (Array.isArray(o)) { o.forEach(walk); return; }
    let idVal = null, nameVal = null;
    for (const [k, v] of Object.entries(o)) {
      if (v == null) continue;
      if (/id$/i.test(k) && /^\d{10,}$/.test(String(v))) idVal = String(v);
      if (/(name|title)/i.test(k) && typeof v === "string" && v.length > 0 && v.length < 120) nameVal = v;
    }
    if (idVal && nameVal) nameMap.set(idVal, nameVal);
    // 阿里云 videoId(hex) 与 name 同节点 → videoIdMap
    for (const [k, v] of Object.entries(o)) {
      if (typeof v === "string" && /^[0-9a-f]{16,40}$/.test(v) && /(video|media)/i.test(k)) {
        const nm2 = o.name || o.title || (o.resource && (o.resource.name || o.resource.title));
        if (nm2 && typeof nm2 === "string") videoIdMap.set(v, nm2);
      }
    }
    Object.values(o).forEach(walk);
  };
  walk(obj);
}

async function scanJson(resp, url) {
  try {
    const ct = (resp.headers.get("content-type") || "").toLowerCase();
    if (!ct.includes("json")) return;
    const t = await resp.clone().text();
    if (t.length > 1000000) return;
    if (!scannedUrls.has(url.split("?")[0])) {
      scannedUrls.add(url.split("?")[0]);
      reportMap("JSON分析", url.split("?")[0].slice(0, 100) + " · " + t.length + "字符");
    }
    harvestText(t);
    // 视频资源详情：记录最近的资源名（播放地址转码名的配对兜底）
    if (/queryResource|queryCourseResources/.test(url)) {
      const nmM = /"name"\s*:\s*"([^"]{1,120})"/.exec(t);
      if (nmM && /video/i.test(t)) {
        pendingVideoName = nmM[1];
        pendingVideoT = Date.now();
      }
    }
    try { harvestNames(JSON.parse(t)); } catch (e) {}
  } catch (e) {}
}
const scannedUrls = new Set();

// pdfv 的 f 参数解码出原始文件名，如 "705749..._705749....pdf"
// 编码变体：标准 base64 后把 "=" 替换成 "-"（结尾 "--" 即 "=="），兼容 base64url
function pdfvFileName(url) {
  try {
    const m = /[?&]f=([^&]+)/.exec(url);
    if (!m) return "";
    const raw = decodeURIComponent(m[1]);
    const cands = [raw.replace(/-/g, "="), raw.replace(/-/g, "+").replace(/_/g, "/")];
    for (let v of cands) {
      try {
        while (v.length % 4) v += "=";
        const dec = atob(v);
        if (/\.(pdf|zip|pptx?|docx?|xlsx?)$/i.test(dec)) return dec.split("\\").pop().trim() || "";
      } catch (e) {}
    }
    return "";
  } catch (e) { return ""; }
}

// 自动捕获：检测响应是否为真实文件（PDF/Office），预览加载时直接截获字节
function guessName(url, ct, isPdf) {
  let name = "";
  try { name = decodeURIComponent(url.split("?")[0].split("/").pop() || ""); } catch (e) { name = ""; }
  const extRe = /\.(pptx?|docx?|pdf|xlsx?|zip|mp4)$/i;
  if (name && extRe.test(name)) return name;
  // ow365 pdfv 地址：从 f 参数解码文件名，并用映射表反查真名
  // Word/PPT 经 pdfv 预览时返回的是转码 PDF，名字如实用 真名.pdf
  if (/\/pdfv\/f\?f=/.test(url)) {
    const fn = pdfvFileName(url);
    if (fn) {
      const qid = /^(\d{10,})/.exec(fn);
      const real = qid && nameMap.has(qid[1]) ? nameMap.get(qid[1]) : "";
      const base = real
        ? real.replace(/\.(pptx?|docx?|xlsx?|pdf)$/i, "")
        : fn.replace(/\.(pptx?|docx?|xlsx?|pdf)$/i, "");
      return base + ".pdf";
    }
  }
  // 从 content-type 推断扩展名（zip 魔数可能是 pptx/docx/xlsx，用 pdf/zip 兜底）
  const extMap = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/vnd.ms-powerpoint": ".ppt",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/msword": ".doc",
  };
  let ext = extMap[(ct || "").split(";")[0].trim()] || "";
  if (!ext) ext = isPdf ? ".pdf" : ".zip";
  // 优先用页面 JSON 里的真实文件名（按 URL 中的数字 ID 匹配）
  const idMatch = /\d{10,}/.exec(url);
  if (idMatch && nameMap.has(idMatch[0])) {
    const real = nameMap.get(idMatch[0]);
    return extRe.test(real) ? real : real + ext;
  }
  // 名字必须稳定（同一 URL 每次捕获同名才能去重）：优先 URL 尾段，否则用 query 前的完整路径哈希
  if (!name) {
    try { name = new URL(url).pathname.replace(/\//g, "_").slice(-40); } catch (e) { name = "captured"; }
  }
  return name + ext;
}

async function tryCapture(resp, url) {
  try {
    // 只处理课程学习页面上下文中的响应
    if (!cdMayCapture()) return;
    const ct = resp.headers.get("content-type") || "";
    const clone = resp.clone();
    const buf = await clone.arrayBuffer();
    if (buf.byteLength < 1024) return;
    const b = new Uint8Array(buf.slice(0, 4));
    const isPdf = b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46; // %PDF
    const isZip = b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04; // PK (pptx/docx/xlsx/zip)
    if (!isPdf && !isZip) return;
    // 统一规则：确认是课件类型才截获（永中 pdfv 的 f 参数提供文件名线索）
    if (S) {
      const hint = /[?&]f=/.test(url) ? S.decodePdfvName(url) : "";
      const judged = S.classifyResource({
        url, mime: ct, filenameHint: hint,
        learning: true, strict: cdStrict,
      });
      if (!judged.ok) return;
    }
    const bytes = new Uint8Array(buf);
    let binary = "";
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    window.postMessage({
      type: "CD_CAPTURE",
      name: guessName(url, ct, isPdf),
      mime: ct,
      size: bytes.length,
      b64: btoa(binary),
    }, "*");
    // PPT/Word 的预览是永中转码 PDF；顺带探测原始文件（.pptx 等）的真实地址
    const fn = pdfvFileName(url);
    const qm = fn && /^(\d{10,})/.exec(fn);
    if (qm) probeOriginal(qm[1]);
  } catch (e) {}
}

// 探测原始文件地址：file_url 接口不带 encryption_status、filename 用原始扩展名
let probeTried = new Set();

// PPT/Word 预览（pv.aspx 逐页图片，无法直接截获）：用 bs 构造 pdfv 请求，让永中服务端转出 PDF 版并截获
let owviewTried = new Set();
async function owviewProbe(bs) {
  try {
    const dec = atob(bs.replace(/-/g, "=")); // oss.ai-augmented.com.80\7066...ppt
    const fn = dec.split("\\").pop().trim(); // 7066211424363613907.ppt
    if (!/\.(pptx?|docx?|xlsx?)$/i.test(fn)) return; // PDF 源文件本身就有 pdfv 通道
    // 范围守卫：只处理带平台文件证据（平台存储域 / 资源 ID）的预览，避免无关永中页被探测
    if (S && !S.hasPlatformFileEvidence(dec)) return;
    if (owviewTried.has(fn)) return;
    owviewTried.add(fn);
    // 两种 f 变体都试：bs 原样（带存储前缀）/ 纯文件名重编码
    const fnEnc = btoa(fn).replace(/=/g, "-");
    const cands = [bs, fnEnc];
    let diagSent = false;
    for (const f of cands) {
      let r;
      try {
        r = await origFetch("https://x1.ow365.cn/pdfv/f?f=" + encodeURIComponent(f), { credentials: "include" });
      } catch (e) {
        if (!diagSent) {
          diagSent = true;
          window.postMessage({ type: "CD_NOTE", text: "PPT构造fetch异常(疑似网络层拦截): " + (e && e.message || e) }, "*");
        }
        continue;
      }
      if (!r.ok) continue;
      const buf = await r.arrayBuffer();
      // 魔数：%PDF / PK(OOXML) / D0CF11E0(OLE2 = 老版 .ppt/.doc 本体！pdfv 对非PDF源直接回原始文件)
      const head = new Uint8Array(buf.slice(0, 2048));
      let s = "";
      for (let i = 0; i < Math.min(head.length, 64); i++) s += String.fromCharCode(head[i]);
      const magic =
        s.includes("%PDF") ||
        s.indexOf("PK\x03\x04") === 0 ||
        (s.charCodeAt(0) === 0xd0 && s.charCodeAt(1) === 0xcf && s.charCodeAt(2) === 0x11);
      if (!magic || buf.byteLength < 1024) {
        if (!diagSent) {
          diagSent = true;
          const hex = [...head.subarray(0, 8)].map((x) => x.toString(16).padStart(2, "0")).join(" ");
          window.postMessage({
            type: "CD_NOTE",
            text: "PPT构造响应诊断: ct=" + (r.headers.get("content-type") || "?") + " · " + (buf.byteLength / 1048576).toFixed(2) + "MB · 头8字节=" + hex + " · 前40字符=" + JSON.stringify(s.slice(0, 40)),
          }, "*");
        }
        continue;
      }
      const bytes = new Uint8Array(buf);
      let binary = "";
      const CH = 0x8000;
      for (let i = 0; i < bytes.length; i += CH) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
      // 返回的是原始文件本体（.ppt/.doc 为 OLE2，.pptx/.docx 为 PK）：按原始扩展名命名
      const mimeMap = {
        ppt: "application/vnd.ms-powerpoint",
        pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        doc: "application/msword",
        docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      };
      const ext2 = (fn.match(/\.([a-z0-9]+)$/i) || [])[1] || "bin";
      window.postMessage({
        type: "CD_CAPTURE",
        name: fn,
        mime: mimeMap[ext2.toLowerCase()] || "application/octet-stream",
        size: bytes.length,
        b64: btoa(binary),
      }, "*");
      window.postMessage({ type: "CD_NOTE", text: "PPT原始文件已截获: " + fn + " (" + (bytes.length / 1048576).toFixed(2) + "MB)" }, "*");
      return;
    }
    window.postMessage({ type: "CD_NOTE", text: "PPT转码PDF构造未成功（" + fn + "），可继续用预览浏览" }, "*");
  } catch (e) {}
}

async function probeOriginal(qid) {
  try {
    const nm = nameMap.get(qid) || "";
    const extM = /\.(pptx?|docx?|xlsx?)$/i.exec(nm);
    if (!extM) return; // 只有 office 文档需要找原始文件
    const cands = [
      "https://whut.ai-augmented.com/api/jx-oresource/cloud/file_url/" + qid + "?filename=" + qid + "." + extM[1],
      "https://whut.ai-augmented.com/api/jx-oresource/cloud/file_url/" + qid + "?filename=" + encodeURIComponent(nm),
    ];
    for (const u of cands) {
      if (probeTried.has(u.split("?")[1])) continue;
      probeTried.add(u.split("?")[1]);
      let headers = headerStore.get(u) || headerStore.get(u.split("?")[0]);
      if (!headers) {
        for (const [k, v] of headerStore) {
          if (k.includes("/api/") && k.split("?")[0] !== u) { headers = v; break; }
        }
      }
      const r = await origFetch(u, { credentials: "include", headers: headers || {} });
      if (!r.ok) continue;
      const t = await r.text();
      const linkM = /https?:\/\/[^"\s\\]+\.(?:pptx?|docx?|xlsx?)(?:\?[^"\s\\]*)?/i.exec(t.replace(/\\u002F/gi, "/").replace(/\\\//g, "/"));
      if (linkM && !linkM[0].includes("ow365.cn")) {
        window.postMessage({ type: "CD_REALFILE", url: linkM[0], name: nm }, "*");
        window.postMessage({ type: "CD_NOTE", text: "原始文件直链: " + nm }, "*");
        return;
      }
    }
    window.postMessage({ type: "CD_NOTE", text: "原始" + extM[1] + "接口未返回直链（预览转码版已捕获）: " + nm }, "*");
  } catch (e) {}
}

// Hook fetch：记录请求头 + 自动捕获文件响应
const origFetch = window.fetch;

// PPT/Word 预览页（pv.aspx）：document_start 立即探测（比 content.js 的定时器早，下载与用户浏览并行，
// 避免捕获完成时用户已切换到下一个文件）
if (/\/owview\/p\/pv\.aspx$/i.test(location.pathname)) {
  try {
    const bs0 = new URLSearchParams(location.search).get("bs") || "";
    if (bs0) {
      try { owviewProbe(bs0); } catch (e) {}
    }
  } catch (e) {}
}

window.fetch = function (...args) {
  try {
    const input = args[0];
    const init = args[1] || {};
    const url = typeof input === "string" ? input : input?.url || "";
    const h = new Headers(init.headers || (typeof input === "object" && input?.headers) || {});
    const obj = {};
    h.forEach((v, k) => (obj[k] = v));
    if (Object.keys(obj).length) recordHeaders(url, obj);
  } catch (e) {}
  const p = origFetch.apply(this, args);
  try {
    const url = typeof args[0] === "string" ? args[0] : args[0]?.url || "";
    p.then((resp) => {
      if (!resp) return;
      scanJson(resp, url);
      if (resp.ok) tryCapture(resp, url);
    }).catch(() => {});
  } catch (e) {}
  return p;
};

// Hook XHR：记录 setRequestHeader 设置的头
const origOpen = XMLHttpRequest.prototype.open;
const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
XMLHttpRequest.prototype.open = function (method, url, ...rest) {
  this.__cdUrl = url;
  this.__cdHeaders = {};
  return origOpen.call(this, method, url, ...rest);
};
XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
  try {
    if (this.__cdHeaders) this.__cdHeaders[name] = value;
  } catch (e) {}
  return origSetHeader.call(this, name, value);
};
const origSend = XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.send = function (...args) {
  try {
    if (this.__cdUrl && Object.keys(this.__cdHeaders || {}).length) {
      recordHeaders(this.__cdUrl, this.__cdHeaders);
    }
    this.addEventListener("load", () => {
      try {
        const url = this.responseURL || this.__cdUrl || "";
        const rt = this.responseType;
        let buf = null;
        if (rt === "arraybuffer") buf = this.response;
        else if (rt === "blob" && this.response) buf = this.response; // Blob
        else if (rt === "" || rt === "text") {
          const t = typeof this.response === "string" ? this.response : "";
          if (t.length > 1024 && (/^%PDF/.test(t.slice(0, 1024)) || /^PK\x03\x04/.test(t.slice(0, 1024)))) {
            buf = new TextEncoder().encode(t).buffer;
          }
        }
        if (!buf) return;
        const ab = buf instanceof Blob ? null : buf;
        if (buf instanceof Blob) {
          buf.arrayBuffer().then((b) => inspectAndCapture(b, url, this.getResponseHeader("content-type") || ""));
        } else {
          inspectAndCapture(ab, url, this.getResponseHeader("content-type") || "");
        }
        // JSON 文本响应：收割文件名映射
        if (rt === "" || rt === "text") {
          const t2 = typeof this.response === "string" ? this.response : "";
          const ct2 = this.getResponseHeader("content-type") || "";
          if (t2 && t2.length < 1000000 && ct2.toLowerCase().includes("json")) {
            const key = "XHR:" + url.split("?")[0];
            if (!scannedUrls.has(key)) {
              scannedUrls.add(key);
              reportMap("JSON分析", key.slice(4, 104) + " · " + t2.length + "字符");
            }
            harvestText(t2);
            try { harvestNames(JSON.parse(t2)); } catch (e) {}
          }
        } else if (rt === "json") {
          reportMap("XHR限制", url.split("?")[0].slice(0, 100) + " 使用 responseType=json，拿不到原始文本");
        }
      } catch (e) {}
    });
  } catch (e) {}
  return origSend.apply(this, args);
};

function inspectAndCapture(ab, url, ct) {
  try {
    if (!cdMayCapture()) return;
    if (!ab || ab.byteLength < 1024) return;
    const b = new Uint8Array(ab.slice(0, 4));
    const isPdf = b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46;
    const isZip = b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;
    if (!isPdf && !isZip) return;
    // 统一规则：确认是课件类型才截获
    if (S) {
      const hint = /[?&]f=/.test(url) ? S.decodePdfvName(url) : "";
      const judged = S.classifyResource({ url, mime: ct, filenameHint: hint, learning: true, strict: cdStrict });
      if (!judged.ok) return;
    }
    const bytes = new Uint8Array(ab);
    let binary = "";
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    const capName = guessName(url, ct, isPdf);
    window.postMessage({
      type: "CD_CAPTURE",
      name: capName,
      mime: ct,
      size: bytes.length,
      b64: btoa(binary),
    }, "*");
    window.postMessage({
      type: "CD_NOTE",
      text: "已捕获预览文件: " + capName + " · " + (bytes.length / 1024 / 1024).toFixed(2) + "MB（可直接下载）",
    }, "*");
  } catch (e) {}
}

// ============ ow365 预览 iframe：抢先截获 ============
// pdfv 请求由浏览器原生查看器/worker 发出，fetch/XHR hook 抓不到。
// 策略：拦截 iframe/embed/object 的 src 赋值，在原生消费前先 fetch 存档，再交给预览器。
// 范围约束：仅处理「平台内嵌的预览框」或「f 参数带平台文件证据（平台存储域名/资源 ID）」，避免把无关永中页也截获。
function cdIsPlatformPreview(src) {
  if (cdIsLearningHere()) return true; // 平台页面内嵌（含跨域预览框）
  // 新标签页直接打开预览：没有祖先链，改看 f 参数里的平台文件证据
  try {
    if (S) {
      const fn = S.decodePdfvName(src);
      if (fn && S.hasPlatformFileEvidence(fn)) return true;
      if (S.hasPlatformFileEvidence(decodeURIComponent(src))) return true;
    }
  } catch (e) {}
  return false;
}

if (/ow365\.cn$/.test(location.hostname)) {
  const PDFV_RE = /\/pdfv\/f\?f=/;
  const preempted = new Set();

  const decodeFName = pdfvFileName;

  async function preempt(src, apply) {
    if (!cdIsPlatformPreview(src)) { apply(src); return; } // 与课程无关的永中页：不截获
    if (preempted.has(src)) { apply(src); return; }
    preempted.add(src);
    try {
      const r = await origFetch(src, { credentials: "include" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const ab = await r.arrayBuffer();
      const b = new Uint8Array(ab.slice(0, 4));
      const isPdf = b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46;
      const isZip = b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;
      if ((!isPdf && !isZip) || ab.byteLength < 1024) throw new Error("非文件内容(" + ab.byteLength + "B)");
      // 统一规则复核：确认是课件类型
      if (S) {
        const judged = S.classifyResource({
          url: src,
          mime: r.headers.get("content-type") || "",
          filenameHint: decodeFName(src) || "",
          learning: true,
          strict: cdStrict,
        });
        if (!judged.ok) throw new Error("非课件类型");
      }
      const bytes = new Uint8Array(ab);
      let bin = "";
      for (let i = 0; i < bytes.length; i += 32768) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 32768));
      const fn = decodeFName(src) || "preview_" + Date.now() + (isPdf ? ".pdf" : ".zip");
      window.postMessage({ type: "CD_CAPTURE", name: fn, mime: r.headers.get("content-type") || "application/pdf", size: bytes.length, b64: btoa(bin) }, "*");
      window.postMessage({ type: "CD_NOTE", text: "抢先截获预览文件: " + fn + " · " + (bytes.length / 1048576).toFixed(2) + "MB（可直接下载）" }, "*");
      apply(URL.createObjectURL(new Blob([ab], { type: isPdf ? "application/pdf" : "application/octet-stream" })));
    } catch (e) {
      window.postMessage({ type: "CD_NOTE", text: "抢先截获未成功（" + (e && e.message || e) + "），放行原始请求" }, "*");
      apply(src);
    }
  }

  function wrapProp(clsName, prop) {
    const proto = window[clsName] && window[clsName].prototype;
    if (!proto) return;
    const d = Object.getOwnPropertyDescriptor(proto, prop);
    if (!d || !d.set) return;
    Object.defineProperty(proto, prop, {
      configurable: true,
      get() { return d.get.call(this); },
      set(v) {
        try {
          const str = String(v || "");
          if (PDFV_RE.test(str)) { preempt(str, (u) => d.set.call(this, u)); return; }
        } catch (e) {}
        return d.set.call(this, v);
      },
    });
  }
  wrapProp("HTMLIFrameElement", "src");
  wrapProp("HTMLEmbedElement", "src");
  wrapProp("HTMLObjectElement", "data");

  const origSetAttr = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name, val) {
    try {
      const str = String(val || "");
      if ((name === "src" || name === "data") && PDFV_RE.test(str)) {
        preempt(str, (u) => origSetAttr.call(this, name, u));
        return;
      }
    } catch (e) {}
    return origSetAttr.call(this, name, val);
  };

  // 诊断：若 DOM 里出现 pdfv 元素说明是 HTML 内联（无法抢先），记录下来
  const diag = () => {
    document.querySelectorAll('iframe[src*="/pdfv/f?f="],embed[src*="/pdfv/f?f="],object[data*="/pdfv/f?f="]').forEach((el) => {
      window.postMessage({ type: "CD_NOTE", text: "检测到内联pdfv元素（HTML内联，无法抢先）: " + (el.src || el.data || "").slice(0, 90) }, "*");
    });
  };
  document.addEventListener("DOMContentLoaded", diag);
  setTimeout(diag, 1500);

  // Worker 包裹：worker 内的 fetch 也无法从外部 hook，注入捕获代码
  const OrigWorker = window.Worker;
  if (OrigWorker) {
    const HOOK = `(function(){
      var of=self.fetch;
      self.fetch=function(...a){
        var p=of.apply(this,a);
        try{
          var u=typeof a[0]==='string'?a[0]:(a[0]&&a[0].url)||'';
          p.then(function(r){
            try{
              var c=r.clone();
              c.arrayBuffer().then(function(ab){
                var b=new Uint8Array(ab.slice(0,4));
                var pdf=b[0]===0x25&&b[1]===0x50&&b[2]===0x44&&b[3]===0x46;
                var zip=b[0]===0x50&&b[1]===0x4b&&b[2]===0x03&&b[3]===0x04;
                if((pdf||zip)&&ab.byteLength>1024){
                  var u8=new Uint8Array(ab),bin='';
                  for(var i=0;i<u8.length;i+=32768)bin+=String.fromCharCode.apply(null,u8.subarray(i,i+32768));
                  var nm='file'+(pdf?'.pdf':'.zip');
                  var m=/[?&]f=([^&]+)/.exec(u);
                  if(m){try{var raw=decodeURIComponent(m[1]);var cs=[raw.replace(/-/g,'='),raw.replace(/-/g,'+').replace(/_/g,'/')];for(var ci=0;ci<cs.length;ci++){var vv=cs[ci];while(vv.length%4)vv+='=';var dd=atob(vv);if(/\\.pdf$|\\.zip$/.test(dd)){nm=dd.split('\\\\').pop()||nm;break;}}}catch(e){}}
                  self.postMessage({__cdCap:1,name:nm,mime:r.headers.get('content-type')||'',size:u8.length,b64:btoa(bin)});
                }
              });
            }catch(e){}
          }).catch(function(){});
        }catch(e){}
        return p;
      };
    })();`;
    window.Worker = function (url, opts) {
      try {
        if (opts && opts.type === "module") return new OrigWorker(url, opts);
        const full = new URL(url, location.href).href;
        const blob = new Blob([HOOK + 'importScripts(' + JSON.stringify(full) + ');'], { type: "application/javascript" });
        const w = new OrigWorker(URL.createObjectURL(blob), opts);
        w.addEventListener("message", (e) => {
          const d = e.data;
          if (d && d.__cdCap) {
            window.postMessage({ type: "CD_CAPTURE", name: d.name, mime: d.mime, size: d.size, b64: d.b64 }, "*");
            window.postMessage({ type: "CD_NOTE", text: "Worker内截获: " + d.name + " · " + (d.size / 1048576).toFixed(2) + "MB（可直接下载）" }, "*");
          }
        });
        return w;
      } catch (e) {
        return new OrigWorker(url, opts);
      }
    };
    window.Worker.prototype = OrigWorker.prototype;
  }
}

// 下载请求处理
// HLS(m3u8) 下载：解析播放列表 → 并发抓分片 → 拼接 Blob → a[download] 保存 .ts
async function hlsDownload(u, name) {
  const abs = (x) => new URL(x, u).href;
  async function getPlaylist(link) {
    const r = await origFetch(link, { credentials: "include" });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.text();
  }
  window.postMessage({ type: "CD_NOTE", text: "HLS下载: 正在获取播放列表" }, "*");
  let pl = await getPlaylist(u);
  if (/#EXT-X-STREAM-INF/.test(pl)) {
    const lines = pl.split("\n");
    let best = "", bestBw = -1;
    for (let i = 0; i < lines.length; i++) {
      if (/^#EXT-X-STREAM-INF/.test(lines[i])) {
        const bw = parseInt((/BANDWIDTH=(\d+)/.exec(lines[i]) || [])[1] || "0");
        const uri = (lines[i + 1] || "").trim();
        if (uri && !uri.startsWith("#") && bw >= bestBw) { bestBw = bw; best = uri; }
      }
    }
    if (!best) throw new Error("master m3u8 中未找到子播放列表");
    pl = await getPlaylist(abs(best));
  }
  const segs = pl.split("\n").map((s) => s.trim()).filter((s) => s && !s.startsWith("#"));
  if (!segs.length) throw new Error("播放列表中没有分片");
  const parts = new Array(segs.length);
  const SEGS_MAX_RETRY = 2; // 每个分片最多重试 2 次（指数退避）
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function fetchSeg(url, tries) {
    let lastErr = null;
    for (let t = 0; t <= tries; t++) {
      try {
        const r = await origFetch(url, { credentials: "include" });
        if (!r.ok) throw new Error("HTTP " + r.status);
        const buf = new Uint8Array(await r.arrayBuffer());
        if (!buf.length) throw new Error("空分片");
        return buf;
      } catch (e) {
        lastErr = e;
        if (t < tries) await sleep(400 * Math.pow(2, t));
      }
    }
    throw lastErr || new Error("分片下载失败");
  }
  let done = 0, failed = 0, idx = 0;
  const failedIdx = [];
  const t0 = Date.now();
  async function worker() {
    while (idx < segs.length) {
      const i = idx++;
      try {
        parts[i] = await fetchSeg(abs(segs[i]), SEGS_MAX_RETRY);
      } catch (e) {
        failed++;
        failedIdx.push(i);
        parts[i] = new Uint8Array(0);
      }
      done++;
      if (done % 20 === 0 || done === segs.length) {
        window.postMessage({
          type: "CD_NOTE",
          text: "HLS下载中: " + done + "/" + segs.length + " 分片（" + ((Date.now() - t0) / 1000).toFixed(0) + "s）"
            + (failed ? " · 失败 " + failed : ""),
        }, "*");
      }
    }
  }
  await Promise.all(Array.from({ length: 6 }, worker));
  // 任何分片缺失都会让 .ts 在播放器里卡住，宁可明确失败，也不交付损坏文件
  if (failed > 0) {
    throw new Error(
      "有 " + failed + " 个分片重试后仍失败（第 " +
      failedIdx.slice(0, 8).map((i) => i + 1).join(",") + (failedIdx.length > 8 ? "…" : "") + " 片），已放弃保存，请重新点击下载"
    );
  }
  const blob = new Blob(parts, { type: "video/mp2t" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  const base = (name || "").replace(/\.[a-z0-9]{2,5}$/i, "").trim() || "video_" + new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  a.download = base + ".ts";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 60000);
  window.postMessage({
    type: "CD_HLS_DONE",
    text: "HLS下载完成: " + segs.length + " 分片 · " + (blob.size / 1048576).toFixed(1) + "MB，已触发浏览器保存 .ts",
  }, "*");
}

window.addEventListener("message", async (e) => {
  if (e.source !== window) return;
  const d = e.data;
  if (!d) return;
  // content 脚本主动拉取的小雅接口原始文本 → 精确收割映射
  if (d.type === "CD_JSON_TEXT" && typeof d.text === "string") {
    try { harvestText(d.text); } catch (err) {}
    try { harvestNames(JSON.parse(d.text)); } catch (err) {}
    return;
  }
  // 小雅接口重放（带页面认证头）
  if (d.type === "CD_XY_GET" && Array.isArray(d.urls)) {
    window.postMessage({ type: "CD_NOTE", text: "main.js 已收到重放请求 (" + d.urls.length + "个接口)" }, "*");
    xyReplay(d.urls).catch((err) => window.postMessage({ type: "CD_NOTE", text: "重放异常: " + (err && err.message || err) }, "*"));
    return;
  }
  // HLS(m3u8) 下载：主世界分片抓取拼接，a[download] 保存 .ts
  if (d.type === "CD_HLS" && d.url) {
    hlsDownload(d.url, d.name).catch((err) =>
      window.postMessage({ type: "CD_HLS_DONE", err: String(err && err.message || err) }, "*")
    );
    return;
  }
  // ow365 PPT/Word 预览页：用 bs 参数构造 pdfv，截获转码 PDF 版
  if (d.type === "CD_OWVIEW" && d.bs) {
    owviewProbe(d.bs);
    return;
  }
  if (d.type !== "CD_FETCH" || !d.url) return;
  const id = d.id;
  try {
    // 找到页面之前对该地址（或其 API 路径）用过的请求头
    let headers = headerStore.get(d.url) || headerStore.get(d.url.split("?")[0]);
    if (!headers) {
      // 按最后一段路径匹配（如文件 id）
      const tail = d.url.split("?")[0].split("/").pop();
      for (const [k, v] of headerStore) {
        if (k.split("?")[0].split("/").pop() === tail) { headers = v; break; }
      }
    }
    const resp = await origFetch(d.url, { credentials: "include", headers: headers || {} });
    if (!resp.ok) throw new Error("HTTP " + resp.status + (headers ? "" : "（未找到页面认证头）"));
    let buf = await resp.arrayBuffer();
    let ct = (resp.headers.get("content-type") || "").toLowerCase();

    // 如果返回的是 JSON/文本，多半是接口包装：从中提取真实文件地址并跟随
    if (ct.includes("json") || ct.includes("text/")) {
      const text = new TextDecoder().decode(buf);
      const candidates = [];

      // 递归搜索 JSON 中的字符串值
      const collect = (obj) => {
        if (!obj) return;
        if (typeof obj === "string") { candidates.push(obj); return; }
        if (typeof obj === "object") Object.values(obj).forEach(collect);
      };
      try { collect(JSON.parse(text)); } catch (e) {}
      candidates.push(...(text.match(/https?:\/\/[^"'\s\\]+/g) || []));

      // 只留下可能是文件地址/路径的值
      const extRe = /\.(pptx?|docx?|pdf|xlsx?|zip|mp4)/i;
      const isTokenLike = (s) => !extRe.test(s) && !s.startsWith("http") && !s.includes("/") && s.length > 30;
      let fileCands = candidates.filter((s) => extRe.test(s) || s.startsWith("http"));

      if (!fileCands.length && candidates.some(isTokenLike)) {
        // data.url 是纯 token：显示完整值，便于确定拼接方式
        const tok = candidates.find(isTokenLike);
        throw new Error("data.url 是 token 而非地址（完整值）: " + tok + " ｜原始JSON: " + text.slice(0, 400));
      }

      if (fileCands.length) {
        let real = fileCands[0];
        if (!real.startsWith("http")) {
          // 相对路径，补全 origin
          try { real = new URL(real.startsWith("/") ? real : "/" + real, location.origin).href; } catch (e) {}
        }
        const r2 = await origFetch(real, { credentials: "include" });
        if (!r2.ok) throw new Error("跟随真实地址失败 HTTP " + r2.status + "：" + real.slice(0, 150));
        buf = await r2.arrayBuffer();
        ct = (r2.headers.get("content-type") || "").toLowerCase();
        d.url = real; // 用真实地址推断文件名
      } else {
        throw new Error("接口返回 JSON 无文件地址，内容: " + text.slice(0, 400));
      }
    }
    if (buf.byteLength < 100) {
      throw new Error("响应过小（" + buf.byteLength + " 字节），content-type: " + ct);
    }
    const bytes = new Uint8Array(buf);
    let binary = "";
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    }
    const b64 = btoa(binary);

    // 从响应头推断文件名
    const cd = resp.headers.get("content-disposition") || "";
    let name = "";
    const m = /filename\*?=(?:UTF-8''|")?([^";]+)/i.exec(cd);
    if (m) { try { name = decodeURIComponent(m[1].replace(/"/g, "")); } catch (err) { name = m[1].replace(/"/g, ""); } }
    if (!name) {
      const ct = (resp.headers.get("content-type") || "").split(";")[0].trim();
      const extMap = {
        "application/pdf": ".pdf",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
        "application/vnd.ms-powerpoint": ".ppt",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
        "application/msword": ".doc",
        "application/zip": ".zip",
      };
      const base = decodeURIComponent(d.url.split("/").pop().split("?")[0] || "file");
      const ext = extMap[ct] || "";
      name = ext && !base.toLowerCase().endsWith(ext) ? base + ext : base || "file" + ext;
    }
    window.postMessage({ type: "CD_DATA", id, b64, name }, "*");
  } catch (err) {
    window.postMessage({ type: "CD_ERROR", id, err: String(err.message || err) }, "*");
  }
});

// 启动标记
try { window.postMessage({ type: "CD_NOTE", text: "main.js 已加载（主世界） " + location.pathname.slice(0, 50) }, "*"); } catch (e) {}
