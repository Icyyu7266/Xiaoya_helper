const listEl = document.getElementById("list");
const errEl = document.getElementById("err");
let batchRunning = false;

// 统一的单条下载链；mode: "single"（弹另存为）| "batch"（直接保存到下载目录）
function downloadOne(it, name, btn, mode, cb) {
  const finish = (r) => {
    if (btn) {
      if (r && r.err) {
        errEl.textContent = "下载失败：" + r.err;
        errEl.hidden = false;
      }
      btn.textContent = "下载";
    }
    cb && cb(r || {});
  };
  const saveAs = mode !== "batch";
  // 自动捕获的文件：直接用已存的数据保存
  if (it.dataUrl) {
    return chrome.runtime.sendMessage(
      { action: "downloadData", dataUrl: it.dataUrl, filename: name, saveAs },
      finish
    );
  }
  // HLS(m3u8) 视频：主世界分片下载拼接保存 .ts（长任务）
  if (/\.m3u8(\?|$)/i.test(it.url)) {
    return chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return finish({ err: "未找到活动标签页" });
      chrome.tabs.sendMessage(tab.id, { action: "pageHls", url: it.url, name }, (r) => {
        if (chrome.runtime.lastError) return finish({ err: "页面未就绪，请刷新课程页后重试" });
        if (r && r.err) return finish(r);
        if (r && r.text && mode !== "batch") {
          errEl.textContent = r.text;
          errEl.hidden = false;
        }
        finish({ ok: true, text: r && r.text });
      });
    });
  }
  // ow365 地址：派发给预览 iframe 内的脚本抓取（分区 Cookie 只有 iframe 内部能带上）
  const iframeFetch = (url, cb2) => {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return cb2({ err: "未找到活动标签页" });
      chrome.webNavigation.getAllFrames({ tabId: tab.id }, (frames) => {
        if (!frames || !frames.length) return cb2({ err: "无可用frame" });
        const sorted = frames.slice().sort(
          (a, b) => (/ow365\.cn/.test(b.url) ? 1 : 0) - (/ow365\.cn/.test(a.url) ? 1 : 0)
        );
        const tryOne = (i) => {
          if (i >= sorted.length) return cb2({ err: "所有frame均抓取失败（请先打开一次课件预览再下载）" });
          chrome.tabs.sendMessage(
            tab.id,
            { action: "pageFetch", url },
            { frameId: sorted[i].frameId },
            (r) => {
              if (chrome.runtime.lastError || !r || r.err) return tryOne(i + 1);
              cb2(r);
            }
          );
        };
        tryOne(0);
      });
    });
  };

  // 校验 base64 内容是真实文件（防保存空白/错误页）
  const validMagic = (b64) => {
    try {
      const head = atob(b64.slice(0, 12)).slice(0, 8);
      return head.startsWith("%PDF") || head.startsWith("PK") || head.startsWith("ftyp") || head.startsWith("\x1f\x8b");
    } catch (e) { return false; }
  };

  // 主路径：后台直接抓取（有 host_permissions，不受 CORS 限制）
  chrome.runtime.sendMessage(
    { action: "fetchDownload", url: it.url, filename: name, saveAs },
    (r) => {
      if (r && !r.err) return finish(r);
      const owFail = () =>
        finish({ err: "该文件需要先在页面上打开它的预览（预览后插件会自动捕获完整文件，再点下载即可）" });
      if (/x1\.ow365\.cn/.test(it.url)) {
        iframeFetch(it.url, (r3) => {
          if (r3 && !r3.err && r3.b64 && validMagic(r3.b64)) {
            return chrome.runtime.sendMessage(
              { action: "downloadData", dataUrl: "data:application/octet-stream;base64," + r3.b64, filename: r3.name || name, saveAs },
              finish
            );
          }
          owFail();
        });
        return;
      }
      // 非 ow365：备用浏览器直接下载（公开 CDN 链接）
      chrome.runtime.sendMessage({ action: "download", url: it.url, saveAs }, (r2) => {
        if (r2 && !r2.err) return finish(r2);
        finish({ err: (r && r.err ? r.err : "") + (r2 && r2.err ? "（浏览器下载也未成功: " + r2.err + "）" : "") });
      });
    }
  );
}

function render(list) {
  errEl.hidden = true;
  if (!list.length) {
    listEl.innerHTML =
      '<div class="empty">暂未捕获到文件。<br />在页面上打开某个课件的预览，这里就会出现可下载的文件。</div>';
    return;
  }
  // 截获的数据条目（可直接下载）排前面
  list = list.slice().sort((a, b) => (b.dataUrl ? 1 : 0) - (a.dataUrl ? 1 : 0));
  const itemMap = {};
  list.forEach((it) => (itemMap[it.time] = it));

  listEl.innerHTML = "";
  // 批量工具栏
  const bar = document.createElement("div");
  bar.id = "batchbar";
  bar.innerHTML = `
    <label><input type="checkbox" id="selall" /> 全选</label>
    <button id="batchdl" disabled>下载选中</button>
    <span id="batchinfo"></span>`;
  listEl.appendChild(bar);
  const selAll = bar.querySelector("#selall");
  const batchBtn = bar.querySelector("#batchdl");
  const batchInfo = bar.querySelector("#batchinfo");

  list.forEach((it) => {
    const div = document.createElement("div");
    div.className = "item";
    const name = it.name || decodeURIComponent(it.url.split("/").pop().split("?")[0] || "file");
    const sizeText = it.size ? " · " + (it.size / 1024 / 1024).toFixed(2) + " MB" : "";
    div.innerHTML = `
      <div class="top">
        <span class="badge">${it.type}${sizeText}</span>
        <button class="dl">下载</button>
      </div>
      <div class="url" title="${it.url}">${name}</div>
      <div class="url">${new Date(it.time).toLocaleTimeString()}</div>`;
    const nameDiv = div.querySelectorAll(".url")[0];
    nameDiv.title = it.url + "（双击可改名）";
    nameDiv.ondblclick = () => {
      const n = prompt("修改文件名：", name);
      if (n && n.trim()) {
        chrome.runtime.sendMessage({ action: "rename", time: it.time, name: n.trim() }, refresh);
      }
    };
    // 复选框
    const ck = document.createElement("input");
    ck.type = "checkbox";
    ck.className = "ck";
    ck.dataset.t = it.time;
    ck.onclick = () => {
      const boxes = [...listEl.querySelectorAll(".ck")];
      const all = boxes.length && boxes.every((b) => b.checked);
      selAll.checked = all;
      const n = boxes.filter((b) => b.checked).length;
      batchBtn.textContent = "下载选中" + (n ? "（" + n + "）" : "");
      batchBtn.disabled = !n || batchRunning;
    };
    div.querySelector(".top").prepend(ck);
    div.querySelector(".dl").onclick = () => {
      const btn = div.querySelector(".dl");
      btn.textContent = "下载中…";
      downloadOne(it, name, btn, "single");
    };
    listEl.appendChild(div);
  });

  // 全选联动
  selAll.onclick = () => {
    listEl.querySelectorAll(".ck").forEach((b) => (b.checked = selAll.checked));
    const n = selAll.checked ? list.length : 0;
    batchBtn.textContent = "下载选中" + (n ? "（" + n + "）" : "");
    batchBtn.disabled = !n || batchRunning;
  };

  // 批量下载：顺序执行，直接保存到默认下载目录（不逐个弹另存为）
  batchBtn.onclick = () => {
    const targets = [...listEl.querySelectorAll(".ck")]
      .filter((b) => b.checked)
      .map((b) => itemMap[b.dataset.t])
      .filter(Boolean);
    if (!targets.length || batchRunning) return;
    batchRunning = true;
    batchBtn.disabled = true;
    selAll.disabled = true;
    errEl.hidden = true;
    let i = 0, ok = 0;
    const failed = [];
    const step = () => {
      if (i >= targets.length) {
        batchRunning = false;
        batchBtn.disabled = false;
        selAll.disabled = false;
        batchInfo.textContent = "完成：" + ok + " 成功" + (failed.length ? "，" + failed.length + " 失败" : "");
        if (failed.length) {
          errEl.textContent = "批量下载失败项：\n" + failed.join("\n");
          errEl.hidden = false;
        }
        return;
      }
      const it = targets[i];
      const nm = it.name || decodeURIComponent(it.url.split("/").pop().split("?")[0] || "file");
      batchInfo.textContent = "下载中 " + (i + 1) + "/" + targets.length + "：" + nm;
      downloadOne(it, nm, null, "batch", (r) => {
        if (r && r.err) failed.push(nm + "（" + r.err + "）");
        else ok++;
        i++;
        step();
      });
    };
    step();
  };
}

// 调试视图：显示页面所有网络请求
let debugMode = false;
document.getElementById("debug").onclick = () => {
  debugMode = !debugMode;
  document.getElementById("debug").textContent = debugMode ? "返回文件" : "调试请求";
  refresh();
};

function refresh() {
  if (debugMode) {
    chrome.runtime.sendMessage({ action: "getDebug" }, (r) => {
      const list = (r ? r.list : []).map((d) => ({
        url: d.url,
        info: (d.status || "") + " · " + (d.len ? (d.len / 1024).toFixed(0) + "KB" : d.ct || ""),
        time: d.time,
      }));
      listEl.innerHTML = "";
      if (!list.length) {
        listEl.innerHTML = '<div class="empty">暂无请求记录。请先操作页面（刷新/打开预览），再打开此面板。</div>';
        return;
      }
      list.forEach((it) => {
        const div = document.createElement("div");
        div.className = "item";
        div.innerHTML = `<div class="url" style="color:#1a56db">${it.info}</div><div class="url">${it.url}</div><div class="url">${new Date(it.time).toLocaleTimeString()}</div>`;
        listEl.appendChild(div);
      });
    });
    return;
  }
  chrome.runtime.sendMessage({ action: "getList" }, (r) => render(r ? r.list : []));
}

document.getElementById("clear").onclick = () =>
  chrome.runtime.sendMessage({ action: "clear" }, refresh);

document.getElementById("opts").onclick = () => chrome.runtime.openOptionsPage();

refresh();
