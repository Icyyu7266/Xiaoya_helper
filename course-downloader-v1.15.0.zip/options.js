// 设置页逻辑：读取/保存各项设置
// 规范化逻辑抽成纯函数（normalize / sanitizeHosts），便于在 Node 下单测
(function () {
  "use strict";

  const DEFAULTS = {
    // 捕获范围
    captureScoped: true,
    strictCapture: true,
    extraHosts: "",
    // 预览与命名
    autoConfirm: false,
    autoRename: true,
    // 视频
    videoAutoplay: true,
    videoKeepMuted: false,
    videoScope: "site",
    videoResume: true,
  };

  /* ===== 纯逻辑：把 storage 里的值规范成表单可用值 ===== */
  function normalize(d) {
    const o = d || {};
    return {
      captureScoped: o.captureScoped !== false,
      strictCapture: o.strictCapture !== false,
      extraHosts: sanitizeHosts(o.extraHosts),
      autoConfirm: o.autoConfirm === true,
      autoRename: o.autoRename !== false,
      videoAutoplay: o.videoAutoplay !== false,
      videoKeepMuted: o.videoKeepMuted === true,
      videoScope: o.videoScope === "all" ? "all" : "site",
      videoResume: o.videoResume !== false,
    };
  }

  // 站点列表规范化：每行一个，去协议/路径/端口，去重，丢弃非法项
  function sanitizeHosts(text) {
    const lines = String(text == null ? "" : text).split(/[\r\n,;]+/);
    const out = [];
    const seen = new Set();
    for (let raw of lines) {
      let s = String(raw || "").trim();
      if (!s) continue;
      s = s.replace(/^[a-zA-Z]+:\/\//, "").replace(/[/?#:].*$/, "").toLowerCase();
      s = s.replace(/^\*\./, "*.");
      if (!s) continue;
      if (!/^(\*\.)?[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/.test(s)) continue;
      if (seen.has(s)) continue;
      seen.add(s);
      out.push(s);
    }
    return out.join("\n");
  }

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { DEFAULTS, normalize, sanitizeHosts };
  }
  if (typeof document === "undefined") return; // Node 环境只导出纯函数

  /* ===== 浏览器接线 ===== */
  const FIELDS = [
    ["captureScoped", "checkbox"],
    ["strictCapture", "checkbox"],
    ["extraHosts", "value"],
    ["autoConfirm", "checkbox"],
    ["autoRename", "checkbox"],
    ["videoAutoplay", "checkbox"],
    ["videoKeepMuted", "checkbox"],
    ["videoScope", "value"],
    ["videoResume", "checkbox"],
  ];

  const $ = (id) => document.getElementById(id);
  let stateTimer = null;

  function flashState(text) {
    const el = $("state");
    const t = $("stateText");
    if (t) t.textContent = text || "设置已自动保存";
    if (!el) return;
    el.classList.add("show");
    clearTimeout(stateTimer);
    stateTimer = setTimeout(() => el.classList.remove("show"), 1500);
  }

  function applyToForm(cfg) {
    FIELDS.forEach(([id, kind]) => {
      const el = $(id);
      if (!el) return;
      if (kind === "checkbox") el.checked = !!cfg[id];
      else el.value = cfg[id];
    });
  }

  function readForm() {
    const raw = {};
    FIELDS.forEach(([id, kind]) => {
      const el = $(id);
      if (!el) return;
      raw[id] = kind === "checkbox" ? el.checked : el.value;
    });
    return normalize(raw);
  }

  function save(showTip) {
    const cfg = readForm();
    // 保存前把站点列表回写为规范化结果，避免用户看到与实际不一致的内容
    const ta = $("extraHosts");
    if (ta) ta.value = cfg.extraHosts;
    try {
      chrome.storage.local.set(cfg, () => {
        if (showTip) flashState("已保存");
      });
    } catch (e) {}
  }

  function load() {
    try {
      // 版本号显示
      try {
        const m = chrome.runtime.getManifest();
        if (m && $("ver")) $("ver").textContent = "版本 " + m.version;
      } catch (e) {}
      chrome.storage.local.get(DEFAULTS, (d) => applyToForm(normalize(d)));
    } catch (e) {
      applyToForm(normalize(DEFAULTS));
    }
  }

  // 改动即保存（与旧版一致）
  FIELDS.forEach(([id]) => {
    const el = $(id);
    if (!el) return;
    el.addEventListener("change", () => save(true));
  });
  // 文本域失焦时规范化并保存
  const ta = $("extraHosts");
  if (ta) ta.addEventListener("blur", () => save(false));

  const saveBtn = $("save");
  if (saveBtn) saveBtn.addEventListener("click", () => save(true));

  const resetBtn = $("reset");
  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      applyToForm(normalize(DEFAULTS));
      save(true);
      flashState("已恢复默认");
    });
  }

  load();
})();