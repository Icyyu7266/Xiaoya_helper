// 后台：监听所有网络请求，只捕获「课程学习页面上下文中的课件」
// 识别规则统一来自 scope.js（与 content.js / main.js 共用同一份判定，避免各处正则不一致）
importScripts("scope.js");
const S = self.CDScope;

let captured = []; // {url, type, time, from}
let reqHeaders = new Map(); // url -> 页面发出的请求头（含 token）
let nameMap = {}; // ID -> 文件名（主世界收割，全局共享）
let transMaps = {}; // 视频转码文件名 -> 课程资源真名
let videoIdMaps = {}; // 阿里云videoId(32hex) -> 课程资源真名（HLS 源播放链路只有 videoId）

// 捕获范围设置：默认只捕获课程学习页面，严格拒绝非课件类型
let strictMode = true;
let extraHosts = "";
let captureScoped = true;
try {
  chrome.storage.local.get({ strictCapture: true, extraHosts: "", captureScoped: true }, (d) => {
    strictMode = d.strictCapture !== false;
    extraHosts = d.extraHosts || "";
    captureScoped = d.captureScoped !== false;
  });
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.strictCapture) strictMode = ch.strictCapture.newValue !== false;
    if (ch.extraHosts) extraHosts = ch.extraHosts.newValue || "";
    if (ch.captureScoped) captureScoped = ch.captureScoped.newValue !== false;
  });
} catch (e) {}

// 调试日志：记录所有请求的响应头信息（含被规则过滤的资源）
// 在使用它的 addFile / reportReject 之前声明，避免暂时性死区
let debugLog = [];

// 标签页 → 是否学习页面（带短缓存，避免每个请求都查标签页）
const learningTabs = new Map(); // tabId -> {v:boolean, t:number}
const LEARNING_TTL = 5000;

function isLearningTab(tabId) {
  if (!captureScoped) return true; // 用户显式关闭范围限制时退回全站（默认不关闭）
  if (tabId == null || tabId < 0) return false;
  const c = learningTabs.get(tabId);
  const now = Date.now();
  if (c && now - c.t < LEARNING_TTL) return c.v;
  try {
    chrome.tabs.get(tabId, (t) => {
      let v = false;
      try {
        if (t && t.url) v = S.isLearningPage(t.url, [], "", extraHosts);
      } catch (e) {}
      learningTabs.set(tabId, { v, t: Date.now() });
    });
  } catch (e) {}
  // 缓存未命中时保守返回 false（宁可漏捕，不误捕）；同一次请求的头/体阶段已会刷新缓存
  return c ? c.v : false;
}

// 统一判定入口：URL + MIME + 下载头文件名 + 页面上下文
function judge(url, mime, tabId, hint) {
  try {
    if (!S) return { ok: false, reason: "规则模块未加载" };
    if (!S.looksCourseLike(url, mime, hint)) return { ok: false, reason: "预筛排除" };
    return S.classifyResource({
      url,
      mime,
      filenameHint: hint,
      learning: isLearningTab(tabId),
      strict: strictMode,
    });
  } catch (e) {
    return { ok: false, reason: "判定异常" };
  }
}

// 用映射表为 URL 里的 ID 找文件名；视频转码名（UUID-xx.mp4）查 transMaps
function mapName(url) {
  if (!url) return "";
  for (const [id, nm] of Object.entries(nameMap)) {
    if (url.includes(id)) return nm;
  }
  try {
    const tail = decodeURIComponent(url.split("?")[0].split("/").pop() || "");
    if (transMaps[tail]) return transMaps[tail];
  } catch (e) {}
  return "";
}
// 数字名/无名条目回溯改名（视频转码名优先用 transMaps 强制改名）
function applyName(it) {
  try {
    const tail = decodeURIComponent((it.url || "").split("?")[0].split("/").pop() || "");
    if (tail && transMaps[tail]) {
      it.name = transMaps[tail];
      return;
    }
  } catch (e) {}
  // 截获条目名字以 19 位 qid 开头（如 7066..._7066....pdf）→ 用映射表换真名（保留实际格式扩展名）
  const qm = /^(\d{10,})/.exec(it.name || "");
  if (qm && nameMap[qm[1]]) {
    const real = nameMap[qm[1]];
    const realBase = real.replace(/\.(pptx?|docx?|xlsx?|pdf|zip)$/i, "");
    const curExt = (it.name.match(/\.[a-z0-9]{2,5}$/i) || [""])[0];
    const origExt = (real.match(/\.[a-z0-9]{2,5}$/i) || [""])[0];
    // 截获的是转码 PDF 版：名字用真名 + .pdf；若截获扩展名与原格式一致则直接用真名
    it.name = /^\.pdf$/i.test(curExt) && !/^\.pdf$/i.test(origExt) ? realBase + ".pdf" : real;
    return;
  }
  if (it.name && /\.[a-z0-9]{2,5}$/i.test(it.name) && !/^\d{8,}[_.]/.test(it.name)) return;
  const nm = mapName(it.url);
  if (nm) it.name = nm;
}
function refreshNames() {
  captured.forEach(applyName);
  save();
}

// 启动时恢复（清除 file_url 接口误存条目与旧版 pdfv 构造残留）
chrome.storage.local.get({ captured: [] }, (d) => {
  captured = (d.captured || []).filter(
    (c) =>
      c.dataUrl ||
      (/^https?:\/\//i.test(c.url || "") &&
        !/cloud\/file_url\//i.test(c.url) &&
        !/x1\.ow365\.cn\/pdfv\//i.test(c.url))
  );
});

function save() {
  // 只保留最近 200 条
  captured = captured.slice(-200);
  chrome.storage.local.set({ captured });
}

function addFile(url, from, name, tabId) {
  // 只接受合法网络地址
  if (!url || !/^https?:\/\//i.test(url)) return;
  // 这几个接口返回 JSON 元数据，不是文件本体（即使查询串以 .pdf 结尾也不捕获）
  if (/cloud\/file_url\/|queryResource|queryCourseResources|aliyuncs\.com\/\?Action=GetPlayInfo/i.test(url)) return;
  // pdfv 地址本体不可直抓（会话绑定），数据走 CD_CAPTURE dataUrl 通道，不存 URL 条目
  if (/x1\.ow365\.cn\/pdfv\//i.test(url)) return;

  // 统一规则判定：必须是课件类型，且处于课程学习页面上下文
  const mime = String(from || "");
  let hint = name || "";
  if (!hint && /[?&]f=/.test(url)) {
    try { hint = S.decodePdfvName(url) || ""; } catch (e) {}
  }
  const judged = judge(url, mime, tabId, hint);
  if (!judged.ok) {
    reportReject(url, judged.reason); // 调试面板可见：便于确认"没误捕"
    return;
  }

  const known = captured.find((c) => c.url === url);
  if (known) {
    if (name && (!known.name || /^\d{8,}\./.test(known.name))) known.name = name;
    save();
    return;
  }
  captured.push({
    url,
    type: S.kindFromExt(judged.ext),
    time: Date.now(),
    from: mime || "",
    name: name || "",
  });
  const it = captured[captured.length - 1];
  if (!name) applyName(it);
  // 视频条目（mp4/m3u8）按稳定 key 去重：同一视频重复播放/签名刷新只更新地址，不新增条目
  const vk = videoKey(url);
  if (vk) {
    const dup = captured.find((c) => c !== it && videoKey(c.url) === vk);
    if (dup) {
      dup.url = url; // 刷新为最新签名地址（利于下载）
      captured = captured.filter((c) => c !== it);
      save();
      return;
    }
    // 进入配对队列，与最近的 vod/duration/<资源ID> 严格一对一配对
    videoTailQ.push({ tail: vk, t: Date.now() });
    tryPairVideos();
    dedupeVideos();
  }
  save();
}

// 被规则拒绝的资源记入调试面板（限流，避免刷屏）
const rejectedSeen = new Set();
function reportReject(url, reason) {
  try {
    const key = url.split("?")[0].slice(0, 120) + "|" + reason;
    if (rejectedSeen.has(key)) return;
    rejectedSeen.add(key);
    if (rejectedSeen.size > 400) rejectedSeen.clear();
    debugLog.push({ url: url.slice(0, 150), ct: "已过滤: " + reason, len: 0, time: Date.now(), status: "SKIP" });
    if (debugLog.length > 300) debugLog = debugLog.slice(-300);
  } catch (e) {}
}

// 同一视频可能同时以 mp4 与 m3u8 双源被捕获（配对后名字相同），合并保留更优格式
function dedupeVideos() {
  const prio = (c) => (c.name ? 100 : 0) + (c.type === "视频" ? 10 : 0);
  const groups = {};
  for (const c of captured) {
    if (c.type !== "视频" && c.type !== "视频HLS") continue;
    const nm = (c.name || "").replace(/\.[a-z0-9]{2,5}$/i, "").trim();
    if (!nm) continue;
    if (!groups[nm] || prio(c) > prio(groups[nm])) {
      if (groups[nm]) captured = captured.filter((x) => x !== groups[nm]);
      groups[nm] = c;
    } else {
      captured = captured.filter((x) => x !== c);
    }
  }
}

// 视频条目稳定 key：mp4 用转码文件名，m3u8 用目录/文件（index.m3u8 多视频重名，需带目录）
function videoKey(url) {
  try {
    const path = decodeURIComponent((url || "").split("?")[0]);
    if (/\.mp4$/i.test(path) && /vod\.ai-augmented\.com/i.test(url)) return path.split("/").pop();
    if (/\.m3u8$/i.test(path) && /vod|m3u8|video/i.test(url)) {
      const segs = path.split("/").filter(Boolean);
      return segs.slice(-2).join("/");
    }
  } catch (e) {}
  return "";
}

// 视频资源配对：duration/<资源ID>、play_auth/<阿里云videoId> 与 mp4/m3u8 播放请求前后脚出现，一对一队列配对
const VIDEO_ID_RE = /\/vod\/(?:duration|info|play|playinfo)[^/]*\/(\d{10,})|\/play_auth\/([0-9a-f]{16,40})|[?&](?:resource_id|resourceId|file_id|fileId|quote_id)=(\d{10,})/;
let videoIdQ = []; // {id, t}
let videoTailQ = []; // {tail, t}

function tryPairVideos() {
  const now = Date.now();
  // 挂起保留 2 分钟（映射晚到也能补上），配对窗口 30 秒
  videoIdQ = videoIdQ.filter((x) => now - x.t < 120000);
  videoTailQ = videoTailQ.filter((x) => now - x.t < 120000);
  while (
    videoIdQ.length &&
    videoTailQ.length &&
    Math.abs(videoIdQ[0].t - videoTailQ[0].t) < 30000
  ) {
    const { id } = videoIdQ.shift();
    const { tail } = videoTailQ.shift();
    const nm = nameMap[id] || videoIdMaps[id];
    if (nm && !transMaps[tail]) {
      transMaps[tail] = nm;
      captured.forEach((c) => {
        if (videoKey(c.url) === tail) c.name = nm;
      });
      dedupeVideos();
      save();
    }
  }
}

function guessType(url) {
  // 类型名交给统一规则（scope.js），保证与捕获判定一致
  try {
    if (S) return S.kindFromExt(S.extFromPath(url));
  } catch (e) {}
  if (/\.pdf(\?|$)/i.test(url)) return "PDF";
  if (/\.pptx?(\?|$)/i.test(url)) return "PPT";
  if (/\.docx?(\?|$)/i.test(url)) return "Word";
  if (/\.xlsx?(\?|$)/i.test(url)) return "Excel";
  if (/\.(mp4)(\?|$)/i.test(url)) return "视频";
  if (/\.m3u8(\?|$)/i.test(url)) return "视频HLS";
  return "文件";
}

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const h = details.responseHeaders || [];
    const get = (n) => (h.find((x) => x.name.toLowerCase() === n) || {}).value || "";
    const mime = get("content-type");
    // 从下载头提取真实文件名，作为课件类型判定线索
    let hint = "";
    const cd = get("content-disposition");
    if (cd) {
      const m = /filename\*?=(?:UTF-8''|")?([^";]+)/i.exec(cd);
      if (m) {
        try { hint = decodeURIComponent(m[1].replace(/"/g, "")); } catch (e) { hint = m[1].replace(/"/g, ""); }
      }
    }
    addFile(details.url, mime, hint, details.tabId);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    // 视频资源 ID 请求（/vod/duration/<ID> 等）进入配对队列
    const vm = VIDEO_ID_RE.exec(details.url);
    if (vm) {
      videoIdQ.push({ id: vm[1] || vm[2], t: Date.now() });
      tryPairVideos();
      return;
    }
    // 永中 OW365 PDF 数据端点：f 参数 base64 解码即原始文件名（作为判定线索）
    let hint = "";
    const m = /x1\.ow365\.cn\/pdfv\/f\?f=([^&]+)/.exec(details.url);
    if (m) {
      try {
        let b64 = decodeURIComponent(m[1]).replace(/--$/, "==").replace(/-/g, "+").replace(/_/g, "/");
        const dec = atob(b64);
        hint = dec.split("\\").pop().split("/").pop() || "";
      } catch (e) {}
    }
    addFile(details.url, "", hint, details.tabId);
  },
  { urls: ["<all_urls>"] }
);

// 记录页面发起请求时的请求头（token / Authorization 等）；无条件记录，下载时再匹配
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (details.requestHeaders && details.requestHeaders.length) {
      reqHeaders.set(details.url, details.requestHeaders);
      const base = details.url.split("?")[0];
      if (base !== details.url) reqHeaders.set(base, details.requestHeaders);
      if (reqHeaders.size > 300) reqHeaders.delete(reqHeaders.keys().next().value);
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders"]
);

// 从 Content-Disposition / Content-Type 推断文件名
function pickName(url, headers) {
  const get = (n) => (headers.find((h) => h.name.toLowerCase() === n) || {}).value || "";
  let cd = get("content-disposition");
  let m = /filename\*?=(?:UTF-8''|")?([^";]+)/i.exec(cd);
  if (m) {
    try { return decodeURIComponent(m[1].replace(/"/g, "")); } catch (e) { return m[1].replace(/"/g, ""); }
  }
  const ct = get("content-type");
  const extMap = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/vnd.ms-powerpoint": ".ppt",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/msword": ".doc",
    "application/zip": ".zip",
  };
  const ext = extMap[ct.split(";")[0].trim()] || "";
  const base = decodeURIComponent(url.split("/").pop().split("?")[0] || "file");
  return ext && !base.toLowerCase().endsWith(ext) ? base + ext : base || "file" + ext;
}

// 调试日志声明已提前到文件前部（见文件开头），此处不再重复声明
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const h = details.responseHeaders || [];
    const get = (n) => (h.find((x) => x.name.toLowerCase() === n) || {}).value || "";
    // 跳过静态资源噪音
    const url = details.url;
    if (/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff2?|ttf|map)(\?|$)/i.test(url)) return;
    const len = parseInt(get("content-length")) || 0;
    debugLog.push({ url, ct: get("content-type"), len, time: Date.now(), status: details.statusCode });
    if (debugLog.length > 300) debugLog = debugLog.slice(-300);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

// 与 popup / content 通信
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getList") {
    sendResponse({ list: captured.slice().reverse() });
  } else if (msg.action === "getDebug") {
    sendResponse({ list: debugLog.slice().reverse() });
  } else if (msg.action === "clearDebug") {
    debugLog = [];
    sendResponse({ ok: true });
  } else if (msg.action === "clear") {
    captured = [];
    save();
    sendResponse({ ok: true });
  } else if (msg.action === "download") {
    try { new URL(msg.url); } catch (e) {
      sendResponse({ err: "URL无效: " + String(msg.url).slice(0, 120) });
      return true;
    }
    chrome.downloads.download({ url: msg.url, saveAs: msg.saveAs !== false }, (id) =>
      sendResponse({ id, err: chrome.runtime.lastError?.message })
    );
    return true;
  } else if (msg.action === "fetchDownload") {
    try { new URL(msg.url); } catch (e) {
      sendResponse({ err: "URL无效: " + String(msg.url).slice(0, 120) });
      return true;
    }
    // 用页面原始请求头（含 token / Referer 防盗链）+ cookie 抓取文件
    const headers = {};
    (reqHeaders.get(msg.url) || reqHeaders.get(msg.url.split("?")[0]) || []).forEach((h) => {
      if (!/^(host|content-length|origin|cookie)$/i.test(h.name)) headers[h.name] = h.value;
    });
    // ow365 端点有防盗链：无记录头时补 Referer
    if (/x1\.ow365\.cn/.test(msg.url) && !headers.Referer) headers.Referer = "https://x1.ow365.cn/";
    fetch(msg.url, { credentials: "include", headers })
      .then(async (r) => {
        if (!r.ok) {
          const t = await r.text().catch(() => "");
          throw new Error("HTTP " + r.status + " " + (new URL(msg.url).host) + " : " + t.slice(0, 180));
        }
        return { blob: await r.blob(), headers: [...r.headers.entries()] };
      })
      .then(async ({ blob, headers: hentries }) => {
        // 魔数校验：PDF=%PDF，Office/ZIP=PK，MP4=ftyp；不匹配则为错误响应
        const head = new Uint8Array(await blob.slice(0, 8).arrayBuffer());
        const sig = Array.from(head).map((b) => String.fromCharCode(b)).join("");
        const magicOk = sig.startsWith("%PDF") || sig.startsWith("PK") || /^.{4}ftyp/.test(sig) || sig.startsWith("\x1f\x8b");
        const ct = (hentries.find(([n, v]) => n.toLowerCase() === "content-type") || [])[1] || "";
        if (!magicOk) {
          const text = await blob.slice(0, 400).text();
          throw new Error(`响应不是有效文件 (${ct || "未知类型"}, ${blob.size}B): ` + text.slice(0, 200));
        }
        const hdrs = hentries.map(([name, value]) => ({ name, value }));
        const name = pickName(msg.url, hdrs) || msg.filename || "file";
        const dataUrl = await new Promise((res, rej) => {
          const fr = new FileReader();
          fr.onload = () => res(fr.result);
          fr.onerror = rej;
          fr.readAsDataURL(blob);
        });
        chrome.downloads.download(
          { url: dataUrl, filename: name, saveAs: msg.saveAs !== false },
          (id) => sendResponse({ id, err: chrome.runtime.lastError?.message })
        );
      })
      .catch((e) => sendResponse({ err: String(e.message || e) }));
    return true;
  } else if (msg.action === "downloadData") {
    // 接收页面主世界抓到的 base64 数据并保存
    chrome.downloads.download(
      { url: msg.dataUrl, filename: msg.filename || "file", saveAs: msg.saveAs !== false },
      (id) => sendResponse({ id, err: chrome.runtime.lastError?.message })
    );
    return true;
  } else if (msg.action === "saveCaptured") {
    // 保存主世界自动捕获的文件（带 dataUrl，可直接保存到磁盘）
    // 主世界只截获 %PDF/PK 魔数内容，这里再确认请求来源属于学习页面
    let learnTab = true;
    try {
      if (captureScoped && sender && sender.tab && sender.tab.url) {
        learnTab = S.isLearningPage(sender.tab.url, [], "", extraHosts);
      }
    } catch (e) {}
    if (!learnTab) {
      reportReject("data:" + (msg.name || ""), "不在课程学习页面上下文");
      sendResponse({ ok: false, reason: "范围外" });
      return true;
    }
    if (!captured.some((c) => c.dataUrl && c.name === msg.name && c.size === msg.size)) {
      const entry = {
        name: msg.name,
        type: guessType(msg.name),
        size: msg.size || 0,
        time: Date.now(),
        url: "捕获: " + msg.name,
        dataUrl: "data:application/octet-stream;base64," + msg.b64,
      };
      applyName(entry);
      captured.push(entry);
      save();
    }
    sendResponse({ ok: true });
  } else if (msg.action === "debugNote") {
    debugLog.push({ url: msg.text, ct: "调试", len: 0, time: Date.now(), status: "MAP" });
    if (debugLog.length > 300) debugLog = debugLog.slice(-300);
    sendResponse({ ok: true });
  } else if (msg.action === "rename") {
    // 手动改名（按捕获时间定位条目）
    const it = captured.find((c) => c.time === msg.time);
    if (it) it.name = msg.name;
    save();
    sendResponse({ ok: true });
  } else if (msg.action === "nameMaps") {
    // 主世界同步的 ID→文件名映射 + 视频转码名映射 + 阿里云 videoId 映射，合并后回溯改名
    nameMap = Object.assign({}, nameMap, msg.maps || {});
    transMaps = Object.assign({}, transMaps, msg.transMaps || {});
    videoIdMaps = Object.assign({}, videoIdMaps, msg.videoMaps || {});
    refreshNames();
    tryPairVideos();
    sendResponse({ ok: true });
  } else if (msg.action === "reportFile") {
    // 由 content script 上报发现的课件链接（可带真实文件名）
    // 上报者已在学习页面上下文，但仍过一次统一规则，保证后台是唯一裁决点
    let tabId = -1;
    try { tabId = sender && sender.tab ? sender.tab.id : -1; } catch (e) {}
    addFile(msg.url, msg.mime || "", msg.name || "", tabId);
    sendResponse({ ok: true });
  } else if (msg.action === "getScopeStats") {
    sendResponse({ ok: true, captured: captured.length, filtered: debugLog.filter((d) => d.status === "SKIP").length });
  }
});
