// 视频自动播放并静音：进入含视频的课程页时，自动把播放器静音并开始播放
// 说明：静音(muted)后浏览器才允许无用户手势的自动播放；用户手动暂停后不再抢播。
//       设置项：videoAutoplay（默认开）、videoKeepMuted（默认关）、videoScope（默认 site）。
(function () {
  "use strict";

  // ===================== 纯逻辑（可在 Node 下直接单测） =====================
  const DEFAULTS = { videoAutoplay: true, videoKeepMuted: false, videoScope: "site" };
  // 课程平台及其播放器域名（小雅：whut.ai-augmented.com、vod.ai-augmented.com …）
  const SITE_HOST_RE = /(^|\.)ai-augmented\.com$/i;
  const MAX_ATTEMPTS = 8; // 元素出现后最多尝试 8 次（约 10 秒内），避免无限重试
  const PLAYER_INIT_PAUSE_MS = 1500; // 播放成功后的这段时间内的 pause 视为播放器初始化，可补播一次

  function hostOf(urlLike) {
    try {
      return new URL(urlLike).hostname.toLowerCase();
    } catch (e) {
      return "";
    }
  }

  // scope: "site"（仅课程平台及其嵌框架）| "all"（所有网站）
  function siteAllowed(host, ancestorOrigins, scope) {
    if (scope === "all") return true;
    const h = String(host || "").toLowerCase();
    if (SITE_HOST_RE.test(h)) return true;
    const list = ancestorOrigins || [];
    for (let i = 0; i < list.length; i++) {
      if (SITE_HOST_RE.test(hostOf(list[i]))) return true;
    }
    return false;
  }

  // opts: { siteOk, alreadyHandled, userStopped }
  function shouldAutoPlay(settings, opts) {
    if (!settings || settings.videoAutoplay !== true) return false;
    if (!opts || opts.siteOk !== true) return false;
    if (opts.alreadyHandled === true || opts.userStopped === true) return false;
    return true;
  }

  function retryDelay(attempt) {
    const n = Math.max(0, Number(attempt) || 0);
    return Math.min(Math.round(900 * Math.pow(1.25, n - 1)) || 900, 3000);
  }

  function shouldRetry(attempt, maxAttempts) {
    return (Number(attempt) || 0) < (maxAttempts || MAX_ATTEMPTS);
  }

  function pauseIsUserStop(msSincePlayed) {
    return (Number(msSincePlayed) || 0) > PLAYER_INIT_PAUSE_MS;
  }

  const API = {
    DEFAULTS: DEFAULTS,
    SITE_HOST_RE: SITE_HOST_RE,
    MAX_ATTEMPTS: MAX_ATTEMPTS,
    PLAYER_INIT_PAUSE_MS: PLAYER_INIT_PAUSE_MS,
    hostOf: hostOf,
    siteAllowed: siteAllowed,
    shouldAutoPlay: shouldAutoPlay,
    retryDelay: retryDelay,
    shouldRetry: shouldRetry,
    pauseIsUserStop: pauseIsUserStop,
  };

  // Node 测试环境：只导出纯逻辑，不接管 window/document
  if (typeof window === "undefined" || typeof document === "undefined") {
    if (typeof module !== "undefined" && module.exports) module.exports = API;
    return;
  }
  if (window.__cdVideoAutoplayLoaded) return;
  window.__cdVideoAutoplayLoaded = true;

  // ===================== 浏览器接线 =====================
  let settings = Object.assign({}, DEFAULTS);
  const handled = new WeakSet(); // 已自动播放过
  const userStopped = new WeakSet(); // 用户手动暂停过 → 不再干预
  const hooked = new WeakSet(); // 已绑定事件
  const states = new WeakMap(); // video -> {attempts, pending, playedAt}

  function normalizeSettings(d) {
    const o = d || {};
    return {
      videoAutoplay: o.videoAutoplay !== false,
      videoKeepMuted: o.videoKeepMuted === true,
      videoScope: o.videoScope === "all" ? "all" : "site",
    };
  }

  function loadSettings(cb) {
    try {
      chrome.storage.local.get(DEFAULTS, (d) => {
        settings = normalizeSettings(d);
        cb && cb();
      });
      chrome.storage.onChanged.addListener((ch) => {
        if (!ch || (!ch.videoAutoplay && !ch.videoKeepMuted && !ch.videoScope)) return;
        try {
          chrome.storage.local.get(DEFAULTS, (d) => {
            settings = normalizeSettings(d);
            scan();
          });
        } catch (e) {}
      });
    } catch (e) {
      cb && cb();
    }
  }

  function siteOkNow() {
    let ancestor = [];
    try {
      ancestor = Array.prototype.slice.call(location.ancestorOrigins || []);
    } catch (e) {}
    return siteAllowed(location.hostname, ancestor, settings.videoScope);
  }

  // 含 open shadow root（部分播放器把 <video> 放在影子树里）
  function collectVideos() {
    const set = new Set();
    try {
      document.querySelectorAll("video").forEach((v) => set.add(v));
    } catch (e) {}
    try {
      (function walk(root) {
        const all = root.querySelectorAll("*");
        for (let i = 0; i < all.length; i++) {
          const el = all[i];
          if (el.tagName === "VIDEO") set.add(el);
          if (el.shadowRoot) walk(el.shadowRoot);
        }
      })(document);
    } catch (e) {}
    return Array.from(set);
  }

  function enforceMute(v, strong) {
    try {
      if (!v.muted) v.muted = true;
    } catch (e) {}
    try {
      if (!v.hasAttribute("muted")) v.setAttribute("muted", "");
    } catch (e) {}
    if (strong) {
      try {
        if (v.volume > 0) v.volume = 0;
      } catch (e) {}
    }
  }

  function getState(v) {
    let st = states.get(v);
    if (!st) {
      st = { attempts: 0, pending: false, playedAt: 0 };
      states.set(v, st);
    }
    return st;
  }

  function attemptPlay(v) {
    const st = getState(v);
    if (!settings.videoAutoplay || userStopped.has(v)) return;
    if (st.playedAt || st.pending) return;
    if (!shouldRetry(st.attempts, MAX_ATTEMPTS)) return;
    st.attempts++;
    st.pending = true;
    enforceMute(v, settings.videoKeepMuted);

    let p = null;
    try {
      p = v.play();
    } catch (e) {
      p = null;
    }
    const done = (ok) => {
      st.pending = false;
      if (ok) {
        st.playedAt = Date.now();
        return;
      }
      if (st.playedAt || userStopped.has(v) || !settings.videoAutoplay) return;
      setTimeout(() => {
        if (v.isConnected) attemptPlay(v);
      }, retryDelay(st.attempts));
    };
    if (p && typeof p.then === "function") p.then(() => done(true), () => done(false));
    else done(!v.paused); // play() 同步返回时以实际暂停状态判断是否成功
  }

  // 播放器初始化阶段被自己暂停 → 只补一次，之后交给用户
  function nudge(v) {
    if (!settings.videoAutoplay || userStopped.has(v)) return;
    enforceMute(v, settings.videoKeepMuted);
    try {
      const p = v.play();
      if (p && typeof p.catch === "function") p.catch(() => {});
    } catch (e) {}
  }

  function hookVideo(v) {
    if (hooked.has(v)) return;
    hooked.add(v);
    ["loadedmetadata", "loadeddata", "canplay"].forEach((ev) => {
      try {
        v.addEventListener(ev, () => {
          const st = states.get(v);
          if (!st || st.playedAt || userStopped.has(v)) return;
          attemptPlay(v);
        });
      } catch (e) {}
    });
    try {
      v.addEventListener("pause", () => {
        const st = states.get(v);
        if (!st || !st.playedAt) return;
        if (pauseIsUserStop(Date.now() - st.playedAt)) {
          userStopped.add(v); // 用户主动暂停：不再自动播放
          return;
        }
        setTimeout(() => {
          if (v.paused) nudge(v);
        }, 500);
      });
    } catch (e) {}
    try {
      v.addEventListener("volumechange", () => {
        if (!settings.videoKeepMuted) return;
        if (!v.muted || v.volume > 0) enforceMute(v, true);
      });
    } catch (e) {}
  }

  function handle(v) {
    if (!v || !v.isConnected) return;
    hookVideo(v);
    if (settings.videoKeepMuted) enforceMute(v, true);
    if (!shouldAutoPlay(settings, {
      siteOk: siteOkNow(),
      alreadyHandled: handled.has(v),
      userStopped: userStopped.has(v),
    })) return;
    handled.add(v);
    enforceMute(v, settings.videoKeepMuted);
    attemptPlay(v);
  }

  let scanTimer = null;
  function scheduleScan() {
    if (scanTimer) return;
    scanTimer = setTimeout(() => {
      scanTimer = null;
      scan();
    }, 300);
  }

  function scan() {
    if (!settings.videoAutoplay && !settings.videoKeepMuted) return;
    if (!siteOkNow()) return; // 范围外一律不干预
    let vids;
    try {
      vids = collectVideos();
    } catch (e) {
      return;
    }
    for (let i = 0; i < vids.length; i++) handle(vids[i]);
  }

  try {
    new MutationObserver(scheduleScan).observe(document.documentElement || document, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["src"],
    });
  } catch (e) {}
  setInterval(scan, 2500); // SPA 切页 / 播放器后置创建兜底

  loadSettings(scan);
  scan();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scan);
    window.addEventListener("load", scan);
  }
})();