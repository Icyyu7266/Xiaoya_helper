/* CDLog —— 轻量事件日志（便于排查问题）
 * 设计：后台 Service Worker 是唯一持久化写入点（避免多上下文并发写 storage 的竞态）；
 *       内容脚本 / 弹窗通过 runtime 消息上报，后台统一落盘。
 * 纯逻辑（条目规范化 / 容量截断 / 级别过滤 / 导出文本）与浏览器接线分离，可在 Node 下单测。
 * 存储键：eventLogs；环形缓冲，默认最多 600 条，自动淘汰最旧的。
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  try {
    root.CDLog = api;
  } catch (e) {}
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const MAX_ENTRIES = 600;
  const FLUSH_MS = 900;
  const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

  function clampText(s, n) {
    s = String(s == null ? "" : s);
    n = n || 500;
    return s.length > n ? s.slice(0, n) + "…" : s;
  }

  function normLevel(lv) {
    const k = String(lv || "info").toLowerCase();
    return LEVELS[k] ? k : "info";
  }

  // 单条日志：{ t, lv, tag, msg }
  function makeEntry(lv, tag, msg, t) {
    return {
      t: Number(t) || Date.now(),
      lv: normLevel(lv),
      tag: clampText(tag, 20),
      msg: clampText(msg, 480),
    };
  }

  // 追加并按容量截断（返回新数组，避免调用方忘了 slice）
  function append(list, entry) {
    const out = (list || []).concat(entry);
    return out.length > MAX_ENTRIES ? out.slice(-MAX_ENTRIES) : out;
  }

  // 只保留级别 >= 指定级别的条目
  function minLevelFilter(list, lv) {
    const min = LEVELS[normLevel(lv)] || 0;
    return (list || []).filter((e) => e && (LEVELS[e.lv] || 0) >= min);
  }

  // 导出为可读文本（每行一条），用于复制 / 保存
  function toText(list) {
    const p = (n) => String(n).padStart(2, "0");
    return (list || [])
      .map((e) => {
        const d = new Date(e.t);
        const time =
          d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) +
          " " + p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds()) +
          "." + String(d.getMilliseconds()).padStart(3, "0");
        return "[" + time + "][" + String(e.lv).toUpperCase() + "][" + e.tag + "] " + e.msg;
      })
      .join("\r\n");
  }

  // 有效性过滤（存储恢复时剔除坏数据）
  function isValid(e) {
    return !!(e && typeof e.t === "number" && e.msg && LEVELS[e.lv]);
  }

  function sanitize(list) {
    return (list || []).filter(isValid).slice(-MAX_ENTRIES);
  }

  return {
    MAX_ENTRIES: MAX_ENTRIES,
    FLUSH_MS: FLUSH_MS,
    LEVELS: LEVELS,
    clampText: clampText,
    normLevel: normLevel,
    makeEntry: makeEntry,
    append: append,
    minLevelFilter: minLevelFilter,
    toText: toText,
    isValid: isValid,
    sanitize: sanitize,
  };
});