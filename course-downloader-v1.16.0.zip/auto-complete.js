/* 完成后自动提交 —— 仅在你确实读完/看完时才点击平台的"完成"按钮
 *
 * 目的：平台要求手动点"完成"才记录进度，忘记点就白读一遍。此模块在检测到
 *      「内容确实消费完」后替你点一次，避免切换页面或临时关闭后从头再来。
 *
 * 完成判定（必须满足其一，绝不凭"页面打开"就点）：
 *   · 视频：播放到结尾（ended，或 currentTime ≥ 时长-1 秒）
 *   · 文档：停留 ≥30 秒，且（主阅读区滚到 ≥95%，或内容本身不可滚动时停留 ≥60 秒）
 *
 * 明确不做：
 *   · 打开页面就点、定时盲点、点完自动切换下一个任务；
 *   · 点击语义不明或带取消/删除/重置字样的按钮。
 *
 * 设置项：autoComplete（默认开）；范围沿用 captureScoped / extraHosts。
 */
(function () {
  "use strict";

  /* ===================== 纯逻辑（Node 可测） ===================== */
  const DEFAULTS = { autoComplete: true };
  const MIN_DWELL_MS = 30 * 1000; // 文档最短停留
  const MIN_DWELL_NON_SCROLL_MS = 60 * 1000; // 不可滚动内容（单页文档）最短停留
  const MIN_SCROLL_RATIO = 0.95; // 主阅读区滚到底的判定线
  const VIDEO_END_TOLERANCE = 1.0; // 距结尾 1 秒内视为看完
  const CLICK_COOLDOWN_MS = 4000;
  const PROBE_AFTER_MS = 20 * 1000; // 进页面停留满 20 秒才做探明点击（不必等用户读完）

  // 按钮文案：只认语义明确的"完成"
  // 平台常见写法差异很大，例如「点我完成任务」「点击完成学习」「立即完成」，
  // 因此先剥掉前缀（点我/点击/立即/请/戳我），再比对核心词。
  const COMPLETE_LABEL_RE =
    /^(完成|完成学习|完成阅读|完成观看|完成任务|完成本节|完成本课|标记完成|标记为已完成|确认完成|已学完|提交|打卡)$/;
  const UNSAFE_LABEL_RE = /(取消|删除|重置|放弃|退出|返回|关闭|上一步|下一节|下一个|重新学习|重做)/;
  const PREFIX_RE = /^(点我|点击|立即|马上|请|戳我|点此|轻点)+/;

  function normLabel(text) {
    return String(text == null ? "" : text).replace(/\s+/g, "").trim();
  }

  // 去掉「点我/点击…」这类引导词
  function stripPrefix(text) {
    return normLabel(text).replace(PREFIX_RE, "");
  }

  // 是否是可点击的"完成"按钮文案
  function isCompleteLabel(text) {
    const raw = normLabel(text);
    if (!raw) return false;
    if (UNSAFE_LABEL_RE.test(raw)) return false;
    const t = stripPrefix(raw);
    if (!t) return false;
    if (t.length > 12) return false; // 太长多半是段落文案，不是按钮
    // 已是完成态则无需再点；但「标记为已完成」是动作，不能误排除
    if (t === "已完成") return false;
    if (/已完成$/.test(t) && !/^标记/.test(t)) return false;
    return COMPLETE_LABEL_RE.test(t);
  }

  // 视频是否确实看完
  function videoFinished(o) {
    const d = Number((o && o.duration) || 0);
    const t = Number((o && o.currentTime) || 0);
    if (o && o.ended === true) return true;
    if (d > 0 && t >= d - VIDEO_END_TOLERANCE) return true;
    return false;
  }

  // 文档是否确实读完
  function docReadyToSubmit(o) {
    const dwell = Number((o && o.dwellMs) || 0);
    const ratio = Number((o && o.scrollRatio) || 0);
    const scrollable = !!(o && o.scrollable);
    if (dwell < 0) return false;
    if (scrollable) {
      return dwell >= MIN_DWELL_MS && ratio >= MIN_SCROLL_RATIO;
    }
    // 内容不可滚动：无法用滚动证明，只能靠足够长的停留
    return dwell >= MIN_DWELL_NON_SCROLL_MS;
  }

  // 综合判定：任一完成信号成立即可
  function shouldSubmit(o) {
    if (!o) return false;
    if (o.videoFinished === true) return true;
    return docReadyToSubmit(o);
  }

  /* ---------- 阅读时长限制（老师设置的门槛） ---------- */
  // 平台常见文案：「需阅读 10 分钟」「至少学习 5 分钟」「10 分钟后可完成」
  //              「本资源最低学习时长 8 分钟」「剩余 04:32」
  const UNIT_MS = { "秒": 1000, "秒钟": 1000, "分": 60000, "分钟": 60000, "小时": 3600000 };
  const MAX_REQUIRED_MS = 180 * 60000; // 超过 3 小时视为解析异常，忽略

  function toMs(num, unit) {
    const n = Number(num);
    const u = UNIT_MS[String(unit || "").trim()];
    if (!isFinite(n) || n <= 0 || !u) return 0;
    return Math.round(n * u);
  }

  // 从页面文本里解析"必须满足的最短时长"；返回毫秒，解析不到返回 0
  function parseRequirement(text, activeMs) {
    const t = String(text == null ? "" : text).replace(/\s+/g, "");
    if (!t) return 0;
    const found = [];
    let m;

    // 1) 需 / 至少 / 不少于 / 最低 ... N 分钟
    const re1 = /(?:需|需要|必须|至少|不少于|最少|最低|满|达到)(?:阅读|学习|观看|浏览|停留|在线)?(?:时长|时间)?(?:不少于|至少|满|达到|超过)?(\d+(?:\.\d+)?)(秒钟|秒|分钟|分|小时)/g;
    while ((m = re1.exec(t)) !== null) {
      const v = toMs(m[1], m[2]);
      if (v) found.push(v);
    }

    // 2) N 分钟后（才可 / 即可 / 可）完成
    const re2 = /(\d+(?:\.\d+)?)(秒钟|秒|分钟|分|小时)后(?:即可|才能|方可|可以|可|能够|解锁)(?:完成|提交|确认|解锁)?/g;
    while ((m = re2.exec(t)) !== null) {
      const v = toMs(m[1], m[2]);
      if (v) found.push(v);
    }

    // 3) 剩余 mm:ss / 剩余 mm 分钟 —— 换算成"已用 + 剩余"
    const re3 = /剩余(?:时长|时间)?[:：]?(\d{1,2}):(\d{2})(?::(\d{2}))?/g;
    while ((m = re3.exec(t)) !== null) {
      let sec;
      if (m[3] != null) sec = (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]);
      else sec = (+m[1]) * 60 + (+m[2]);
      if (sec > 0) found.push((Number(activeMs) || 0) + sec * 1000);
    }
    const re4 = /剩余(?:时长|时间)?[:：]?(\d+(?:\.\d+)?)(秒钟|秒|分钟|分|小时)/g;
    while ((m = re4.exec(t)) !== null) {
      const v = toMs(m[1], m[2]);
      if (v) found.push((Number(activeMs) || 0) + v);
    }

    if (!found.length) return 0;
    const max = Math.max.apply(null, found);
    return max > MAX_REQUIRED_MS ? 0 : max;
  }

  // 何时可以点：完成信号已成立，且"有效停留"满足门槛（门槛取解析值与默认值中的较大者）
  function shouldClick(o) {
    if (!o) return false;
    if (o.completed !== true) return false; // 没完成信号绝不点
    const need = Math.max(Number(o.requiredMs) || 0, Number(o.minDefaultMs) || 0);
    return (Number(o.activeMs) || 0) >= need;
  }

  // 点了但平台没记录 → 隔一段时间再试（避免狂点）
  function nextRetryAt(now, intervalMs) {
    return (Number(now) || Date.now()) + (Number(intervalMs) || 60 * 1000);
  }

  /* ---------- 从"点击后的提示弹窗"学要求 ---------- */
  // 平台常见提示：
  //   「已学习 1 秒，连续观看时间未达要求，至少观看 2 分钟」
  //   「*刷新或离开页面将会重置任务计时。」
  // 这类任务的要求只出现在点击之后，所以第一次点击相当于"探明要求"。
  function parseWarning(text) {
    const t = String(text == null ? "" : text).replace(/\s+/g, "");
    const out = { requiredMs: 0, progressMs: 0, resetOnLeave: false, needsMore: false };
    if (!t) return out;
    let m;

    // 要求：「至少观看/学习/阅读 N 分钟」
    const reReq = /(?:至少|不少于|最少|最低)(?:连续)?(?:观看|学习|阅读|停留|在线)(?:时长|时间)?[:：]?(\d+(?:\.\d+)?)(秒钟|秒|分钟|分|小时)/g;
    while ((m = reReq.exec(t)) !== null) {
      const v = toMs(m[1], m[2]);
      if (v > out.requiredMs) out.requiredMs = v;
    }
    // 要求（另一种说法）：「需连续观看满 N 分钟」
    const reReq2 = /(?:需|需要)(?:连续)?(?:观看|学习|阅读)(?:满|不少于|至少|达到)?(\d+(?:\.\d+)?)(秒钟|秒|分钟|分|小时)/g;
    while ((m = reReq2.exec(t)) !== null) {
      const v = toMs(m[1], m[2]);
      if (v > out.requiredMs) out.requiredMs = v;
    }
    // 平台自己报的进度：「已学习 1 秒 / 已观看 2 分钟」
    const reProg = /已(?:学习|观看|阅读|在线)(?:了)?(?:时长|时间)?[:：]?(\d+(?:\.\d+)?)(秒钟|秒|分钟|分|小时)/g;
    while ((m = reProg.exec(t)) !== null) {
      const v = toMs(m[1], m[2]);
      if (v > out.progressMs) out.progressMs = v;
    }
    // 未达标 / 会重置
    out.needsMore = /(未达要求|未满足|未达到|不足|时长不够|请继续|请观看完|未观看完|请完整观看|请先观看|观看完成后)/.test(t);
    out.resetOnLeave = /(刷新|离开|关闭|切换页面).{0,14}(重置|重新计时|清零|从头)/.test(t);

    if (out.requiredMs > MAX_REQUIRED_MS) out.requiredMs = 0;
    return out;
  }

  // 下次尝试的时间：知道要求时，等到"剩余时间 + 缓冲"再点，避免没必要的点击
  function planNextAttempt(o) {
    const now = Number((o && o.now) || 0) || Date.now();
    const need = Number((o && o.requiredMs) || 0);
    const have = Number((o && o.progressMs) || 0);
    const gap = Number((o && o.minGapMs) || 15000);
    if (need > 0) {
      const remain = Math.max(0, need - have);
      return now + Math.max(gap, remain + 5000);
    }
    return now + Math.max(gap, 60000);
  }

  // 提示文案是否代表"还没完成"（出现要求或"未达要求"就一定没完成）
  function warningSaysIncomplete(text) {
    const w = parseWarning(text);
    if (w.needsMore || w.requiredMs > 0) return true;
    return /(未完成|未达要求|未达到|时长不足|不足\d|请继续阅读|请继续学习|请继续观看)/.test(
      String(text == null ? "" : text).replace(/\s+/g, "")
    );
  }

  // 是否是可用来"关掉弹窗"的按钮（不含完成按钮、不含取消）
  const DISMISS_LABEL_RE = /^(我知道了|知道了|我明白|明白|确定|好的|好|关闭|继续学习|继续观看|继续阅读)$/;
  function isDismissLabel(text) {
    const t = normLabel(text);
    if (!t) return false;
    if (isCompleteLabel(t)) return false; // 别把完成按钮当成关闭
    return DISMISS_LABEL_RE.test(t);
  }

  // 纯时间闸门：已知要求时，只看时长是否达标（不看滚动/播放等自有信号）
  function timeGateMet(o) {
    const need = Math.max(Number((o && o.requiredMs) || 0), Number((o && o.minDefaultMs) || 0));
    if (!(need > 0)) return false; // 没有门槛信息时保守不放行
    return Number((o && o.progressMs) || 0) >= need;
  }

  // 点了没成功之后，是否应当"等平台给出新读数"再点？
  // 平台可能比我们慢得多（例如页面停留 22 秒、平台只记了 1 秒），
  // 此时连续点击既没用又打扰人，不如等到新的读数或足够长的等待。
  function shouldWaitForFreshSample(o) {
    if (!o || o.needFresh !== true) return false;
    if (o.sampleSeq !== o.sampleSeqAtAttempt) return false; // 已有新读数 → 可以再判断
    const since = Number(o.sinceClickMs) || 0;
    const required = Number(o.requiredMs) || 0;
    const grace = Number(o.graceMs) || 30000;
    return since < required + grace;
  }

  // 选一个用于判定的"已学习进度"。
  // 默认信平台自报值（平台按自己的时钟校验）；但若平台的读数长期远低于我们
  // 实际可见停留（说明它的计时条件更严/根本不涨），就取两者较大者，避免永远等不到。
  function pickProgress(o) {
    const p = Number((o && o.platformMs) || 0);
    const a = Number((o && o.activeMs) || 0);
    const r = Number((o && o.requiredMs) || 0);
    if (!p) return a; // 平台没报过 → 用本地可见时长
    if (r > 0 && p < r && a >= r * 2) return Math.max(p, a); // 平台明显落后 → 用较大的
    return p;
  }

  /* ---------- 累计时长持久化（切换/关闭后不从头等） ---------- */
  const PROGRESS_PREFIX = "ac:";
  const PROGRESS_TTL_MS = 12 * 3600 * 1000; // 记录 12 小时内有效

  function progressKeyOf(pathname) {
    const p = String(pathname || "").split("?")[0].split("#")[0];
    return p ? PROGRESS_PREFIX + p : "";
  }

  // 取历史累计：同一页面、且未过期
  function usableSavedMs(saved, now, ttlMs) {
    if (!saved || typeof saved.ms !== "number" || saved.ms <= 0) return 0;
    const ttl = Number(ttlMs) || PROGRESS_TTL_MS;
    if (!saved.at || (Number(now) || Date.now()) - saved.at > ttl) return 0;
    return saved.ms;
  }

  const API = {
    DEFAULTS,
    MIN_DWELL_MS,
    MIN_DWELL_NON_SCROLL_MS,
    MIN_SCROLL_RATIO,
    VIDEO_END_TOLERANCE,
    CLICK_COOLDOWN_MS,
    MAX_REQUIRED_MS,
    PROBE_AFTER_MS,
    COMPLETE_LABEL_RE,
    UNSAFE_LABEL_RE,
    PREFIX_RE,
    normLabel,
    stripPrefix,
    isCompleteLabel,
    videoFinished,
    docReadyToSubmit,
    shouldSubmit,
    toMs,
    parseRequirement,
    shouldClick,
    nextRetryAt,
    parseWarning,
    planNextAttempt,
    warningSaysIncomplete,
    DISMISS_LABEL_RE,
    isDismissLabel,
    timeGateMet,
    shouldWaitForFreshSample,
    pickProgress,
    PROGRESS_TTL_MS,
    progressKeyOf,
    usableSavedMs,
  };

  if (typeof window === "undefined" || typeof document === "undefined") {
    if (typeof module !== "undefined" && module.exports) module.exports = API;
    return;
  }
  if (window.__cdAutoCompleteLoaded) return;
  window.__cdAutoCompleteLoaded = true;

  /* ===================== 浏览器接线 ===================== */
  const SCOPE = (typeof globalThis !== "undefined" && globalThis.CDScope) || null;
  let settings = Object.assign({}, DEFAULTS);
  let extraHosts = "";
  let captureScoped = true;

  const pageLoadedAt = Date.now();
  let done = false; // 平台已确认完成
  let probedOnce = false; // 是否已"点一次探明要求"
  let attempts = 0; // 已点击次数
  let nextAttemptAt = 0; // 下一次允许点击的时间
  let lastClickAt = 0;
  let maxScrollRatio = 0;
  let sawScrollable = false;
  let videoEndedRecently = false;

  // 有效停留时长：只在页面可见时累加（与平台"在线时长"口径一致）
  let activeMs = 0;
  let lastTickAt = Date.now();
  // 从页面文本解析出的时长门槛（毫米级刷新，避免每帧读整页文本）
  let requiredMs = 0;
  let requiredParsedAt = 0;
  let lastWaitLogAt = 0;

  const MAX_ATTEMPTS = 40; // 最多尝试次数
  const RETRY_INTERVAL_MS = 60 * 1000; // 点了没生效 → 60 秒后再试
  const REQUIREMENT_TTL_MS = 15 * 1000; // 时长要求的重新解析间隔

  function log(lv, msg) {
    try { chrome.runtime.sendMessage({ action: "logEvent", lv, tag: "自动完成", msg }); } catch (e) {}
  }

  function fmtDur(ms) {
    const s = Math.max(0, Math.round((Number(ms) || 0) / 1000));
    const m = Math.floor(s / 60);
    return m + ":" + String(s % 60).padStart(2, "0");
  }

  function tickActive() {
    const now = Date.now();
    const delta = now - lastTickAt;
    lastTickAt = now;
    if (delta <= 0 || delta > 60000) return; // 休眠/切走回来不正常累加
    try {
      if (document.visibilityState === "visible") {
        activeMs += delta;
        if (activeMs - lastPersistMs >= 30000) persistProgress();
      }
    } catch (e) {}
  }

  /* ---------- 累计时长读写（切页/关闭后接着算） ---------- */
  let progressKey = "";
  let lastPersistMs = 0;
  let restoredMs = 0; // 本次从存储恢复的时长（用于"平台会重置计时"时扣除）
  let platformProgressMs = 0; // 平台自己报的"已学习 N"
  let platformProgressAt = 0; // 读到该数值的时刻（用于外推）
  let sampleSeq = 0; // 平台读数的序号（每读到新值 +1）
  let needFreshSample = false; // 上次点击失败后，等平台给出新读数再点
  let sampleSeqAtAttempt = 0;
  let resetOnLeave = false; // 平台提示"刷新/离开会重置计时"

  function persistProgress() {
    if (!progressKey || !settings.autoComplete) return;
    lastPersistMs = activeMs;
    try {
      chrome.storage.local.set({
        [progressKey]: {
          ms: activeMs,
          at: Date.now(),
          reset: resetOnLeave ? 1 : 0,
          req: requiredMs || 0,
        },
      });
    } catch (e) {}
  }

  function restoreProgress(cb) {
    progressKey = progressKeyOf(location.pathname);
    if (!progressKey) return cb && cb();
    try {
      chrome.storage.local.get(progressKey, (d) => {
        const rec = d && d[progressKey];
        // 记住的时长要求：下次进同一资源无需再"点一次探明"
        if (rec && rec.req > 0) {
          requiredMs = rec.req;
          log("info", "记忆中的学习时长要求 " + fmtDur(requiredMs) + "（无需再次试探点击）");
        }
        // 平台会因刷新/离开重置计时 → 本地累计对它无效，不能用来提前点击
        if (rec && rec.reset) {
          resetOnLeave = true;
          activeMs = 0;
          log("info", "该任务离开页面会重置计时，本次从 0 开始计（不套用历史累计）");
          return cb && cb();
        }
        const ms = usableSavedMs(rec, Date.now(), PROGRESS_TTL_MS);
        if (ms > 0) {
          activeMs = Math.max(activeMs, ms);
          lastPersistMs = activeMs;
          restoredMs = ms;
          log("info", "恢复本站该资源的累计学习时长 " + fmtDur(ms));
        }
        cb && cb();
      });
    } catch (e) {
      cb && cb();
    }
  }

  function clearProgress() {
    if (!progressKey) return;
    try { chrome.storage.local.remove(progressKey); } catch (e) {}
  }

  /* ---------- 读取"必须满足的时长" ---------- */
  // 深度遍历（含 open shadow root）：// 平台弹层常挂在 web component 里
  function deepAll(sel, root) {
    const out = [];
    const seen = new Set();
    (function walk(node) {
      if (!node || seen.has(node) || out.length > 6000) return;
      seen.add(node);
      try {
        if (node.querySelectorAll) {
          const list = node.querySelectorAll(sel);
          for (let i = 0; i < list.length; i++) out.push(list[i]);
        }
      } catch (e) {}
      let all;
      try { all = node.querySelectorAll ? node.querySelectorAll("*") : []; } catch (e) { all = []; }
      for (let i = 0; i < all.length && i < 3000; i++) {
        const el = all[i];
        if (el.shadowRoot) walk(el.shadowRoot);
      }
    })(root || document);
    return out;
  }

  // 收集"可能是提示弹窗"的文字：可见文字 + 弹层/提示容器的 textContent（后者对隐藏元素也有效）
  const DIALOG_SEL =
    '[role="dialog"], [role="alertdialog"], [class*="dialog" i], [class*="modal" i], ' +
    '[class*="popup" i], [class*="toast" i], [class*="message" i], [class*="notice" i], [class*="tip" i]';

  // Ant Design 的 Modal.confirm 结构固定，优先精确读取正文（避免把整页文字混进来）
  const DIALOG_TEXT_SELECTORS = [
    ".ant-modal-confirm-content",
    ".finish_task_info",
    ".ant-modal-confirm-body",
    ".ant-modal-confirm",
  ];

  function collectDialogText() {
    const parts = [];
    try {
      // 1) antd 弹窗正文：最准
      for (let i = 0; i < DIALOG_TEXT_SELECTORS.length; i++) {
        let nodes;
        try { nodes = deepAll(DIALOG_TEXT_SELECTORS[i]); } catch (e) { nodes = []; }
        for (let j = 0; j < nodes.length && j < 6; j++) {
          try {
            const t = String(nodes[j].textContent || "").trim();
            if (t && t.length <= 400) parts.push(t);
          } catch (e) {}
        }
      }
      // 2) 通用弹层容器
      const nodes = deepAll(DIALOG_SEL);
      for (let i = 0; i < nodes.length && i < 40; i++) {
        const el = nodes[i];
        try {
          const t = String(el.textContent || "").trim();
          // 只取较短、且像提示语的容器，避免把整页误当成弹窗
          if (t && t.length <= 300) parts.push(t);
        } catch (e) {}
      }
      // 3) 可见文字与全量 textContent 兜底
      const body = document.body;
      if (body) parts.push(String(body.innerText || "").slice(0, 20000));
    } catch (e) {}
    return parts.join("\n");
  }

  function pageTextSample() {
    try {
      const body = document.body;
      if (!body) return "";
      // innerText 较贵，但每 15 秒一次可接受；限制长度避免超长页面
      return String(body.innerText || "").slice(0, 20000);
    } catch (e) {
      return "";
    }
  }

  function refreshRequirement(force) {
    const now = Date.now();
    if (!force && now - requiredParsedAt < REQUIREMENT_TTL_MS) return requiredMs;
    requiredParsedAt = now;
    const parsed = parseRequirement(pageTextSample(), activeMs);
    if (parsed && parsed !== requiredMs) {
      requiredMs = parsed;
      log("info", "页面要求学习时长 ≥ " + fmtDur(parsed) + "，将等满足后再提交");
    } else if (parsed) {
      requiredMs = parsed;
    }

    // 可见文字里没有时，再从「隐藏 DOM / 内联脚本数据」里找——很多平台的提示文案
    // 是预先渲染好但隐藏的，或直接写在页面数据里，这样就不用靠"点一次"去探明。
    if (!requiredMs) {
      const hidden = readRequirementFromSource();
      if (hidden) {
        requiredMs = hidden;
        log("info", "从页面数据中读到学习时长要求 " + fmtDur(hidden) + "，无需试探点击");
      }
    }

    // 同时看看有没有"点击后的提示弹窗"（要求常常只在那里出现）
    scanWarningText(false);
    persistIfLearned();
    return requiredMs;
  }

  // 从页面源码找要求：隐藏的弹窗模板 / 内联 JSON
  function readRequirementFromSource() {
    try {
      const html = document.documentElement ? document.documentElement.outerHTML : "";
      if (!html || html.length > 900000) return 0;
      const text = html
        .replace(/<[^>]+>/g, " ")          // 去掉标签，只留文本与属性值
        .replace(/\\u([0-9a-fA-F]{4})/g, (m, h) => String.fromCharCode(parseInt(h, 16)))
        .replace(/\\\//g, "/");
      const v = parseRequirement(text, activeMs);
      if (v) return v;
      return 0;
    } catch (e) {
      return 0;
    }
  }

  let learnedPersisted = 0;
  function persistIfLearned() {
    if (!requiredMs || learnedPersisted === requiredMs) return;
    learnedPersisted = requiredMs;
    persistProgress();
  }

  // 解析页面上的"未达要求"提示，学习门槛/进度/是否重置计时
  function scanWarningText(verbose) {
    let changed = false;
    try {
      const w = parseWarning(collectDialogText());
      if (w.requiredMs && w.requiredMs !== requiredMs) {
        requiredMs = w.requiredMs;
        changed = true;
        log("info", "平台要求：至少观看/学习 " + fmtDur(w.requiredMs) + "，到时会自动提交");
        calibrateWithRequirement(); // 顺便用真值认领接口字段，下次免探明
      }
      // 平台自报进度：这是最可信的计时来源（平台按自己的时钟校验）
      if (w.progressMs > 0 && w.progressMs !== platformProgressMs) {
        platformProgressMs = w.progressMs;
        platformProgressAt = Date.now();
        sampleSeq++;
        needFreshSample = false;
        changed = true;
        // 平台自报计时是判定依据，变动时记一条，便于对照
        log("info", "平台读数：已学习 " + fmtDur(w.progressMs) + (requiredMs ? " / 要求 " + fmtDur(requiredMs) : ""));
      }
      if (w.resetOnLeave && !resetOnLeave) {
        resetOnLeave = true;
        changed = true;
        // 平台自己会清零 → 把"历史恢复的时长"扣掉，避免用虚高时长提前点击
        if (restoredMs > 0) {
          activeMs = Math.max(0, activeMs - restoredMs);
          restoredMs = 0;
        }
        persistProgress();
        log("info", "平台提示：刷新/离开会重置计时，已改为仅按本次停留计时");
      }
      if (w.needsMore || w.requiredMs) {
        // 一看到提示就记一次快照，便于下次不用开 DevTools 也能定位弹窗结构
        logDialogSnapshot(w);
      }
      if (changed) persistIfLearned();
      if (verbose && changed) {
        log("debug", "状态更新：要求 " + fmtDur(requiredMs) + " / 平台已学 " + fmtDur(platformProgressMs));
      }
    } catch (e) {}
    return changed;
  }

  // 平台自报进度的估算：以最近一次读到的值为基准，按可见时间外推。
  // 平台是按自己的时钟校验的，用它的数值比我方计时更准；
  // 若平台在每次点击后重置"连续观看"计时，下次弹窗给出更小的值时会自动校正。
  function estimatedPlatformMs() {
    if (!platformProgressMs) return 0;
    const vis = Date.now() - platformProgressAt;
    if (vis <= 0) return platformProgressMs;
    return platformProgressMs + Math.min(vis, 10 * 60 * 1000);
  }

  // 有效进度：优先用平台自报值（更可信），没读到过才用本地计时
  function effectiveProgressMs() {
    return pickProgress({ platformMs: estimatedPlatformMs(), activeMs: activeMs, requiredMs: requiredMs });
  }

  /* ---------- 从"学习时长接口"直接读要求（免探明点击） ---------- */
  // 主世界会把 learnLength / studentFinishInfo 等接口里的时长字段回传过来，
  // 形如 [{k:"learnLength", v:120}, ...]。单位未知，先当候选，再与弹窗读到的值互相校验。
  let apiCandidates = [];   // 最近一次的候选（已换算成多种可能单位）
  let apiFieldName = "";    // 与弹窗读数对上的字段名，之后优先用它

  function candidatesFromFields(fields) {
    const out = [];
    const KEY_RE = /(learn|study|watch|read|finish|complete|require|need|limit|min|duration|length|time)/i;
    for (let i = 0; i < fields.length && i < 30; i++) {
      const k = String(fields[i].k || "");
      const v = Number(fields[i].v);
      if (!KEY_RE.test(k) || !isFinite(v) || v <= 0) continue;
      // 同一数值可能是秒、分或毫秒，都作为候选（后面用弹窗真值筛掉错的）
      out.push({ k: k, raw: v, ms: v * 1000 });
      out.push({ k: k, raw: v, ms: v * 60000 });
      out.push({ k: k, raw: v, ms: v });
    }
    return out;
  }

  // 用"已确认的要求"去认领字段：哪个字段换算后正好等于它，就记住这个字段
  function calibrateWithRequirement() {
    if (!requiredMs || !apiCandidates.length) return "";
    for (let i = 0; i < apiCandidates.length; i++) {
      const c = apiCandidates[i];
      if (Math.abs(c.ms - requiredMs) <= 2000) {
        if (apiFieldName !== c.k) {
          apiFieldName = c.k;
          log("info", "已确认时长字段：" + c.k + "（可免去下次的试探点击）");
        }
        return apiFieldName;
      }
    }
    return "";
  }

  function onTaskInfo(info) {
    try {
      if (!info || !info.fields) return;
      apiCandidates = candidatesFromFields(info.fields);
      if (apiFieldName) {
        // 已认领字段 → 直接当要求使用（比探明更快，也不打扰）
        for (let i = 0; i < apiCandidates.length; i++) {
          const c = apiCandidates[i];
          if (c.k === apiFieldName && Math.abs(c.ms - requiredMs) <= 2000) {
            if (!requiredMs) {
              requiredMs = c.ms;
              log("info", "从接口字段 " + c.k + " 直接读到学习时长要求 " + fmtDur(requiredMs));
            }
            return;
          }
        }
      }
      // 还没认领：若弹窗已给出要求，就用它认领字段
      calibrateWithRequirement();
      // 若还没有要求，且只有一个高置信候选（键名含 length/duration/require + 值像时长），先记录不采用
      if (!requiredMs && apiCandidates.length) {
        const top = apiCandidates.find((c) => /length|duration|require|need/i.test(c.k));
        if (top) log("debug", "接口候选时长：" + top.k + "=" + top.raw + "（待与平台读数核对）");
      }
    } catch (e) {}
  }

  // 一次"点击后"的弹窗快照：把弹窗容器与可点元素写进日志，
  // 这样即使不开 DevTools 也能知道该支持哪些关闭按钮。
  let lastSnapshotKey = "";
  function logDialogSnapshot(w) {
    try {
      const key = Math.round((w && w.requiredMs) / 1000) + "|" + Math.round((w && w.progressMs) / 1000) + "|" + (w && w.resetOnLeave ? 1 : 0);
      if (key === lastSnapshotKey) return;
      lastSnapshotKey = key;
      const nodes = deepAll(DIALOG_SEL);
      let box = null;
      for (let i = 0; i < nodes.length; i++) {
        const t = String(nodes[i].textContent || "");
        if (/未达要求|至少观看|至少学习|时长不足|请继续/.test(t) && t.length <= 400) { box = nodes[i]; break; }
      }
      let desc = "无弹层容器";
      if (box) {
        const cls = String(box.className || "").trim().split(/\s+/).slice(0, 3).join(".");
        desc = box.tagName.toLowerCase() + (cls ? "." + cls : "") + (box.getAttribute("role") ? "[role=" + box.getAttribute("role") + "]" : "");
      }
      const labels = [];
      const clickables = deepAll('button, [role="button"], a, [class*="btn" i], [class*="close" i]');
      for (let i = 0; i < clickables.length && labels.length < 6; i++) {
        const el = clickables[i];
        if (box && !(box.contains(el) || (el.closest && el.closest(DIALOG_SEL)))) continue;
        const txt = normLabel(el.textContent || "").slice(0, 8);
        const aria = String(el.getAttribute("aria-label") || "").slice(0, 8);
        const cl = String(el.className || "").split(/\s+/).slice(0, 2).join(".");
        const label = txt || aria || (cl ? "[" + cl + "]" : el.tagName.toLowerCase());
        if (!labels.includes(label)) labels.push(label);
      }
      log("debug", "弹窗快照：容器 " + desc + " / 可点 " + (labels.join("|") || "无"));
    } catch (e) {}
  }

  function inScope() {
    if (!settings.autoComplete) return false;
    if (!captureScoped) return true;
    if (!SCOPE) return false;
    let ao = [];
    let referrer = "";
    try { ao = Array.prototype.slice.call(location.ancestorOrigins || []); } catch (e) {}
    try { referrer = document.referrer || ""; } catch (e) {}
    return SCOPE.isLearningPage(location.href, ao, referrer, extraHosts);
  }

  function loadSettings(cb) {
    try {
      chrome.storage.local.get(
        { autoComplete: true, extraHosts: "", captureScoped: true },
        (d) => {
          settings.autoComplete = d.autoComplete !== false;
          extraHosts = d.extraHosts || "";
          captureScoped = d.captureScoped !== false;
          cb && cb();
        }
      );
      chrome.storage.onChanged.addListener((ch) => {
        if (!ch) return;
        if (ch.autoComplete) settings.autoComplete = ch.autoComplete.newValue !== false;
        if (ch.extraHosts) extraHosts = ch.extraHosts.newValue || "";
        if (ch.captureScoped) captureScoped = ch.captureScoped.newValue !== false;
      });
    } catch (e) {
      cb && cb();
    }
  }

  /* ---------- 阅读进度 ---------- */
  function isScrollableEl(el) {
    try {
      if (!el || el.scrollHeight <= el.clientHeight + 24) return false;
      if (el.clientHeight < 160) return false; // 太矮的多半是侧栏/列表
      const cs = getComputedStyle(el);
      return /(auto|scroll|overlay)/.test(cs.overflowY || "");
    } catch (e) {
      return false;
    }
  }

  function ratioOf(el) {
    try {
      const max = el.scrollHeight - el.clientHeight;
      if (max <= 0) return 1;
      return Math.max(0, Math.min(1, el.scrollTop / max));
    } catch (e) {
      return 0;
    }
  }

  function updateScrollProgress() {
    try {
      const candidates = [document.scrollingElement, document.documentElement, document.body].filter(Boolean);
      // 内层滚动容器（平台常把文档放进自己的滚动区）
      const inner = document.querySelectorAll("div, main, article, section");
      for (let i = 0; i < inner.length && i < 400; i++) {
        if (isScrollableEl(inner[i])) candidates.push(inner[i]);
      }
      let best = 0;
      let scrollable = false;
      for (const el of candidates) {
        if (!isScrollableEl(el)) continue;
        scrollable = true;
        const r = ratioOf(el);
        if (r > best) best = r;
      }
      if (scrollable) {
        sawScrollable = true;
        if (best > maxScrollRatio) maxScrollRatio = best;
      }
    } catch (e) {}
  }

  /* ---------- 视频完成信号 ---------- */
  function collectVideos() {
    const set = new Set();
    try { document.querySelectorAll("video").forEach((v) => set.add(v)); } catch (e) {}
    try {
      (function walk(root) {
        const all = root.querySelectorAll("*");
        for (let i = 0; i < all.length; i++) {
          const el = all[i];
          if (el.tagName === "VIDEO") set.add(el);
          if (el.shadowRoot) walk(el.shadowRoot);
        }
      })(document);
    } catch (e) {}
    return Array.from(set);
  }

  function hookVideos() {
    for (const v of collectVideos()) {
      if (v.__cdAcHooked) continue;
      v.__cdAcHooked = true;
      try {
        v.addEventListener("ended", () => {
          videoEndedRecently = true;
          log("info", "视频已播放完毕，准备提交完成");
          announceVideoEnded(); // 通知同标签页的其他框架（按钮常在顶层）
          evaluate();
        });
        // 有些播放器不派发 ended（例如循环播放/分片切换），用进度兜底
        v.addEventListener("timeupdate", () => {
          if (v.__cdAcEndNotified) return;
          if (videoFinished({ ended: v.ended, currentTime: v.currentTime, duration: v.duration })) {
            v.__cdAcEndNotified = true;
            videoEndedRecently = true;
            announceVideoEnded();
            evaluate();
          }
        });
      } catch (e) {}
    }
  }

  function anyVideoFinished() {
    for (const v of collectVideos()) {
      try {
        if (videoFinished({ ended: v.ended, currentTime: v.currentTime, duration: v.duration })) return true;
      } catch (e) {}
    }
    return videoEndedRecently;
  }

  // 页面里是否存在（有真实时长的）视频 → 说明这是视频任务，判定基准是"看完"
  function hasRealVideo() {
    for (const v of collectVideos()) {
      try {
        if (Number(v.duration) > 0) return true;
      } catch (e) {}
    }
    return false;
  }

  // 视频常在内嵌 iframe 里播放，而"完成"按钮和提示在顶层：
  // 让播放结束的信号经后台广播到同一标签页的所有框架。
  let remoteVideoEndedAt = 0;
  let videoEndedAnnounced = false;
  const REMOTE_VIDEO_TTL = 30 * 60 * 1000;

  function announceVideoEnded() {
    if (videoEndedAnnounced) return;
    videoEndedAnnounced = true;
    try { chrome.runtime.sendMessage({ action: "videoEnded" }); } catch (e) {}
  }

  function videoFinishedAnywhere() {
    if (anyVideoFinished()) return true;
    return remoteVideoEndedAt > 0 && Date.now() - remoteVideoEndedAt < REMOTE_VIDEO_TTL;
  }

  /* ---------- 找"完成"按钮 ---------- */
  // 元素是否"看起来可点"（平台常用 div/span 自绘按钮，不一定是 <button>）
  function looksClickable(el) {
    try {
      const tag = el.tagName;
      if (tag === "BUTTON") return true;
      if (tag === "A" && el.getAttribute("href") !== null) return true;
      if (String(el.getAttribute("role") || "").toLowerCase() === "button") return true;
      if (/btn|button|click|action/i.test(String(el.className || ""))) return true;
      const cs = getComputedStyle(el);
      if (cs && cs.cursor === "pointer") return true;
      if (typeof el.onclick === "function") return true;
      return false;
    } catch (e) {
      return false;
    }
  }

  function isUsable(el) {
    try {
      if (el.disabled === true) return false;
      if (String(el.getAttribute("aria-disabled") || "") === "true") return false;
      if (/disabled/i.test(String(el.className || ""))) return false;
      const r = el.getBoundingClientRect();
      if (!r || r.width < 8 || r.height < 8) return false;
      // 注意：不能用 offsetParent === null 判断（position:fixed 的元素它也是 null，
      // 而弹窗/浮层恰恰大量使用 fixed，会导致"看得见却点不到"）
      const cs = getComputedStyle(el);
      if (cs) {
        if (cs.display === "none" || cs.visibility === "hidden") return false;
        if (parseFloat(cs.opacity || "1") < 0.05) return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  function findCompleteButton() {
    // 先扫常见可点元素；范围放宽到 div/span（平台自绘按钮很常见）
    const sel = 'button, [role="button"], a, div, span';
    let nodes;
    try { nodes = deepAll(sel); } catch (e) { return null; }
    let fallback = null;
    for (let i = 0; i < nodes.length && i < 4000; i++) {
      const el = nodes[i];
      try {
        if (!isCompleteLabel(el.textContent || "")) continue;
        if (!isUsable(el)) continue;
        // 优先返回"看起来就是按钮"的元素；否则记住最内层候选
        if (looksClickable(el)) return el;
        // 避免选中包含整段内容的容器：只取文本长度接近标签本身的元素
        const txt = normLabel(el.textContent || "");
        if (!fallback || txt.length < normLabel(fallback.textContent || "").length) fallback = el;
      } catch (e) {}
    }
    return fallback;
  }

  // 点击后校验平台是否真的记了完成
  function stillIncomplete() {
    try {
      // 只要出现"未达要求 / 至少观看 N"这类提示（含隐藏文案），就一定没完成
      if (warningSaysIncomplete(collectDialogText())) return true;
      if (findCompleteButton()) return true; // 完成按钮还在 → 没认定
      return false;
    } catch (e) {
      return false;
    }
  }

  /* ---------- 关闭提示弹窗（多路兜底） ---------- */
  // 1) 文案按钮（我知道了/确定…，容忍标点与"×"）
  // 2) 关闭图标（aria-label / class 含 close、icon-close 等）
  // 3) Esc 键（多数弹层框架支持）
  // 4) 点遮罩层角落
  const DISMISS_EXTRA_RE = /^(我已知晓|已知晓|知道了|我明白了|明白|确定|确认|好的|好|关闭|关闭提示|不用了|继续学习|继续观看|继续阅读|ok|gotit)$/i;

  function stripTrailingPunct(s) {
    return String(s || "").replace(/[!！.。,，、:：;；~～\s]+$/g, "");
  }

  function isDismissText(text) {
    const t = stripTrailingPunct(normLabel(text));
    if (!t) return false;
    if (isCompleteLabel(t)) return false; // 别把完成按钮当成关闭
    if (isDismissLabel(t)) return true;
    return DISMISS_EXTRA_RE.test(t);
  }

  function clickEl(el) {
    try {
      el.click();
      return true;
    } catch (e) {
      try {
        ["mousedown", "mouseup", "click"].forEach((t) => {
          el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
        });
        return true;
      } catch (e2) {}
    }
    return false;
  }

  function dismissDialog() {
    try {
      // ① 先按 antd 的固定结构精确点。
      //    顺序很重要：**优先右上角 ×**（纯关闭），最后才点「知道了」——
      //    实测点确认按钮会再次触发平台校验，出现"关了又弹"的循环。
      const priority = [
        ["antd-close", ".ant-modal-close"],
        ["antd-confirm-plain", ".ant-modal-confirm-btns .ant-btn:not(.ant-btn-primary)"],
        ["antd-confirm-primary", ".ant-modal-confirm-btns .ant-btn-primary"],
      ];
      for (let i = 0; i < priority.length; i++) {
        let nodes;
        try { nodes = deepAll(priority[i][1]); } catch (e) { nodes = []; }
        for (let j = 0; j < nodes.length && j < 4; j++) {
          const el = nodes[j];
          if (!isUsable(el)) continue;
          // 主按钮若是"取消/完成"这类，跳过（确认框里也可能出现）
          const txt = normLabel(el.textContent || "");
          if (txt && isCompleteLabel(txt)) continue;
          if (clickEl(el)) return priority[i][0];
        }
      }

      // ② 通用扫描：文案按钮 + 关闭图标
      const nodes = deepAll('button, [role="button"], a, [class*="btn" i], [class*="close" i], [class*="icon" i], span, div');
      let best = null;
      let bestInDialog = false;
      let closeIcon = null;
      for (let i = 0; i < nodes.length && i < 6000; i++) {
        const el = nodes[i];
        try {
          if (!isUsable(el)) continue;
          const txt = normLabel(el.textContent || "");
          const aria = String(el.getAttribute("aria-label") || el.getAttribute("title") || "");
          const cls = String(el.className || "");

          // 关闭图标：× / close 类 / aria-label=关闭
          if (!closeIcon) {
            const looksClose =
              /^(×|✕|✖|x)$/i.test(txt) ||
              /(^|[-_\s])(close|icon-close|closebtn|btn-close)([-_\s]|$)/i.test(cls) ||
              /^(关闭|close|关闭弹窗)$/i.test(normLabel(aria));
            if (looksClose) closeIcon = el;
          }

          const label = txt || aria;
          if (!isDismissText(label) && !isDismissText(txt)) continue;
          const inDialog = !!(el.closest && el.closest(DIALOG_SEL));
          if (inDialog) { best = el; bestInDialog = true; break; }
          if (!best) best = el;
        } catch (e) {}
      }
      if (best && clickEl(best)) return bestInDialog ? "text-in-dialog" : "text";
      if (closeIcon && clickEl(closeIcon)) return "close-icon";
      // ③ Esc 兜底
      try {
        const ev = new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true });
        (document.activeElement || document.body || document).dispatchEvent(ev);
        document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", keyCode: 27, bubbles: true }));
        return "escape";
      } catch (e) {}
    } catch (e) {}
    return "";
  }

  // 只要发现了提示弹窗就尽早关掉（不依赖点击后的 4 秒窗口）
  let lastDismissAt = 0;
  let dismissCount = 0;
  let dismissWindowAt = 0;
  function dismissIfWarningVisible() {
    try {
      if (Date.now() - lastDismissAt < 1200) return;
      const txt = collectDialogText();
      if (!warningSaysIncomplete(txt)) return;
      // 熔断：短时间内反复关闭（平台关了又弹）时降低频率，避免和平台互相触发
      const now = Date.now();
      if (now - dismissWindowAt > 60000) { dismissWindowAt = now; dismissCount = 0; }
      dismissCount++;
      if (dismissCount > 6) {
        if (dismissCount === 7) log("warn", "提示弹窗反复弹出，已降低自动关闭频率（可手动关掉，不影响计时）");
        if (now - lastDismissAt < 10000) return;
      }
      lastDismissAt = now;
      const how = dismissDialog();
      if (how) log("debug", "检测到提示弹窗并已关闭（" + how + "）");
      else log("warn", "检测到提示弹窗，但没找到可点的关闭按钮（详见上一条弹窗快照）");
    } catch (e) {}
  }

  let lastNoBtnLogAt = 0;
  function clickOnce() {
    const now = Date.now();
    if (done) return false;
    if (now < nextAttemptAt) return false;
    if (now - lastClickAt < CLICK_COOLDOWN_MS) return false;
    const btn = findCompleteButton();
    if (!btn) {
      // 找不到按钮时不再静默返回——否则日志会"断在半路"，看不出为什么没继续
      if (now - lastNoBtnLogAt > 30000) {
        lastNoBtnLogAt = now;
        log("debug", "未找到可点的完成按钮（可能已被平台置灰或页面已切走），稍后继续检查");
      }
      return false;
    }

    attempts++;
    lastClickAt = now;
    sampleSeqAtAttempt = sampleSeq;
    needFreshSample = true;
    nextAttemptAt = nextRetryAt(now, RETRY_INTERVAL_MS); // 默认按"可能不生效"排队
    try {
      btn.click();
      log(
        "info",
        "已自动点击「" + normLabel(btn.textContent).slice(0, 10) + "」· 本次停留 " + fmtDur(activeMs) +
        (requiredMs ? " / 要求 " + fmtDur(requiredMs) : "") + "（第 " + attempts + " 次）"
      );
    } catch (e) {
      log("warn", "点击完成按钮失败: " + (e && e.message || e));
      return false;
    }
    // 弹窗可能在几秒后才出现，分多个时间点读+关，避免错过
    setTimeout(() => { scanWarningText(true); dismissIfWarningVisible(); }, 700);
    setTimeout(() => { scanWarningText(false); dismissIfWarningVisible(); }, 2500);
    // 4 秒后回看：先读提示弹窗（要求通常只在这里），再关掉它，然后判断是否生效
    setTimeout(() => {
      if (!inScope() || done) return;
      const before = requiredMs;
      scanWarningText(true);
      if (requiredMs && requiredMs !== before) persistIfLearned();
      const closed = dismissDialog();
      if (closed) log("debug", "已关闭提示弹窗（" + closed + "）");
      if (stillIncomplete()) {
        if (attempts >= MAX_ATTEMPTS) {
          log("warn", "已尝试 " + attempts + " 次仍未记录完成，停止自动提交（请手动确认）");
          done = true;
          return;
        }
        nextAttemptAt = planNextAttempt({
          now: Date.now(),
          requiredMs: requiredMs,
          progressMs: effectiveProgressMs(),
          minGapMs: 15000,
        });
        const waitS = Math.max(1, Math.round((nextAttemptAt - Date.now()) / 1000));
        log(
          "info",
          "平台尚未记录完成" + (requiredMs ? "（要求 " + fmtDur(requiredMs) + "，当前 " + fmtDur(effectiveProgressMs()) + "）" : "") +
          "，" + waitS + " 秒后自动重试"
        );
        return;
      }
      done = true;
      clearProgress(); // 平台已记录完成，累计时长可以清零
      log("info", "平台已记录完成 ✓（停留 " + fmtDur(effectiveProgressMs()) + "）");
    }, 4000);
    return true;
  }

  function evaluate() {
    if (done) return;
    if (!inScope()) return;
    tickActive();
    hookVideos();
    updateScrollProgress();
    refreshRequirement(false);
    scanWarningText(false);
    dismissIfWarningVisible(); // 弹窗只要出现就尽早关掉

    const progress = effectiveProgressMs();

    // ⓪ 视频任务：判定基准是"播放到结尾即可点"。
    //    没看完就点，平台只会弹一条提示（没有对话框可读），所以这里**绝不做探明点击**，
    //    静默等到播完再提交。
    if (hasRealVideo() || remoteVideoEndedAt > 0) {
      if (!videoFinishedAnywhere()) {
        if (Date.now() - lastWaitLogAt > 60000) {
          lastWaitLogAt = Date.now();
          log("debug", "视频尚未播放完毕，暂不提交");
        }
        return;
      }
      clickOnce();
      return;
    }

    // ① 已知要求：**只按时间判定**。
    //    平台校验的就是时长，用我们自己的"读完/看完"信号去挡它，反而会永远不点
    //    （例如 PPT 是翻页渲染、iframe 里滚不到底）。
    if (requiredMs > 0) {
      // 上次点失败后、平台还没给出新读数 → 先别重复点（平台可能比我们慢很多）
      if (shouldWaitForFreshSample({
        needFresh: needFreshSample,
        sampleSeq: sampleSeq,
        sampleSeqAtAttempt: sampleSeqAtAttempt,
        sinceClickMs: Date.now() - lastClickAt,
        requiredMs: requiredMs,
        graceMs: 30000,
      })) {
        if (Date.now() - lastWaitLogAt > 60000) {
          lastWaitLogAt = Date.now();
          log("debug", "上次点击后平台尚未给出新读数，继续等待（避免重复点击）");
        }
        return;
      }
      if (timeGateMet({ requiredMs: requiredMs, minDefaultMs: 0, progressMs: progress })) {
        clickOnce();
      } else if (Date.now() - lastWaitLogAt > 60000) {
        lastWaitLogAt = Date.now();
        log("debug", "等待学习时长达标 " + fmtDur(progress) + " / " + fmtDur(requiredMs));
      }
      return;
    }

    // ② 未知要求：做一次"探明点击"（点一次看平台怎么说）。
    //    不等用户读完再探明——早点问清楚要求，之后静默等到时间即可；
    //    探明后出现的提示弹窗会在 4 秒内自动关闭。
    if (!probedOnce) {
      if (progress < PROBE_AFTER_MS) return; // 刚进页面不点，避免打扰
      probedOnce = true;
      log("info", "读取平台要求：试探点击一次（提示弹窗会自动关闭）");
      clickOnce();
      return;
    }
    // 已探明但没读到要求（例如提示文案不认识）→ 回到原策略：完成信号 + 定期重试
    const completed = shouldSubmit({
      videoFinished: anyVideoFinished(),
      dwellMs: progress,
      scrollRatio: maxScrollRatio,
      scrollable: sawScrollable,
    });
    if (!completed) return;
    if (Date.now() >= nextAttemptAt) clickOnce();
  }

  /* ---------- 事件与定时 ---------- */
  try {
    window.addEventListener("scroll", updateScrollProgress, { passive: true, capture: true });
  } catch (e) {}
  try {
    new MutationObserver(() => { hookVideos(); }).observe(document.documentElement || document, {
      childList: true, subtree: true,
    });
  } catch (e) {}
  // 离开页面/切到后台时把累计时长存稳，回来可以接着算
  try {
    window.addEventListener("pagehide", () => { persistProgress(); });
    window.addEventListener("beforeunload", () => { persistProgress(); });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") persistProgress();
    });
  } catch (e) {}

  // 视频在内嵌框架里播放时，由后台把"已播完"广播回来
  try {
    chrome.runtime.onMessage.addListener((m) => {
      if (m && m.action === "videoEnded") {
        remoteVideoEndedAt = Date.now();
        log("info", "收到播放结束信号（来自内嵌播放器），准备提交");
        evaluate();
      }
    });
  } catch (e) {}

  // 主世界回传的"学习时长接口"字段：优先用于免探明读取要求
  try {
    document.addEventListener("cd-taskinfo", (e) => { onTaskInfo(e && e.detail); });
    if (window.__cdTaskInfo) onTaskInfo(window.__cdTaskInfo);
  } catch (e) {}

  setInterval(evaluate, 2000);
  setInterval(tickActive, 1000);
  setInterval(updateScrollProgress, 1000);
  setInterval(hookVideos, 2500);

  // DOM 变更即抓取：提示弹窗可能是"一闪而过"或只在极短时间内存在，
  // 靠 2 秒轮询会错过。这里对新增节点立即读取并关闭。
  try {
    let pending = null;
    new MutationObserver((records) => {
      if (pending) return;
      pending = setTimeout(() => {
        pending = null;
        if (done || !inScope()) return;
        let hit = false;
        for (let i = 0; i < records.length && i < 60; i++) {
          const r = records[i];
          if (r.type !== "childList" || !r.addedNodes || !r.addedNodes.length) continue;
          for (let j = 0; j < r.addedNodes.length && j < 10; j++) {
            const n = r.addedNodes[j];
            if (n.nodeType !== 1) continue;
            let t = "";
            try { t = String(n.textContent || "").slice(0, 600); } catch (e) {}
            if (t && /(未达要求|至少观看|至少学习|时长不足|请继续阅读|请继续学习)/.test(t)) { hit = true; break; }
          }
          if (hit) break;
        }
        if (!hit) return;
        scanWarningText(true);   // 第一时间读出要求与平台进度
        dismissIfWarningVisible(); // 并立刻关掉，别挡着
      }, 120);
    }).observe(document.documentElement || document, { childList: true, subtree: true });
  } catch (e) {}

  loadSettings(() => {
    restoreProgress(() => {
      updateScrollProgress();
      evaluate();
    });
  });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { updateScrollProgress(); evaluate(); });
    window.addEventListener("load", () => { updateScrollProgress(); evaluate(); });
  }
})();