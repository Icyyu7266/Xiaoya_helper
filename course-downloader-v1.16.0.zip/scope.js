/* 课程资源识别规则 —— 单一事实来源
 * 同一份逻辑供四个执行环境共用：
 *   1. 后台 Service Worker（importScripts 加载）
 *   2. 隔离世界 content.js
 *   3. 主世界 main.js
 *   4. Node 单元测试
 * 只做纯计算，不接触任何 chrome.* API / DOM API（collectLearningLinks 只读传入的 root）。
 *
 * 设计原则：捕获必须同时满足「请求发生在课程学习页面上下文」且「资源本身是课件类型」，
 * 任一不满足即拒绝，避免把浏览其他网站时的普通 zip/txt/图片/分片当成学习文件。
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  try {
    root.CDScope = api;
  } catch (e) {}
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  /* ================= 站点范围 ================= */
  // 课程平台（学习页面所在域）
  const PLATFORM_HOST_RE = /(^|\.)ai-augmented\.com$/i;
  // 平台使用的文档预览/转码服务商（永中 OW365）：仅当被平台页面内嵌时才算学习内容
  const PREVIEW_HOST_RE = /(^|\.)ow365\.cn$/i;

  /* ================= 课件类型 ================= */
  const DOC_EXTS = ["pdf", "doc", "docx", "docm", "ppt", "pptx", "pptm", "xls", "xlsx", "xlsm"];
  const MEDIA_EXTS = ["mp4", "m3u8"];
  const COURSE_EXTS = DOC_EXTS.concat(MEDIA_EXTS);
  const COURSE_EXT_SET = new Set(COURSE_EXTS);

  // 精确的课件 MIME → 扩展名（不做模糊匹配）
  const MIME_TO_EXT = {
    "application/pdf": "pdf",
    "application/msword": "doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "application/vnd.ms-word.document.macroenabled.12": "docm",
    "application/vnd.ms-powerpoint": "ppt",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
    "application/vnd.ms-powerpoint.presentation.macroenabled.12": "pptm",
    "application/vnd.ms-excel": "xls",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    "application/vnd.ms-excel.sheet.macroenabled.12": "xlsm",
    "video/mp4": "mp4",
    "application/vnd.apple.mpegurl": "m3u8",
    "application/x-mpegurl": "m3u8",
    "audio/mpegurl": "m3u8",
  };

  // 明确不属于课件的静态资源 / 媒体分片 / 可执行文件 / 音频（清单一律拒绝）
  const NOISE_EXT_RE =
    /\.(js|mjs|cjs|css|html?|xhtml|json|jsonp|xml|rss|atom|txt|md|csv|log|ini|conf|png|jpe?g|jfif|gif|webp|avif|svg|ico|bmp|tiff?|woff2?|ttf|otf|eot|map|wasm|ts|m4s|mp3|wav|ogg|oga|webm|flac|aac|apk|exe|dmg|msi|deb|rpm|crx)(?:[?#]|$)/i;

  // 平台元数据接口：返回 JSON 描述而非文件本体，必须排除
  const META_API_RE = /(cloud\/file_url\/|queryResource|queryCourseResources|aliyuncs\.com\/\?Action=GetPlayInfo)/i;

  // 平台文件证据：预览服务商（永中）的 f/bs 参数里若出现平台自身存储域名或 19 位资源 ID，
  // 说明该文件确实来自课程平台（用于「新标签页直接打开预览」这一类没有祖先链的场景）
  const PLATFORM_FILE_EVIDENCE_RE = /(ai-augmented\.com|\b\d{17,20}\b)/i;

  // 二进制流 MIME：只有在拿到课件文件名线索时才允许通过
  const AMBIGUOUS_MIME_RE = /^(application\/octet-stream|application\/zip|application\/x-zip-compressed|binary\/octet-stream)$/;

  const KIND_BY_EXT = {
    pdf: "PDF",
    doc: "Word", docx: "Word", docm: "Word",
    ppt: "PPT", pptx: "PPT", pptm: "PPT",
    xls: "Excel", xlsx: "Excel", xlsm: "Excel",
    mp4: "视频", m3u8: "视频HLS",
  };

  /* ================= 基础工具 ================= */
  function hostOf(u) {
    try {
      return String(new URL(String(u)).hostname || "").toLowerCase();
    } catch (e) {
      return "";
    }
  }

  function isPlatformHost(h) {
    return PLATFORM_HOST_RE.test(String(h || "").toLowerCase());
  }

  function isPreviewHost(h) {
    return PREVIEW_HOST_RE.test(String(h || "").toLowerCase());
  }

  // 路径末段的扩展名（只认单个后缀）
  function extFromPath(url) {
    try {
      const p = new URL(String(url)).pathname;
      const m = /\.([a-z0-9]{1,6})$/i.exec(p);
      return m ? m[1].toLowerCase() : "";
    } catch (e) {
      return "";
    }
  }

  function extFromName(name) {
    const m = /\.([a-z0-9]{1,6})\s*$/i.exec(String(name || "").trim());
    return m ? m[1].toLowerCase() : "";
  }

  function normMime(mime) {
    return String(mime || "").split(";")[0].trim().toLowerCase();
  }

  function kindFromExt(ext) {
    return KIND_BY_EXT[String(ext || "").toLowerCase()] || "文件";
  }

  // 永中 pdfv 的 f 参数 base64 解码出原始文件名（编码变体：base64 把 "=" 换成 "-"）
  function decodePdfvName(url) {
    try {
      const m = /[?&]f=([^&]+)/.exec(String(url || ""));
      if (!m) return "";
      const raw = decodeURIComponent(m[1]);
      const cands = [raw.replace(/-/g, "="), raw.replace(/-/g, "+").replace(/_/g, "/")];
      for (let v of cands) {
        try {
          while (v.length % 4) v += "=";
          const dec = atob(v);
          if (/\.(pdf|zip|pptx?|docx?|xlsx?)$/i.test(dec)) return dec.split("\\").pop().trim() || "";
        } catch (e) {}
      }
      return "";
    } catch (e) {
      return "";
    }
  }

  // URL 查询串里的文件名线索（如 ?filename=xxx.pptx）
  function hintFromUrl(url) {
    try {
      const sp = new URL(String(url)).searchParams;
      const keys = ["filename", "fileName", "file_name", "name", "title", "fname"];
      for (const k of keys) {
        const v = sp.get(k);
        if (!v) continue;
        let dec = v;
        try { dec = decodeURIComponent(v); } catch (e) {}
        if (COURSE_EXT_SET.has(extFromName(dec))) {
          if (isPreviewHost(hostOf(url)) && /^[A-Za-z0-9+/=_-]{16,}$/.test(v)) continue; // pdfv 的 f 参数另行解码
          return dec;
        }
      }
    } catch (e) {}
    return "";
  }

  /* ================= 页面上下文判定 ================= */
  // 额外允许的站点：形如 "example.edu.cn" 或 "*.example.edu.cn"（用户可选配置，默认空）
  function matchExtraHost(host, extraHosts) {
    const h = String(host || "").toLowerCase();
    if (!h) return false;
    const list = Array.isArray(extraHosts) ? extraHosts : String(extraHosts || "").split(/[\s,;]+/);
    for (let i = 0; i < list.length; i++) {
      const raw = String(list[i] || "").trim().toLowerCase();
      if (!raw) continue;
      // 去掉协议/路径/端口，只留主机名
      const pat = raw.replace(/^[a-z]+:\/\//, "").replace(/[/:].*$/, "");
      if (!pat) continue;
      if (pat.startsWith("*.")) {
        const base = pat.slice(2);
        if (h === base || h.endsWith("." + base)) return true;
      } else if (pat.startsWith(".")) {
        if (h.endsWith(pat)) return true;
      } else if (h === pat) {
        return true;
      }
    }
    return false;
  }

  // pageUrl：当前页面（或框架）的地址；ancestorOrigins：location.ancestorOrigins；referrer：document.referrer
  function isLearningPage(pageUrl, ancestorOrigins, referrer, extraHosts) {
    const h = hostOf(pageUrl);
    if (isPlatformHost(h)) return true;
    if (matchExtraHost(h, extraHosts)) return true;

    const list = ancestorOrigins || [];
    for (let i = 0; i < list.length; i++) {
      const ah = hostOf(list[i]);
      if (isPlatformHost(ah) || matchExtraHost(ah, extraHosts)) return true;
    }
    if (referrer) {
      const rh = hostOf(referrer);
      if (isPlatformHost(rh) || matchExtraHost(rh, extraHosts)) return true;
    }
    // 课件预览服务商（永中）必须挂在课程页面之下才算学习内容
    return false;
  }

  /* ================= 单文件判定 ================= */
  // input: { url, mime, filenameHint, learning, strict }
  // 返回 { ok, ext, kind, reason }（ok=false 时 reason 说明拒绝原因）
  function classifyResource(input) {
    const o = input || {};
    const url = String(o.url || "");
    const strict = o.strict !== false; // 默认严格
    const learning = o.learning !== false; // 默认要求学习页面上下文
    const mime = normMime(o.mime);
    let hint = String(o.filenameHint || "") || hintFromUrl(url);
    // 永中 pdfv 的 f 参数里编码着原始文件名，需解码后才算线索
    if (!hint && /[?&]f=/.test(url) && isPreviewHost(hostOf(url))) {
      const decoded = decodePdfvName(url);
      if (decoded) hint = decoded;
    }

    if (!/^https?:\/\//i.test(url)) return { ok: false, reason: "非 http(s) 地址" };
    if (META_API_RE.test(url)) return { ok: false, reason: "平台元数据接口(非文件本体)" };
    if (!learning) return { ok: false, reason: "不在课程学习页面上下文" };

    const noise = NOISE_EXT_RE.exec(url);
    if (noise) return { ok: false, reason: "静态资源或媒体分片(." + noise[1] + ")" };

    // 0) 响应类型明确说明这不是文件本体（HTML/JSON/图片等）→ 一票否决，
    //    避免把 .mp4/.pdf 之类的"伪装地址"（占位页、跳转页、错误页）当成课件
    const hintExt = extFromName(hint);
    if (mime && !MIME_TO_EXT[mime] && !AMBIGUOUS_MIME_RE.test(mime)) {
      return { ok: false, reason: "响应类型非课件(" + mime + ")" };
    }
    // 明确是课件 MIME 但与 URL 后缀冲突（如 .mp4 返回 application/pdf）以 MIME 为准，按 MIME 归类
    if (MIME_TO_EXT[mime] && COURSE_EXT_SET.has(hintExt) && MIME_TO_EXT[mime] !== hintExt) {
      const mExt0 = MIME_TO_EXT[mime];
      return { ok: true, ext: mExt0, kind: kindFromExt(mExt0), reason: "响应类型(覆盖地址后缀)" };
    }

    // 1) URL 路径后缀（最可靠）
    const uExt = extFromPath(url);
    if (COURSE_EXT_SET.has(uExt)) return { ok: true, ext: uExt, kind: kindFromExt(uExt), reason: "地址后缀" };

    // 2) 文件名线索（下载头 / 查询串 / pdfv 解码）
    if (COURSE_EXT_SET.has(hintExt)) return { ok: true, ext: hintExt, kind: kindFromExt(hintExt), reason: "文件名" };

    // 3) 精确 MIME
    const mExt = MIME_TO_EXT[mime];
    if (mExt) return { ok: true, ext: mExt, kind: kindFromExt(mExt), reason: "响应类型" };

    // 3.5) 平台原生文件下发接口：路径含文件类关键词 + 资源 ID（如 /resource/download/7056...）。
    // 这类地址没有后缀、MIME 可能是 octet-stream 甚至为空，但语义明确是课件下发，必须放行。
    if (looksLikePlatformFileApi(url)) {
      const ext0 = (uExt && COURSE_EXT_SET.has(uExt) ? uExt : "") || hintExt || "bin";
      return { ok: true, ext: ext0, kind: kindFromExt(ext0) || "文件", reason: "平台文件接口(资源ID)" };
    }

    // 4) 二进制流：严格模式下必须有文件名线索才算课件（避免任何 zip/二进制都进来）
    if (AMBIGUOUS_MIME_RE.test(mime)) {
      if (!strict) return { ok: true, ext: uExt && COURSE_EXT_SET.has(uExt) ? uExt : "bin", kind: "文件", reason: "宽松模式(二进制流)" };
      return { ok: false, reason: "二进制流且无课件文件名线索" };
    }

    return { ok: false, reason: "非课件类型" + (mime ? "(" + mime + ")" : "") };
  }

  // 平台文件下发接口的特征：
  //   · 路径里必须有"下载动词段"（download / file / material / attach / content），
  //     而不是随便含 resource —— 后者会命中 /mycourse/<id>/resource/<id> 这类**页面路由**，
  //     把网页当成文件收进来（下载后就是 .htm，名字还是空的）。
  //   · 必须带 10 位以上资源 ID。
  //   · 排除 SPA 页面路由特征（jx-web / mycourse / app 等）。
  const FILE_API_SEG_RE = /^(download|downloadfile|file|files|material|materials|attach|attachment|content|export)$/i;
  const PAGE_ROUTE_RE = /(^|\/)(app|jx-web|mycourse|course-detail|index\.html?|#)(\/|$)/i;
  function looksLikePlatformFileApi(url) {
    try {
      const p = new URL(String(url)).pathname;
      if (!p) return false;
      if (PAGE_ROUTE_RE.test(p)) return false;
      if (!/\d{10,}/.test(p)) return false;
      const segs = p.split("/").filter(Boolean);
      for (let i = 0; i < segs.length; i++) {
        if (FILE_API_SEG_RE.test(decodeURIComponent(segs[i]))) return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // 是否是"看起来像页面、不可能当文件下载"的地址（用于清理历史误收条目）
  function isPageLikeUrl(url) {
    try {
      const p = new URL(String(url)).pathname;
      if (extFromPath(url)) return false; // 有课件后缀就不算页面（extFromPath 需完整 URL）
      if (PAGE_ROUTE_RE.test(p)) return true;
      // 无后缀又无下载动词段的，基本是页面/接口
      return !looksLikePlatformFileApi(url);
    } catch (e) {
      return false;
    }
  }

  // 便宜的预筛：明显不可能是课件的请求不必进入后续判定（避免每个请求都查标签页）
  function looksCourseLike(url, mime, filenameHint) {
    const u = String(url || "");
    if (META_API_RE.test(u)) return false;
    if (u && NOISE_EXT_RE.test(u) && !/[?&]f=/.test(u)) return false;
    if (COURSE_EXT_SET.has(extFromPath(u))) return true;
    if (COURSE_EXT_SET.has(extFromName(filenameHint))) return true;
    if (COURSE_EXT_SET.has(extFromName(hintFromUrl(u)))) return true;
    if (MIME_TO_EXT[normMime(mime)]) return true;
    if (AMBIGUOUS_MIME_RE.test(normMime(mime))) return true;
    if (isPreviewHost(hostOf(u)) && /[?&]f=/.test(u)) return true;
    // 平台文件下发接口（无后缀、可能无 MIME，但有资源 ID）
    if (looksLikePlatformFileApi(u)) return true;
    return false;
  }

  /* ================= 文件名：从资源 JSON 里挑"真名" ================= */
  // 平台对象里往往同时有 groupName / teacherName / courseName / nodeName 等，
  // 若简单取"第一个含 name 的字段"，很容易把章节名、老师名当成文件名（实测踩过）。
  const NAME_KEY_TIER = [
    /^(fileName|originalName|resourceName|attachName|realName|sourceName|originName)$/i, // 最可信
    /^(name|title)$/i,                                                                     // 次之
    /(name|title)$/i,                                                                      // 最后
  ];
  // 这些词出现在键名里，多半是分类/组织信息，不是文件名
  const NAME_KEY_BLOCK = /(group|teacher|course|chapter|user|class|node|knowledge|label|tag|type|status|school|term|parent|package|menu|role|org|dept|subject|section|lesson|category|folder|space|team|author|owner|creator)/i;

  // 返回 {name, key, tier} 或 null（tier 越小越可信）
  function pickResourceName(obj) {
    if (!obj || typeof obj !== "object") return null;
    let best = null;
    for (const k of Object.keys(obj)) {
      const v = obj[k];
      if (typeof v !== "string") continue;
      const name = v.trim();
      if (!name || name.length > 160) continue;
      if (!/(name|title)/i.test(k)) continue;
      const isPreferred = /^(fileName|originalName|resourceName|attachName|realName|sourceName|originName)$/i.test(k);
      if (NAME_KEY_BLOCK.test(k) && !isPreferred) continue;
      let tier = 3;
      for (let i = 0; i < NAME_KEY_TIER.length; i++) {
        if (NAME_KEY_TIER[i].test(k)) { tier = i; break; }
      }
      if (!best || tier < best.tier) best = { name: name, key: k, tier: tier };
    }
    return best;
  }

  /* ================= 视频转码哈希名 ================= */
  // 阿里云 VOD 的转码文件名形如：
  //   fdb7876ad5bb4467b4579284366126c0-b13e45cffb4b4dc9044909eac2d70a69-ld.mp4
  // 这类名字不是课程资源名，需要凭其中的 videoId 反查真名。
  const VIDEO_HASH_RE = /^([0-9a-f]{16,40})(?:-[0-9a-f]{16,40})?(?:-(?:ld|sd|hd|fhd|uhd|od))?\.(?:mp4|m4v|m3u8|ts|flv)$/i;

  function videoIdFromName(name) {
    const m = VIDEO_HASH_RE.exec(String(name || "").trim());
    return m ? m[1].toLowerCase() : "";
  }

  function isPlaceholderVideoName(name) {
    return !!videoIdFromName(name);
  }

  // 从任意地址里取 32~40 位十六进制 videoId（播放链路常见 /play_auth/<id>、/<id>/index.m3u8）
  function videoIdFromUrl(url) {
    try {
      const u = String(url || "");
      const m = /[0-9a-f]{32,40}/i.exec(u.split("?")[0]);
      return m ? m[0].toLowerCase() : "";
    } catch (e) {
      return "";
    }
  }

  /* ================= DOM 扫描 ================= */
  const SCAN_SELECTOR =
    "a[href],iframe[src],embed[src],object[data],video[src],video source[src],audio[src],source[src]";

  function absUrl(raw, base) {
    try {
      return new URL(String(raw), base).href;
    } catch (e) {
      return "";
    }
  }

  // root：document 或其影子根（需提供 querySelectorAll）；ctx：{pageUrl, ancestorOrigins, referrer, strict, maxHtml}
  // 返回 [{url, ext, kind, reason}]
  function collectLearningLinks(root, ctx) {
    const o = ctx || {};
    let pageUrl = o.pageUrl;
    if (!pageUrl) {
      try { pageUrl = root && root.location ? root.location.href : ""; } catch (e) { pageUrl = ""; }
    }
    const learning = typeof o.learning === "boolean"
      ? o.learning
      : isLearningPage(pageUrl, o.ancestorOrigins, o.referrer, o.extraHosts);
    if (!learning) return [];

    const found = new Map();
    const strict = o.strict !== false;

    const push = (raw) => {
      if (typeof raw !== "string" || !raw) return;
      const s = raw.replace(/\\\//g, "/").replace(/&amp;/g, "&").trim();
      if (/^(data|blob|javascript|about|mailto|tel|chrome|edge):/i.test(s)) return;
      const abs = absUrl(s, pageUrl);
      if (!abs) return;
      if (found.has(abs)) return;
      const hint = /[?&]f=/.test(abs) ? decodePdfvName(abs) : "";
      const judged = classifyResource({ url: abs, learning: true, strict, filenameHint: hint });
      if (judged.ok) found.set(abs, { url: abs, ext: judged.ext, kind: judged.kind, reason: judged.reason });
    };

    // 1) 页面元素
    try {
      const els = root.querySelectorAll(SCAN_SELECTOR);
      for (let i = 0; i < els.length; i++) {
        const el = els[i];
        push(
          el.getAttribute("href") ||
            el.getAttribute("src") ||
            el.getAttribute("data") ||
            ""
        );
      }
    } catch (e) {}

    // 2) open shadow root（部分预览组件挂在影子树里）
    try {
      const all = root.querySelectorAll("*");
      for (let i = 0; i < all.length; i++) {
        const el = all[i];
        if (el.shadowRoot) {
          const nested = collectLearningLinks(el.shadowRoot, {
            pageUrl, ancestorOrigins: o.ancestorOrigins, referrer: o.referrer,
            extraHosts: o.extraHosts, learning: true, strict, maxHtml: 0,
          });
          nested.forEach((x) => { if (!found.has(x.url)) found.set(x.url, x); });
        }
      }
    } catch (e) {}

    // 3) 页面内联数据（JSON/JS 里常直接放着课件直链，含 \/ 转义）
    const maxHtml = typeof o.maxHtml === "number" ? o.maxHtml : 12 * 1024 * 1024;
    if (maxHtml > 0) {
      try {
        const html = root && root.documentElement ? root.documentElement.outerHTML : "";
        if (html && html.length < maxHtml) {
          const text = html.replace(/\\\//g, "/");
          const re = /https?:\/\/[^\s"'<>)]+/g;
          let m;
          let guard = 0;
          while ((m = re.exec(text)) !== null) {
            push(m[0]);
            if (++guard > 4000 || found.size > 200) break;
          }
        }
      } catch (e) {}
    }

    return Array.from(found.values());
  }

  // 判定一段文件名/存储路径文本是否带有平台文件证据
  function hasPlatformFileEvidence(text) {
    return PLATFORM_FILE_EVIDENCE_RE.test(String(text || ""));
  }

  return {
    PLATFORM_HOST_RE,
    PREVIEW_HOST_RE,
    PLATFORM_FILE_EVIDENCE_RE,
    DOC_EXTS,
    MEDIA_EXTS,
    COURSE_EXTS,
    MIME_TO_EXT,
    NOISE_EXT_RE,
    KIND_BY_EXT,
    hostOf,
    isPlatformHost,
    isPreviewHost,
    extFromPath,
    extFromName,
    normMime,
    kindFromExt,
    decodePdfvName,
    hintFromUrl,
    matchExtraHost,
    hasPlatformFileEvidence,
    isLearningPage,
    classifyResource,
    looksCourseLike,
    looksLikePlatformFileApi,
    isPageLikeUrl,
    pickResourceName,
    videoIdFromName,
    isPlaceholderVideoName,
    videoIdFromUrl,
    collectLearningLinks,
  };
});