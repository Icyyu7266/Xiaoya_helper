/* 断点续播 —— 记录课程视频的精确播放位置
 * 做两件事：
 *   1) 平台把视频重置回 0 / 重新加载时，自动跳回上次位置；
 *   2) 你从别的窗口切回标签页时，自动从暂停处继续播放。
 * 有意不做的事（边界）：
 *   - 标签页隐藏期间不维持播放、不拦截平台的暂停、不伪造任何进度；
 *     人不在时视频保持暂停，进度不会增长。恢复只发生在你真正回到标签页之后。
 * 已知限制：MSE 类播放器的地址是 blob:（每次随机），无法按地址定位，
 *           退化为「框架路径 + 时长」作键，绝大多数场景仍然有效。
 * 设置项：videoResume（默认开）；范围沿用 captureScoped / extraHosts。
 */
(function () {
  "use strict";

  const STORE_KEY = "resumePositions";
  const DEFAULTS = { videoResume: true };
  const MIN_SAVE_SECONDS = 5; // 少于 5 秒不值得记录
  const MIN_RESTORE_SECONDS = 20; // 累计进度不足 20 秒时不自动恢复（从头看更省事）
  const RESET_MAX_SECONDS = 10; // 当前位置 ≤10 秒视为"被重置回开头"
  const SAVE_INTERVAL_MS = 4000; // 节流：两次落盘至少间隔 4 秒（暂停/隐藏时强制落盘）
  const MAX_ENTRIES = 200; // 最多记录 200 个视频
  const ENTRY_TTL_MS = 45 * 86400000; // 记录 45 天后过期

  /* ===================== 纯逻辑（Node 可直接单测） ===================== */

  // 媒体稳定键：http(s) 直链用 origin+path（签名 query 会变，不能进键）；
  // blob:/MSE 用「框架路径 + 时长」当指纹
  function mediaKey(src, baseHref, framePath, duration) {
    try {
      const u = new URL(String(src || ""), baseHref || undefined);
      if (/^https?:$/.test(u.protocol)) return (u.origin + u.pathname).toLowerCase();
      if (/^blob:$/.test(u.protocol)) {
        const d = Math.max(0, Math.round(Number(duration) || 0));
        if (!d) return ""; // 时长未知时先不落键
        const fp = String(framePath || "").split("?")[0].toLowerCase();
        return fp + "#d" + d;
      }
      return "";
    } catch (e) {
      return "";
    }
  }

  // opts: { saved, current, duration }
  function shouldRestore(o) {
    const saved = Number(o && o.saved) || 0;
    const current = Number(o && o.current) || 0;
    const duration = Number(o && o.duration) || 0;
    if (saved < MIN_RESTORE_SECONDS) return false; // 进度太短
    if (current > RESET_MAX_SECONDS) return false; // 当前不在开头，别覆盖
    // 恢复要有意义：保存点必须明显超前于当前位置（比如 25 秒 vs 5 秒 → 跳回去没有意义）
    if (saved < current + MIN_RESTORE_SECONDS) return false;
    if (duration > 0 && saved >= duration - 3) return false; // 已经看到结尾，视为看完
    return true;
  }

  function shouldSaveNow(lastSavedAt, now, force) {
    if (force) return true;
    return !(now - (Number(lastSavedAt) || 0) < SAVE_INTERVAL_MS);
  }

  // 清理过期条目并按最近使用截断
  function pruneEntries(map, now) {
    const out = {};
    Object.keys(map || {})
      .map((k) => ({ k: k, v: map[k] }))
      .filter((r) => r.v && typeof r.v.t === "number" && now - (Number(r.v.at) || 0) <= ENTRY_TTL_MS)
      .sort((a, b) => (Number(b.v.at) || 0) - (Number(a.v.at) || 0))
      .slice(0, MAX_ENTRIES)
      .forEach((r) => { out[r.k] = r.v; });
    return out;
  }

  // 回到标签页时是否自动续播
  // st: { hiddenPaused, userPaused }；state: { visible, videoPaused, ended, sawPlaying }
  function shouldAutoResume(st, state) {
    if (!state || state.visible !== true) return false; // 只在真正回到标签页时动作
    if (!st || st.userPaused === true) return false; // 用户自己暂停的，不抢
    if (st.hiddenPaused !== true) return false; // 只有"因隐藏被平台暂停"才续
    if (!state.videoPaused || state.ended) return false;
    if (state.sawPlaying !== true) return false;
    return true;
  }

  const API = {
    STORE_KEY: STORE_KEY,
    DEFAULTS: DEFAULTS,
    MIN_SAVE_SECONDS: MIN_SAVE_SECONDS,
    MIN_RESTORE_SECONDS: MIN_RESTORE_SECONDS,
    RESET_MAX_SECONDS: RESET_MAX_SECONDS,
    SAVE_INTERVAL_MS: SAVE_INTERVAL_MS,
    MAX_ENTRIES: MAX_ENTRIES,
    ENTRY_TTL_MS: ENTRY_TTL_MS,
    mediaKey: mediaKey,
    shouldRestore: shouldRestore,
    shouldSaveNow: shouldSaveNow,
    pruneEntries: pruneEntries,
    shouldAutoResume: shouldAutoResume,
  };

  // Node 测试环境：只导出纯逻辑
  if (typeof window === "undefined" || typeof document === "undefined") {
    if (typeof module !== "undefined" && module.exports) module.exports = API;
    return;
  }
  if (window.__cdVideoResumeLoaded) return;
  window.__cdVideoResumeLoaded = true;

  /* ===================== 浏览器接线 ===================== */
  let settings = Object.assign({}, DEFAULTS);
  let extraHosts = "";
  let captureScoped = true;
  let store = {}; // resumePositions 内存缓存
  let storeReady = false;
  const tracked = []; // 本帧跟踪到的 video 元素
  const states = new WeakMap(); // video -> st

  const SCOPE = (typeof globalThis !== "undefined" && globalThis.CDScope) || null;

  function inScope() {
    if (!settings.videoResume) return false;
    if (!captureScoped) return true;
    if (!SCOPE) return false; // 规则模块缺失时保守不作为
    let ao = [];
    let referrer = "";
    try { ao = Array.prototype.slice.call(location.ancestorOrigins || []); } catch (e) {}
    try { referrer = document.referrer || ""; } catch (e) {}
    return SCOPE.isLearningPage(location.href, ao, referrer, extraHosts);
  }

  function loadSettings(cb) {
    try {
      chrome.storage.local.get(
        { videoResume: true, extraHosts: "", captureScoped: true },
        (d) => {
          settings.videoResume = d.videoResume !== false;
          extraHosts = d.extraHosts || "";
          captureScoped = d.captureScoped !== false;
          cb && cb();
        }
      );
      chrome.storage.onChanged.addListener((ch) => {
        if (!ch) return;
        if (ch.videoResume) settings.videoResume = ch.videoResume.newValue !== false;
        if (ch.extraHosts) extraHosts = ch.extraHosts.newValue || "";
        if (ch.captureScoped) captureScoped = ch.captureScoped.newValue !== false;
      });
    } catch (e) {
      cb && cb();
    }
  }

  function loadStore(cb) {
    try {
      chrome.storage.local.get(STORE_KEY, (d) => {
        store = pruneEntries((d && d[STORE_KEY]) || {}, Date.now());
        storeReady = true;
        cb && cb();
      });
    } catch (e) {
      storeReady = true;
      cb && cb();
    }
  }

  function persistStore() {
    try {
      const clean = pruneEntries(store, Date.now());
      store = clean;
      chrome.storage.local.set({ [STORE_KEY]: clean });
    } catch (e) {}
  }

  function savedFor(key) {
    if (!key || !storeReady) return 0;
    const rec = store[key];
    return rec && typeof rec.t === "number" ? rec.t : 0;
  }

  function remember(v, st, force) {
    if (!settings.videoResume) return;
    const t = Number(v.currentTime) || 0;
    if (t < MIN_SAVE_SECONDS) return;
    if (!st.key) {
      st.key = mediaKey(v.currentSrc || v.src, location.href, location.pathname, v.duration);
      if (!st.key) return;
    }
    if (!shouldSaveNow(st.lastSaveAt, Date.now(), force)) return;
    st.lastSaveAt = Date.now();
    store[st.key] = { t: t, at: Date.now() };
    persistStore();
  }

  function forget(st) {
    if (!st.key || !store[st.key]) return;
    delete store[st.key];
    persistStore();
  }

  // 平台把视频重置回开头时，恢复到上次位置（每个元素只做一次，之后绝不和用户抢进度条）
  function attemptRestore(v, st) {
    if (!settings.videoResume || st.restored) return;
    if (!st.key) {
      st.key = mediaKey(v.currentSrc || v.src, location.href, location.pathname, v.duration);
    }
    if (!st.key) return;
    if (v.readyState < 1) return; // 元数据未就绪，等 canplay 再来
    const saved = savedFor(st.key);
    if (!shouldRestore({ saved: saved, current: v.currentTime, duration: v.duration })) return;
    st.restored = true;
    try {
      v.currentTime = saved;
    } catch (e) {}
  }

  function tryResume(v, st) {
    if (!settings.videoResume) return;
    try {
      const p = v.play();
      if (p && typeof p.catch === "function") p.catch(() => {}); // 被自动播放策略拒绝就算了，不强来
    } catch (e) {}
  }

  function getState(v) {
    let st = states.get(v);
    if (!st) {
      st = { key: "", hiddenPaused: false, userPaused: false, restored: false, lastSaveAt: 0, sawPlaying: false, ended: false };
      states.set(v, st);
    }
    return st;
  }

  function hookVideo(v) {
    const st = getState(v);
    try {
      v.addEventListener("play", () => {
        st.sawPlaying = true;
        st.hiddenPaused = false;
        st.userPaused = false;
      });
      v.addEventListener("timeupdate", () => remember(v, st, false));
      v.addEventListener("pause", () => {
        remember(v, st, true); // 暂停时强制落盘
        if (typeof document !== "undefined" && document.hidden) st.hiddenPaused = true;
        else st.userPaused = true; // 可见状态下的暂停一律视为用户意图
      });
      v.addEventListener("ended", () => {
        st.ended = true;
        forget(st); // 看完了，清掉记录，下次重看从头开始
      });
      ["loadedmetadata", "loadeddata", "canplay", "durationchange"].forEach((ev) => {
        v.addEventListener(ev, () => attemptRestore(v, st));
      });
    } catch (e) {}
    // 挂钩时元数据可能已就绪（content script 注入晚于媒体加载）
    attemptRestore(v, st);
  }

  function collectVideos() {
    const set = new Set();
    try { document.querySelectorAll("video").forEach((x) => set.add(x)); } catch (e) {}
    try {
      (function walk(root) {
        const all = root.querySelectorAll("*");
        for (let i = 0; i < all.length; i++) {
          const el = all[i];
          if (el.tagName === "VIDEO") set.add(el);
          if (el.shadowRoot) walk(el.shadowRoot);
        }
      })(document);
    } catch (e) {}
    return Array.from(set);
  }

  function scan() {
    if (!settings.videoResume) return;
    let vids;
    try { vids = collectVideos(); } catch (e) { return; }
    for (let i = vids.length - 1; i >= 0; i--) {
      const v = vids[i];
      if (!v.isConnected) { vids.splice(i, 1); continue; }
      if (!states.has(v)) {
        if (!inScope()) continue;
        tracked.push(v);
        hookVideo(v);
      }
    }
  }

  // 回到标签页：把"因隐藏被暂停"的视频接上
  function onVisible() {
    if (!settings.videoResume) return;
    for (let i = tracked.length - 1; i >= 0; i--) {
      const v = tracked[i];
      if (!v.isConnected) { tracked.splice(i, 1); continue; }
      const st = states.get(v);
      if (!st) continue;
      if (!shouldAutoResume(st, {
        visible: document.visibilityState === "visible",
        videoPaused: v.paused,
        ended: v.ended,
        sawPlaying: st.sawPlaying,
      })) continue;
      st.hiddenPaused = false;
      tryResume(v, st);
    }
  }

  function flushAll() {
    if (!settings.videoResume) return;
    for (let i = 0; i < tracked.length; i++) {
      const v = tracked[i];
      if (!v.isConnected) continue;
      remember(v, states.get(v), true);
    }
  }

  try {
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") onVisible();
      else flushAll(); // 转入后台前把位置存稳
    });
    window.addEventListener("pagehide", flushAll);
    window.addEventListener("beforeunload", flushAll);
  } catch (e) {}

  let scanTimer = null;
  function scheduleScan() {
    if (scanTimer) return;
    scanTimer = setTimeout(() => { scanTimer = null; scan(); }, 300);
  }
  try {
    new MutationObserver(scheduleScan).observe(document.documentElement || document, {
      childList: true, subtree: true, attributes: true, attributeFilter: ["src"],
    });
  } catch (e) {}
  setInterval(scan, 2500);

  loadSettings(() => {
    loadStore(scan);
  });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scan);
    window.addEventListener("load", scan);
  }
})();