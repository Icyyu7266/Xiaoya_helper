// 内容脚本：扫描页面 DOM 中的课件链接 / blob 链接，并拦截动态创建的下载请求
// 识别规则统一来自 scope.js（与后台、主世界共用同一份判定，避免各处正则不一致）
try { chrome.runtime.sendMessage({ action: "debugNote", text: "content.js 已加载 " + location.pathname.slice(0, 60) }); } catch (e) {}

const CD_SCOPE = (typeof globalThis !== "undefined" && globalThis.CDScope) || null;

// 捕获范围设置（与后台/设置页共用同一组键）
let cdCaptureScoped = true;
let cdExtraHosts = "";
let cdStrict = true;

// 主世界没有 chrome.* API，需由本脚本转发设置
function pushSettingsToMainWorld() {
  try {
    window.postMessage({
      type: "CD_SETTINGS",
      captureScoped: cdCaptureScoped,
      extraHosts: cdExtraHosts,
      strictCapture: cdStrict,
    }, "*");
  } catch (e) {}
}

try {
  chrome.storage.local.get({ captureScoped: true, extraHosts: "", strictCapture: true }, (d) => {
    cdCaptureScoped = d.captureScoped !== false;
    cdExtraHosts = d.extraHosts || "";
    cdStrict = d.strictCapture !== false;
    pushSettingsToMainWorld();
  });
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.captureScoped) cdCaptureScoped = ch.captureScoped.newValue !== false;
    if (ch.extraHosts) cdExtraHosts = ch.extraHosts.newValue || "";
    if (ch.strictCapture) cdStrict = ch.strictCapture.newValue !== false;
    pushSettingsToMainWorld();
  });
} catch (e) {}
// 主世界脚本可能晚于本脚本就绪，启动后再补发一次
setTimeout(pushSettingsToMainWorld, 1000);

function ancestorOrigins() {
  try { return Array.prototype.slice.call(location.ancestorOrigins || []); } catch (e) { return []; }
}

// 当前页面是否属于课程学习上下文（含平台内嵌的预览框架、以及用户自定义站点）
function isLearningHere() {
  if (!CD_SCOPE) return false;
  let referrer = "";
  try { referrer = document.referrer || ""; } catch (e) {}
  return CD_SCOPE.isLearningPage(location.href, ancestorOrigins(), referrer, cdExtraHosts);
}

// 轻量日志上报：统一走后台落盘（CDLog），弹窗"日志"面板可见
function logEvent(lv, tag, msg) {
  try { chrome.runtime.sendMessage({ action: "logEvent", lv, tag, msg }); } catch (e) {}
}

function report(url, mime) {
  try {
    chrome.runtime.sendMessage({ action: "reportFile", url, mime });
  } catch (e) {}
}

function scanDom() {
  if (!CD_SCOPE) return;
  if (cdCaptureScoped && !isLearningHere()) return; // 非学习页面不采集任何链接
  let links = [];
  try {
    links = CD_SCOPE.collectLearningLinks(document, {
      pageUrl: location.href,
      ancestorOrigins: ancestorOrigins(),
      referrer: (function () {
        try { return document.referrer || ""; } catch (e) { return ""; }
      })(),
      extraHosts: cdExtraHosts,
      learning: !cdCaptureScoped ? true : undefined,
      strict: cdStrict,
    });
  } catch (e) {
    return;
  }
  links.forEach((x) => report(x.url, ""));
}

// ow365 预览页（pv.aspx）：把 bs 参数交给主世界，构造 pdfv 拿转码 PDF 版
if (/\/owview\/p\/pv\.aspx$/i.test(location.pathname)) {
  try {
    const bs = new URLSearchParams(location.search).get("bs") || "";
    if (bs) setTimeout(() => window.postMessage({ type: "CD_OWVIEW", bs }, "*"), 800);
  } catch (e) {}
}

// —— 小雅主动下载链路：交给页面主世界重放（content 世界无认证头） ——
let lastHarvestPath = "";

async function xyHarvest() {
  const path = location.pathname;
  if (path === lastHarvestPath) return;
  const m = path.match(/\/mycourse\/(\d+)\/resource\/(\d+)(?:\/(\d+))?/);
  if (!m) return;
  lastHarvestPath = path;
  const gid = m[1];
  const nid = m[3] || m[2];

  // 交给页面主世界重放（content 世界 fetch 无认证头，必 401）
  const urls = [
    location.origin + "/api/jx-iresource/resource/queryResource/v3?node_id=" + nid + "&group_id=" + gid,
    location.origin + "/api/jx-iresource/resource/queryCourseResources/v2?group_id=" + gid,
  ];
  window.postMessage({ type: "CD_XY_GET", urls }, "*");
}

// 拦截 fetch / XHR 响应，捕获 blob: 之前的真实地址
const origFetch = window.fetch;
window.fetch = async function (...args) {
  const url = typeof args[0] === "string" ? args[0] : args[0]?.url || "";
  const resp = await origFetch.apply(this, args);
  try {
    const ct = resp.headers.get("content-type") || "";
    // 交给统一规则判定：只有学习页面上下文中的课件才上报（严格度跟随用户设置）
    if (CD_SCOPE) {
      const judged = CD_SCOPE.classifyResource({
        url: resp.url || url,
        mime: ct,
        learning: cdCaptureScoped ? isLearningHere() : true,
        strict: cdStrict,
      });
      if (judged.ok) report(resp.url || url, ct);
    }
  } catch (e) {}
  return resp;
};

const origOpen = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function (method, url, ...rest) {
  try {
    if (typeof url === "string" && CD_SCOPE) {
      const judged = CD_SCOPE.classifyResource({
        url,
        learning: cdCaptureScoped ? isLearningHere() : true,
        strict: cdStrict,
      });
      if (judged.ok) report(url, "");
    }
  } catch (e) {}
  return origOpen.call(this, method, url, ...rest);
};

// 捕获页面通过 blob 下载的行为（记录触发时的事件路径）
const origCreate = URL.createObjectURL;
URL.createObjectURL = function (obj) {
  const u = origCreate.call(URL, obj);
  try {
    if (obj instanceof Blob) {
      report(u + "||blobname||" + (obj.type || ""));
    }
  } catch (e) {}
  return u;
};

// 桥接：popup 请求页面主世界下载文件 / HLS 下载
let seq = 0;
const pending = new Map(); // id -> {resolve}
let hlsWaiters = []; // (result)=>[] 回调

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "taskInfo" && msg.info) {
    // 后台回放"学习时长/任务完成"接口拿到的字段（不依赖页面注入时机）
    try {
      window.__cdTaskInfo = msg.info;
      document.dispatchEvent(new CustomEvent("cd-taskinfo", { detail: msg.info }));
    } catch (err) {}
    if (sendResponse) sendResponse({ ok: true });
    return;
  }
  if (msg.action === "pageHls") {
    // HLS 下载是长任务：等 CD_HLS_DONE 通知
    logEvent("info", "HLS", "开始下载 " + (msg.name || msg.url || "").slice(0, 80));
    hlsWaiters.push(sendResponse);
    window.postMessage({ type: "CD_HLS", url: msg.url, name: msg.name || "" }, "*");
    return true;
  }
  if (msg.action === "pageFetch") {
    const id = "cd" + ++seq;
    pending.set(id, { sendResponse });
    window.postMessage({ type: "CD_FETCH", id, url: msg.url }, "*");
    // 超时保护
    setTimeout(() => {
      if (pending.has(id)) {
        pending.get(id).sendResponse({ err: "超时：页面未响应（请刷新页面后重试）" });
        pending.delete(id);
      }
    }, 120000);
    return true;
  }
});

window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  const d = e.data;
  if (!d) return;
  if (d.type === "CD_DATA" && pending.has(d.id)) {
    pending.get(d.id).sendResponse({ b64: d.b64, name: d.name });
    pending.delete(d.id);
  } else if (d.type === "CD_ERROR" && pending.has(d.id)) {
    pending.get(d.id).sendResponse({ err: d.err });
    pending.delete(d.id);
  } else if (d.type === "CD_CAPTURE" && d.b64) {
    // 自动捕获的文件字节，交给后台保存
    try {
      chrome.runtime.sendMessage({ action: "saveCaptured", name: d.name, mime: d.mime, size: d.size, b64: d.b64 });
    } catch (err) {}
  } else if (d.type === "CD_MAPS" && d.maps) {
    // 主世界的 ID→文件名映射表 + 视频转码名映射 + 阿里云videoId映射，交给后台全局共享
    try {
      chrome.runtime.sendMessage({ action: "nameMaps", maps: d.maps, transMaps: d.transMaps || {}, videoMaps: d.videoMaps || {} });
    } catch (err) {}
  } else if (d.type === "CD_REALFILE" && d.url) {
    // 主世界拿到的真实下载地址（带真实文件名）
    try { chrome.runtime.sendMessage({ action: "reportFile", url: d.url, mime: "", name: d.name || "" }); } catch (err) {}
  } else if (d.type === "CD_TASKINFO" && d.info) {
    // 主世界从"学习时长/任务完成"接口抓到的字段，转交给页面内的自动提交模块
    // （同时落一条日志，便于确认这些接口到底返回了哪些时长字段）
    const f = (d.info.fields || []).slice(0, 6).map((x) => x.k + "=" + x.v).join(", ");
    if (f) logEvent("debug", "任务信息", (d.info.from || "") + " · " + f);
    try {
      window.__cdTaskInfo = d.info;
      document.dispatchEvent(new CustomEvent("cd-taskinfo", { detail: d.info }));
    } catch (err) {}
  } else if (d.type === "CD_NAMING" && d.text) {
    // 命名诊断：把主世界看到的候选名字/ID 记进日志，便于确定"真名在哪个字段"
    logEvent("info", "命名候选", String(d.text).slice(0, 300));
  } else if (d.type === "CD_NOTE" && d.text) {
    try {
      chrome.runtime.sendMessage({ action: "debugNote", text: d.text });
    } catch (err) {}
    // 主世界诊断文本转写日志：仅收警告/错误级（失败、未成功、异常、限制类），避免刷屏
    const t = String(d.text || "");
    if (/(未成功|失败|异常|限制|检测到|无法)/.test(t)) {
      logEvent(/(失败|异常)/.test(t) ? "error" : "warn", "主世界", t.slice(0, 200));
    }
  } else if (d.type === "CD_HLS_DONE") {
    // HLS 长任务结束：通知 popup（成功 text / 失败 err）
    logEvent(d.err ? "error" : "info", "HLS", d.err ? "下载失败: " + d.err : (d.text || "下载完成"));
    const w = hlsWaiters;
    hlsWaiters = [];
    w.forEach((fn) => {
      try { fn(d.err ? { err: d.err } : { ok: true, text: d.text || "" }); } catch (err) {}
    });
  }
});

// ============ 自动确认预览（可在设置页开启） ============
let autoConfirm = false;
try {
  chrome.storage.local.get({ autoConfirm: false }, (d) => (autoConfirm = !!d.autoConfirm));
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.autoConfirm) autoConfirm = !!ch.autoConfirm.newValue;
  });
} catch (e) {}

let lastAutoConfirm = 0;
function tryAutoConfirm() {
  if (!autoConfirm) return;
  const now = Date.now();
  if (now - lastAutoConfirm < 600) return;
  try {
    // 弹层特征：页面出现“是否确认打开文件”，且有文本为“确定”的按钮
    if (!/是否确认打开文件/.test(document.body.innerText)) return;
    for (const b of document.querySelectorAll("button")) {
      const t = (b.textContent || "").trim();
      if (t === "确定" && b.offsetParent !== null) {
        lastAutoConfirm = now;
        b.click();
        logEvent("info", "预览", "已自动确认预览弹层");
        return;
      }
    }
  } catch (e) {}
}

/* ---------- 命名诊断：把"界面上看到的名字"记进日志 ----------
 * 视频的名字常常取不到课程标题（平台 JSON 里给的是上传文件名），
 * 这里把页面标题 / h1 / 面包屑一并打出来，便于对症确定该用哪个来源。 */
let namingDiagSent = false;
function diagPageNaming() {
  try {
    if (namingDiagSent) return;
    if (typeof isLearningHere === "function" && !isLearningHere()) return;
    namingDiagSent = true;
    const norm = (s) => String(s || "").replace(/\s+/g, " ").trim();
    const title = norm(document.title).slice(0, 100);
    const h1 = document.querySelector("h1");
    const h1t = h1 ? norm(h1.textContent).slice(0, 100) : "";
    const crumbs = Array.prototype.slice
      .call(document.querySelectorAll('[class*="breadcrumb" i] li, [class*="breadcrumb" i] a, [class*="crumb" i]'))
      .slice(0, 8)
      .map((e) => norm(e.textContent))
      .filter((x) => x && x.length < 60)
      .join(" > ")
      .slice(0, 160);
    if (!title && !h1t && !crumbs) return;
    logEvent(
      "info",
      "命名候选",
      "页面标题=" + title + (h1t ? " | h1=" + h1t : "") + (crumbs ? " | 面包屑=" + crumbs : "")
    );
  } catch (e) {}
}
setTimeout(diagPageNaming, 4000);

new MutationObserver(() => {
  scanDom();
  xyHarvest();
  tryAutoConfirm();
}).observe(document.documentElement, {
  childList: true,
  subtree: true,
});
document.addEventListener("DOMContentLoaded", () => {
  scanDom();
  xyHarvest();
  tryAutoConfirm();
});
scanDom();
xyHarvest();
