// 后台：监听所有网络请求，只捕获「课程学习页面上下文中的课件」
// 识别规则统一来自 scope.js（与 content.js / main.js 共用同一份判定，避免各处正则不一致）
importScripts("scope.js");
const S = self.CDScope;
importScripts("logger.js");
const CDLog = self.CDLog;

/* ===================== 事件日志（排障用） =====================
 * 环形缓冲存 chrome.storage.local("eventLogs")；写操作节流合并。
 * 后台是唯一写入点；内容脚本/弹窗只上报。 */
let logs = [];
let logFlushTimer = null;
let logLoaded = false;
let logViewErrorsOnly = false;

function persistLogs() {
  try {
    chrome.storage.local.set({ eventLogs: logs });
  } catch (e) {}
}

function scheduleLogPersist() {
  if (logFlushTimer) return;
  logFlushTimer = setTimeout(() => {
    logFlushTimer = null;
    persistLogs();
  }, CDLog.FLUSH_MS);
}

// sender 信息折进出处，便于定位"发生在哪个页面"
function logEvent(lv, tag, msg, sender) {
  try {
    let where = "";
    if (sender && sender.tab && sender.tab.url) where = " @" + S.hostOf(sender.tab.url);
    logs = CDLog.append(logs, CDLog.makeEntry(lv, tag, msg, Date.now()));
    if (where) logs = CDLog.append(logs, CDLog.makeEntry(lv, tag, "  ↳ 来源" + where, Date.now()));
    scheduleLogPersist();
  } catch (e) {}
}

try {
  chrome.storage.local.get({ eventLogs: [] }, (d) => {
    logs = CDLog.sanitize(d.eventLogs || []);
    logLoaded = true;
    let ver = "";
    try { ver = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || ""; } catch (e) {}
    // 把版本号写进日志：便于确认浏览器里运行的到底是哪一份构建
    logEvent("info", "后台", "Service Worker 启动 v" + (ver || "?") + "，恢复日志 " + logs.length + " 条");
  });
} catch (e) {}

let captured = []; // {url, type, time, from}
let reqHeaders = new Map(); // url -> 页面发出的请求头（含 token）
let nameMap = {}; // ID -> 文件名（主世界收割，全局共享）
let transMaps = {}; // 视频转码文件名 -> 课程资源真名
let videoIdMaps = {}; // 阿里云videoId(32hex) -> 课程资源真名（HLS 源播放链路只有 videoId）

// 捕获范围设置：默认只捕获课程学习页面，严格拒绝非课件类型
let strictMode = true;
let extraHosts = "";
let captureScoped = true;
try {
  chrome.storage.local.get({ strictCapture: true, extraHosts: "", captureScoped: true }, (d) => {
    strictMode = d.strictCapture !== false;
    extraHosts = d.extraHosts || "";
    captureScoped = d.captureScoped !== false;
  });
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.strictCapture) strictMode = ch.strictCapture.newValue !== false;
    if (ch.extraHosts) extraHosts = ch.extraHosts.newValue || "";
    if (ch.captureScoped) captureScoped = ch.captureScoped.newValue !== false;
  });
} catch (e) {}

// 调试日志：记录所有请求的响应头信息（含被规则过滤的资源）
// 在使用它的 addFile / reportReject 之前声明，避免暂时性死区
let debugLog = [];

// 标签页 → 是否学习页面（带短缓存，避免每个请求都查标签页）
const learningTabs = new Map(); // tabId -> {v:boolean, t:number}
const LEARNING_TTL = 5000;

function rememberTab(tabId, url) {
  if (tabId == null || tabId < 0 || !url) return;
  try {
    learningTabs.set(tabId, { v: S.isLearningPage(url, [], "", extraHosts), t: Date.now() });
  } catch (e) {}
}

// 启动预热 + 导航时更新：避免"每个标签页的首个文件因缓存为空被丢弃"
try {
  chrome.tabs.query({}, (tabs) => {
    (tabs || []).forEach((t) => { if (t) rememberTab(t.id, t.url); });
  });
  chrome.tabs.onUpdated.addListener((id, info, tab) => {
    if (tab && tab.url) rememberTab(id, tab.url);
  });
  chrome.tabs.onRemoved.addListener((id) => learningTabs.delete(id));
} catch (e) {}

function isLearningTab(tabId) {
  if (!captureScoped) return true; // 用户显式关闭范围限制时退回全站（默认不关闭）
  if (tabId == null || tabId < 0) return false;
  const c = learningTabs.get(tabId);
  const now = Date.now();
  if (c && now - c.t < LEARNING_TTL) return c.v;
  try {
    chrome.tabs.get(tabId, (t) => {
      if (t && t.url) rememberTab(tabId, t.url);
      else learningTabs.set(tabId, { v: false, t: Date.now() });
    });
  } catch (e) {}
  // 缓存未命中且调用方没给页面地址时保守返回 false（宁可漏捕，不误捕）
  return c ? c.v : false;
}

// 统一判定入口：URL + MIME + 下载头文件名 + 页面上下文
// pageUrl：请求发起页的地址（webRequest 的 documentUrl/initiator、消息的 sender.tab.url）。
// 有它就能同步判定，不必等标签页缓存就绪——否则每个标签页的首个文件会被保守丢弃。
function judge(url, mime, tabId, hint, pageUrl) {
  try {
    if (!S) return { ok: false, reason: "规则模块未加载" };
    if (!S.looksCourseLike(url, mime, hint)) return { ok: false, reason: "预筛排除" };
    let learning;
    if (!captureScoped) {
      learning = true; // 用户显式关闭范围限制
    } else if (pageUrl) {
      try {
        learning = S.isLearningPage(pageUrl, [], "", extraHosts);
      } catch (e) {
        learning = isLearningTab(tabId);
      }
    } else {
      learning = isLearningTab(tabId);
    }
    return S.classifyResource({
      url,
      mime,
      filenameHint: hint,
      learning,
      strict: strictMode,
    });
  } catch (e) {
    return { ok: false, reason: "判定异常" };
  }
}

// 用映射表为 URL 里的 ID 找文件名；视频转码名（UUID-xx.mp4）查 transMaps
function mapName(url) {
  if (!url) return "";
  for (const [id, nm] of Object.entries(nameMap)) {
    if (url.includes(id)) return nm;
  }
  try {
    const tail = decodeURIComponent(url.split("?")[0].split("/").pop() || "");
    if (transMaps[tail]) return transMaps[tail];
  } catch (e) {}
  return "";
}
// 数字名/无名条目回溯改名（视频转码名优先用 transMaps 强制改名）
function applyName(it) {
  try {
    const tail = decodeURIComponent((it.url || "").split("?")[0].split("/").pop() || "");
    if (tail && transMaps[tail]) {
      it.name = transMaps[tail];
      return;
    }
  } catch (e) {}

  // 视频转码哈希名（如 fdb7…-b13e…-ld.mp4）不是课程名：凭其中的 videoId 反查真名。
  // 哈希名也可能出现在 name 而不是 url 尾段（HLS 的 index.m3u8 目录名等）。
  try {
    if (S) {
      let hashTail = "";
      try {
        hashTail = decodeURIComponent((it.url || "").split("?")[0].split("/").pop() || "");
      } catch (e2) {
        hashTail = "";
      }
      const cur = S.isPlaceholderVideoName(it.name) ? it.name : "";
      const names = [cur, hashTail].filter(Boolean);
      for (const n of names) {
        const vid = S.videoIdFromName(n);
        if (vid && videoIdMaps[vid]) {
          it.name = videoIdMaps[vid];
          logNamedOnce("视频", vid, it.name);
          return;
        }
      }
      // 地址里带 videoId 也能反查
      const uvid = S.videoIdFromUrl(it.url);
      if (uvid && videoIdMaps[uvid]) {
        it.name = videoIdMaps[uvid];
        logNamedOnce("视频", uvid, it.name);
        return;
      }
    }
  } catch (e) {}

  // 截获条目名字以 19 位 qid 开头（如 7066..._7066....pdf）→ 用映射表换真名（保留实际格式扩展名）
  const qm = /^(\d{10,})/.exec(it.name || "");
  if (qm && nameMap[qm[1]]) {
    const real = nameMap[qm[1]];
    const realBase = real.replace(/\.(pptx?|docx?|xlsx?|pdf|zip)$/i, "");
    const curExt = (it.name.match(/\.[a-z0-9]{2,5}$/i) || [""])[0];
    const origExt = (real.match(/\.[a-z0-9]{2,5}$/i) || [""])[0];
    // 截获的是转码 PDF 版：名字用真名 + .pdf；若截获扩展名与原格式一致则直接用真名
    it.name = /^\.pdf$/i.test(curExt) && !/^\.pdf$/i.test(origExt) ? realBase + ".pdf" : real;
    return;
  }
  if (it.name && /\.[a-z0-9]{2,5}$/i.test(it.name) && !/^\d{8,}[_.]/.test(it.name)) return;
  const nm = mapName(it.url);
  if (nm) { it.name = nm; return; }
  // 兜底：映射表还没到时，用地址尾段的真实文件名（如 .../oss/数学.pptx）。
  // 不兜底会留下"空白名"条目，和转码条目无法配对，正是重复条目的来源之一。
  if (!it.name) {
    const fb = fileNameFromUrl(it.url);
    if (fb) it.name = fb;
  }
}

// 去掉扩展名比较是否同一个名字
function sameNameIgnoringExt(a, b) {
  const strip = (s) => String(s || "").replace(/\.[a-z0-9]{2,5}$/i, "").trim();
  return strip(a) === strip(b);
}

// 用新名字替换，但保留条目现有的（更准确的）扩展名：真名常无后缀
function keepExt(real, cur) {
  const r = String(real || "").trim();
  if (!r) return cur;
  if (/\.[a-z0-9]{2,5}$/i.test(r)) return r;
  const m = /\.[a-z0-9]{2,5}$/i.exec(String(cur || ""));
  return m ? r + m[0] : r;
}

// 名字"好坏"打分：中文、更长更像课程名；哈希/转码后缀减分。
// 目的：别让后到的上传文件名把先到的课程标题顶掉（实测踩过：正确标题被覆盖成 9.6何平6VA0.mp4）。
function nameScore(nm) {
  const s = String(nm || "");
  let v = Math.min(s.length, 60);
  if (/[\u4e00-\u9fa5]/.test(s)) v += 40;
  if (/^[0-9a-f]{16,40}(-|\.)/i.test(s)) v -= 60;
  if (/(^|[^a-z0-9])(ld|sd|hd)\.(mp4|m3u8)$/i.test(s)) v -= 20;
  return v;
}

// 合并映射：只在"更好"时才覆盖
function mergeInto(target, incoming) {
  const src = incoming || {};
  let changed = 0;
  for (const k of Object.keys(src)) {
    const v = src[k];
    if (!v || typeof v !== "string") continue;
    const cur = target[k];
    if (!cur || nameScore(v) > nameScore(cur)) {
      if (cur !== v) changed++;
      target[k] = v;
    }
  }
  return changed;
}

function mergeNameMap(incoming) {
  return mergeInto(nameMap, incoming);
}

function mergeVideoMaps(cur, incoming) {
  const out = Object.assign({}, cur);
  mergeInto(out, incoming);
  return out;
}

// 命名日志（同一映射只记一次，便于排查"名字从哪来"）
const namedSeen = new Set();function logNamedOnce(kind, key, name) {
  try {
    const k = kind + "|" + key;
    if (namedSeen.has(k)) return;
    namedSeen.add(k);
    if (namedSeen.size > 300) namedSeen.clear();
    logEvent("info", "命名", kind + " " + String(key).slice(0, 12) + "… → " + CDLog.clampText(name, 80));
  } catch (e) {}
}

// 从地址尾段取文件名（仅当看起来是课件）
function fileNameFromUrl(url) {  try {
    const seg = decodeURIComponent(String(url || "").split("?")[0].split("/").pop() || "");
    if (!seg) return "";
    if (!/\.(pdf|pptx?|docx?|xlsx?|zip|m4a|mp4|m3u8)$/i.test(seg)) return "";
    return seg;
  } catch (e) {
    return "";
  }
}

// 占位名：地址本身没有文件名时（如 /resource/download/7066...），
// 用「末段（通常是资源ID）+ 类型后缀」造一个稳定名字。
// 保留资源ID很关键：后续 nameMap 到位时能反查出真名，重复条目也才能按 ID 配对合并。
function placeholderName(url, ext) {
  const suffix = String(ext || "").toLowerCase() || "bin";
  const fromUrl = fileNameFromUrl(url);
  if (fromUrl) return fromUrl;
  let tail = "";
  try {
    const parts = String(url || "").split("?")[0].split("/").filter(Boolean);
    tail = decodeURIComponent(parts[parts.length - 1] || "");
  } catch (e) {
    tail = "";
  }
  // 末段可能是资源ID、hash、或 download 这类动词；动词没有区分度，改用时间戳
  if (tail && !/^(download|file|resource|view|preview|get|api|content)$/i.test(tail)) {
    return tail + "." + suffix;
  }
  return "资源_" + Date.now().toString(36) + "." + suffix;
}
function refreshNames() {
  const before = captured.map((c) => c.name).join("|");
  captured.forEach(applyName);
  // 视频：如果已经知道它对应的资源 ID，而资源列表里给了标题，就用标题覆盖
  // （视频文件名常是上传名/哈希，资源标题才是"课程里的那个名字"）
  captured.forEach((c) => {
    try {
      if (!c.resId) return;
      const real = nameMap[c.resId];
      if (!real) return;
      if (c.name === real) return;
      if (sameNameIgnoringExt(c.name, real)) return;
      c.name = keepExt(real, c.name);
    } catch (e) {}
  });
  // 名字映射晚到会改变条目名 → 改名后再跑一次关联合并，消化此前无法配对的重复
  const merged = dedupeAll(captured);
  if (merged.length !== captured.length) {
    logEvent("info", "去重", "映射到位后合并了 " + (captured.length - merged.length) + " 条重复条目");
    captured = merged;
  }
  const after = captured.map((c) => c.name).join("|");
  if (before !== after) save();
  else if (merged.length !== captured.length) save();
}

// 启动时恢复（清除 file_url 接口误存条目与旧版 pdfv 构造残留），并清理重复条目
chrome.storage.local.get({ captured: [] }, (d) => {
  captured = (d.captured || []).filter(
    (c) =>
      c.dataUrl ||
      (/^https?:\/\//i.test(c.url || "") &&
        !/cloud\/file_url\//i.test(c.url) &&
        !/x1\.ow365\.cn\/pdfv\//i.test(c.url))
  );
  // 修复历史遗留的"空白名"条目；并清理"页面路由"误收条目
  // （URL 无课件后缀、又不像文件下发接口的，下载下来只会是 .htm）
  let repaired = 0;
  let dropped = 0;
  captured = captured.filter((c) => {
    if (c.dataUrl) return true;
    try {
      if (S && S.isPageLikeUrl && S.isPageLikeUrl(c.url)) {
        dropped++;
        logEvent("info", "去重", "移除误收的页面条目: " + CDLog.clampText(c.url, 100));
        return false;
      }
    } catch (e) {}
    if (!String(c.name || "").trim()) {
      const ext = (/\.([a-z0-9]{1,6})(?:[?#]|$)/i.exec(String(c.url || "")) || [])[1] || "bin";
      c.name = placeholderName(c.url, ext);
      repaired++;
    }
    return true;
  });
  const beforeLen = captured.length;
  captured = dedupeAll(captured);
  if (repaired) logEvent("info", "去重", "修复空白名条目 " + repaired + " 条");
  if (dropped) logEvent("info", "去重", "清理页面误收条目 " + dropped + " 条");
  if (captured.length !== beforeLen) {
    logEvent("info", "去重", "启动时合并重复条目 " + (beforeLen - captured.length) + " 条");
  }
  chrome.storage.local.set({ captured });
});

// ========== 去重核心 ==========
// 同一个课件会同时走两条通道：网络直链（addFile）与预览字节截获（saveCaptured）。
// 平台会把 PPT/Word 转成 PDF 供预览，于是出现"数学.pptx + 数字名.pdf"或"数学.pptx + 空名"
// 两条记录。这里以「资源ID → 真名」映射（nameMap）为桥梁把两条并成一条。
// 规则：
//   1) 名字可确定（真名，或占位名经 nameMap 解析）→ 按「基名」分组，扩展名兼容即合并；
//      pdf 与 office 互为转码，视为同一文件的两种形态；
//   2) 名字仍无法确定但带资源ID → 与 URL 含同一 ID 的直链条目配对，借其名字后合并；
//   3) 既无真名也无 ID → 保持原样（宁可多留，不误删用户数据）。
function normNameKey(n) {
  return String(n || "").trim().toLowerCase().replace(/\s+/g, "");
}
function extOfName(n) {
  const m = /\.([a-z0-9]{1,6})\s*$/i.exec(String(n || "").trim());
  return m ? m[1].toLowerCase() : "";
}
function baseNameKey(n) {
  const k = normNameKey(n);
  return k ? k.replace(/\.[a-z0-9]{1,6}$/i, "") : "";
}
function isPlaceholderName(n) {
  if (!n) return true; // 空名
  const s = String(n).trim();
  if (!s) return true;
  if (/^\d{8,}[_.\-]/.test(s)) return true; // 7066..._7066....pdf
  if (/^[_\-.]+/.test(s)) return true; // guessName 兜底的路径哈希
  if (extOfName(s) && /^[0-9_\-a-f]{16,}$/i.test(s.replace(/\.[a-z0-9]{1,6}$/i, ""))) return true; // 纯ID/哈希名
  return false;
}
// 扩展名是否"同一文件的不同形态"：相同，或 pdf ↔ office（平台转码）
function extCompatible(a, b) {
  const x = String(a || "").toLowerCase();
  const y = String(b || "").toLowerCase();
  if (!x || !y) return true; // 有一方未知时允许（配合基名同名才合并）
  if (x === y) return true;
  const office = /^(pptx?|docx?|xlsx?)$/;
  if (x === "pdf" && office.test(y)) return true;
  if (y === "pdf" && office.test(x)) return true;
  return false;
}
// 推导条目的规范名：真名优先，占位名则用 nameMap[资源ID] 反查
function canonicalNameOf(c) {
  const raw = String((c && c.name) || "").trim();
  if (raw && !isPlaceholderName(raw)) return raw;
  const idm = /\d{10,}/.exec(raw + " " + String((c && c.url) || ""));
  if (idm && nameMap[idm[0]]) {
    const real = nameMap[idm[0]];
    // 字节条目是转码 PDF 版：真名是 office 文档时用 真名.pdf
    if (extOfName(raw) === "pdf" && /^(pptx?|docx?|xlsx?)$/.test(extOfName(real))) {
      return real.replace(/\.[a-z0-9]{1,6}$/i, "") + ".pdf";
    }
    return real;
  }
  return "";
}
// 两条合并后取哪个名字：优先能表达"真名"的一方；转码关系则拼 真名.pdf
function pickMergedName(a, b) {
  const an = String(a || "").trim();
  const bn = String(b || "").trim();
  if (!an) return bn;
  if (!bn) return an;
  if (extOfName(an) === "pdf" && /^(pptx?|docx?|xlsx?)$/.test(extOfName(bn))) {
    return bn.replace(/\.[a-z0-9]{1,6}$/i, "") + ".pdf";
  }
  if (extOfName(bn) === "pdf" && /^(pptx?|docx?|xlsx?)$/.test(extOfName(an))) {
    return an.replace(/\.[a-z0-9]{1,6}$/i, "") + ".pdf";
  }
  if (isPlaceholderName(an) && !isPlaceholderName(bn)) return bn;
  return an;
}
// 把 drop 合并进 keep（keep 优先保留字节条目、直链 url、更早时间）
function mergeEntry(keep, drop) {
  keep.name = pickMergedName(keep.name, drop.name);
  keep.time = Math.min(keep.time || drop.time || 0, drop.time || keep.time || 0) || keep.time;
  if (!keep.size && drop.size) keep.size = drop.size;
  if (!keep.dataUrl && drop.dataUrl) {
    keep.dataUrl = drop.dataUrl;
    keep.type = drop.type || keep.type;
  }
  const keepUrlBad = !keep.url || /^捕获: /.test(keep.url);
  if (keepUrlBad && drop.url && /^https?:/i.test(drop.url)) keep.url = drop.url;
}

function dedupeAll(list) {
  const removed = new Set();
  const items = (list || []).map((c) => {
    const canon = canonicalNameOf(c);
    return { c: c, base: baseNameKey(canon), ext: extOfName(canon || c.name) };
  });

  // 规则 2：名字不可确定但带资源ID → 与 URL 含同一 ID 的直链条目配对（借名后交给规则 1）
  for (const it of items) {
    if (it.base || removed.has(it.c) || !it.c.dataUrl) continue;
    const idm = /\d{10,}/.exec(String(it.c.name || "") + " " + String(it.c.url || ""));
    if (!idm) continue;
    const id = idm[0];
    const target = items.find(
      (o) =>
        !removed.has(o.c) &&
        o.c !== it.c &&
        new RegExp(id).test(String(o.c.url || "") + " " + String(o.c.name || ""))
    );
    if (!target) continue;
    mergeEntry(it.c, target.c);
    removed.add(target.c);
    it.base = baseNameKey(it.c.name);
    it.ext = extOfName(it.c.name);
  }

  // 规则 1：按基名分组合并（组内按扩展名兼容性两两合并，字节条目优先当 keep）
  const groups = new Map();
  for (const it of items) {
    if (removed.has(it.c) || !it.base) continue;
    if (!groups.has(it.base)) groups.set(it.base, []);
    groups.get(it.base).push(it.c);
  }
  for (const [, group] of groups) {
    if (group.length < 2) continue;
    // keep：优先带字节、其次更早
    group.sort((x, y) => {
      const bx = x.dataUrl ? 1 : 0;
      const by = y.dataUrl ? 1 : 0;
      if (bx !== by) return by - bx;
      return (x.time || 0) - (y.time || 0);
    });
    const keeper = group[0];
    for (let i = 1; i < group.length; i++) {
      const other = group[i];
      if (removed.has(other)) continue;
      if (!extCompatible(extOfName(keeper.name), extOfName(other.name))) continue;
      mergeEntry(keeper, other);
      removed.add(other);
    }
  }

  return (list || []).filter((c) => !removed.has(c));
}

function save() {
  // 只保留最近 200 条
  captured = captured.slice(-200);
  chrome.storage.local.set({ captured });
}

function addFile(url, from, name, tabId, pageUrl) {
  // 只接受合法网络地址
  if (!url || !/^https?:\/\//i.test(url)) return;
  // 这几个接口返回 JSON 元数据，不是文件本体（即使查询串以 .pdf 结尾也不捕获）
  if (/cloud\/file_url\/|queryResource|queryCourseResources|aliyuncs\.com\/\?Action=GetPlayInfo/i.test(url)) return;
  // pdfv 地址本体不可直抓（会话绑定），数据走 CD_CAPTURE dataUrl 通道，不存 URL 条目
  if (/x1\.ow365\.cn\/pdfv\//i.test(url)) return;

  // 统一规则判定：必须是课件类型，且处于课程学习页面上下文
  const mime = String(from || "");
  let hint = name || "";
  if (!hint && /[?&]f=/.test(url)) {
    try { hint = S.decodePdfvName(url) || ""; } catch (e) {}
  }
  const judged = judge(url, mime, tabId, hint, pageUrl);
  if (!judged.ok) {
    reportReject(url, judged.reason); // 调试面板可见：便于确认"没误捕"
    logEvent("debug", "捕获", "已过滤: " + judged.reason + " · " + CDLog.clampText(url, 120));
    return;
  }

  const known = captured.find((c) => c.url === url);
  if (known) {
    if (name && (!known.name || /^\d{8,}\./.test(known.name))) known.name = name;
    save();
    return;
  }
  captured.push({
    url,
    type: S.kindFromExt(judged.ext),
    time: Date.now(),
    from: mime || "",
    name: name || "",
  });
  const it = captured[captured.length - 1];
  if (!name) applyName(it);
  // 兜底命名：绝不允许留下"空白名"条目——空名无法与已命名条目按基名配对，
  // 就会出现"数学.pptx + 空白名"两条并存。拿不到真名时用「地址尾段/资源ID + 类型后缀」占位。
  if (!it.name) it.name = placeholderName(it.url, judged.ext);
  logEvent("info", "捕获", "新增 " + it.type + " · " + CDLog.clampText(it.name || url, 100));
  // 同名合并：若此直链与已有字节条目实为同一文件（规范名一致），合并而不是并存
  const merged = dedupeAll(captured);
  if (merged.length !== captured.length) captured = merged;
  // 视频条目（mp4/m3u8）按稳定 key 去重：同一视频重复播放/签名刷新只更新地址，不新增条目
  const vk = videoKey(url);
  if (vk) {
    const dup = captured.find((c) => c !== it && videoKey(c.url) === vk);
    if (dup) {
      dup.url = url; // 刷新为最新签名地址（利于下载）
      captured = captured.filter((c) => c !== it);
      save();
      return;
    }
    // 进入配对队列，与最近的 vod/duration/<资源ID> 严格一对一配对
    videoTailQ.push({ tail: vk, t: Date.now() });
    tryPairVideos();
    dedupeVideos();
  }
  save();
}

// 被规则拒绝的资源记入调试面板（限流，避免刷屏）
const rejectedSeen = new Set();
function reportReject(url, reason) {
  try {
    const key = url.split("?")[0].slice(0, 120) + "|" + reason;
    if (rejectedSeen.has(key)) return;
    rejectedSeen.add(key);
    if (rejectedSeen.size > 400) rejectedSeen.clear();
    debugLog.push({ url: url.slice(0, 150), ct: "已过滤: " + reason, len: 0, time: Date.now(), status: "SKIP" });
    if (debugLog.length > 300) debugLog = debugLog.slice(-300);
  } catch (e) {}
}

// 同一视频可能同时以 mp4 与 m3u8 双源被捕获（配对后名字相同），合并保留更优格式
function dedupeVideos() {
  const prio = (c) => (c.name ? 100 : 0) + (c.type === "视频" ? 10 : 0);
  const groups = {};
  for (const c of captured) {
    if (c.type !== "视频" && c.type !== "视频HLS") continue;
    const nm = (c.name || "").replace(/\.[a-z0-9]{2,5}$/i, "").trim();
    if (!nm) continue;
    if (!groups[nm] || prio(c) > prio(groups[nm])) {
      if (groups[nm]) captured = captured.filter((x) => x !== groups[nm]);
      groups[nm] = c;
    } else {
      captured = captured.filter((x) => x !== c);
    }
  }
}

// 视频条目稳定 key：mp4 用转码文件名，m3u8 用目录/文件（index.m3u8 多视频重名，需带目录）
function videoKey(url) {
  try {
    const path = decodeURIComponent((url || "").split("?")[0]);
    if (/\.mp4$/i.test(path) && /vod\.ai-augmented\.com/i.test(url)) return path.split("/").pop();
    if (/\.m3u8$/i.test(path) && /vod|m3u8|video/i.test(url)) {
      const segs = path.split("/").filter(Boolean);
      return segs.slice(-2).join("/");
    }
  } catch (e) {}
  return "";
}

// 视频资源配对：duration/<资源ID>、play_auth/<阿里云videoId> 与 mp4/m3u8 播放请求前后脚出现，一对一队列配对
const VIDEO_ID_RE = /\/vod\/(?:duration|info|play|playinfo)[^/]*\/(\d{10,})|\/play_auth\/([0-9a-f]{16,40})|[?&](?:resource_id|resourceId|file_id|fileId|quote_id)=(\d{10,})/;
let videoIdQ = []; // {id, t}
let videoTailQ = []; // {tail, t}

function tryPairVideos() {
  const now = Date.now();
  // 挂起保留 2 分钟（映射晚到也能补上），配对窗口 30 秒
  videoIdQ = videoIdQ.filter((x) => now - x.t < 120000);
  videoTailQ = videoTailQ.filter((x) => now - x.t < 120000);
  while (
    videoIdQ.length &&
    videoTailQ.length &&
    Math.abs(videoIdQ[0].t - videoTailQ[0].t) < 30000
  ) {
    const { id } = videoIdQ.shift();
    const { tail } = videoTailQ.shift();
    const nm = nameMap[id] || videoIdMaps[id];
    // 记下配对的资源 ID：即便当前用的是视频文件名，等资源列表的真标题到位后还能覆盖
    captured.forEach((c) => {
      if (videoKey(c.url) === tail) c.resId = id;
    });
    if (nm && !transMaps[tail]) {
      transMaps[tail] = nm;
      captured.forEach((c) => {
        if (videoKey(c.url) === tail) c.name = nm;
      });
      dedupeVideos();
      save();
    }
  }
}

function guessType(url) {
  const s = String(url || "");
  // 类型名交给统一规则（scope.js），保证与捕获判定一致。
  // 注意：字节条目的 url 形如 "捕获: 数学.docx"，不是合法 URL，
  // 所以先从字符串尾段取后缀，再退回按 URL 解析。
  try {
    if (S) {
      const m = /\.([a-z0-9]{1,6})(?:[?#]|$)/i.exec(s);
      if (m) {
        const byExt = S.kindFromExt(m[1].toLowerCase());
        if (byExt && byExt !== "文件") return byExt;
      }
      const byPath = S.kindFromExt(S.extFromPath(s));
      if (byPath && byPath !== "文件") return byPath;
    }
  } catch (e) {}
  if (/\.pdf(\?|$)/i.test(s)) return "PDF";
  if (/\.pptx?(\?|$)/i.test(s)) return "PPT";
  if (/\.docx?(\?|$)/i.test(s)) return "Word";
  if (/\.xlsx?(\?|$)/i.test(s)) return "Excel";
  if (/\.(mp4)(\?|$)/i.test(s)) return "视频";
  if (/\.m3u8(\?|$)/i.test(s)) return "视频HLS";
  return "文件";
}

/* ---------- 任务信息：回放"学习时长/任务完成"接口，直读时长要求 ---------- */
// 页面里的接口（learnLength/learnRecord、resource/task/studentFinishInfo…）通常带着
// 「要求学习多久」的字段。页内 hook 有注入时机的风险，所以这里由后台自己回放一次，
// 把 JSON 里"像时长"的字段摘出来记进日志，并转给页内的自动提交模块。
const TASKINFO_URL_RE = /(learnLength|learnRecord|studentFinishInfo|resource\/task|activity\/info|resource\/detail)/i;
const taskInfoSeen = new Map(); // 接口路径 -> 上次回放时间

function extractDurationFields(text) {
  const out = [];
  const KEY_RE = /"([A-Za-z_][\w]{1,40})"\s*:\s*"?(\d{1,9})"?/g;
  const HINT_RE = /(learn|study|watch|read|finish|complete|require|need|limit|min|duration|length|time|progress|second|minute)/i;
  let m;
  let n = 0;
  while ((m = KEY_RE.exec(text)) !== null && n < 40) {
    const k = m[1];
    const v = Number(m[2]);
    if (!HINT_RE.test(k) || !isFinite(v) || v <= 0) continue;
    out.push({ k: k, v: v });
    n++;
  }
  return out;
}

function replayTaskInfo(url, tabId) {
  try {
    if (!TASKINFO_URL_RE.test(url || "")) return;
    const key = String(url).split("?")[0];
    const now = Date.now();
    if (now - (taskInfoSeen.get(key) || 0) < 20000) return; // 限流，别反复打接口
    taskInfoSeen.set(key, now);

    const hdrs = {};
    const h = reqHeaders.get(url);
    if (h && h.length) {
      h.forEach((x) => {
        if (!x || !x.name) return;
        // 只带业务头（token 之类），这几个由浏览器自己管
        if (/^(host|content-length|connection|cookie|origin|referer|sec-|accept-encoding)$/i.test(x.name)) return;
        hdrs[x.name] = x.value;
      });
    }
    fetch(url, { credentials: "include", headers: hdrs })
      .then((r) => (r && r.ok ? r.text() : ""))
      .then((t) => {
        if (!t || t.length > 1000000) return;
        const fields = extractDurationFields(t);
        if (!fields.length) return;
        const info = { from: key.slice(-60), fields: fields.slice(0, 12), at: Date.now() };
        logEvent("info", "任务信息", info.from + " · " + fields.slice(0, 6).map((f) => f.k + "=" + f.v).join(", "));
        if (tabId != null && tabId >= 0) {
          try { chrome.tabs.sendMessage(tabId, { action: "taskInfo", info }); } catch (e) {}
        }
      })
      .catch(() => {});
  } catch (e) {}
}

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const h = details.responseHeaders || [];
    const get = (n) => (h.find((x) => x.name.toLowerCase() === n) || {}).value || "";
    const mime = get("content-type");
    // 从下载头提取真实文件名，作为课件类型判定线索
    let hint = "";
    const cd = get("content-disposition");
    if (cd) {
      const m = /filename\*?=(?:UTF-8''|")?([^";]+)/i.exec(cd);
      if (m) {
        try { hint = decodeURIComponent(m[1].replace(/"/g, "")); } catch (e) { hint = m[1].replace(/"/g, ""); }
      }
    }
    addFile(details.url, mime, hint, details.tabId, details.documentUrl || details.initiator || "");
    replayTaskInfo(details.url, details.tabId);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    // 视频资源 ID 请求（/vod/duration/<ID> 等）进入配对队列
    const vm = VIDEO_ID_RE.exec(details.url);
    if (vm) {
      videoIdQ.push({ id: vm[1] || vm[2], t: Date.now() });
      tryPairVideos();
      return;
    }
    // 永中 OW365 PDF 数据端点：f 参数 base64 解码即原始文件名（作为判定线索）
    let hint = "";
    const m = /x1\.ow365\.cn\/pdfv\/f\?f=([^&]+)/.exec(details.url);
    if (m) {
      try {
        let b64 = decodeURIComponent(m[1]).replace(/--$/, "==").replace(/-/g, "+").replace(/_/g, "/");
        const dec = atob(b64);
        hint = dec.split("\\").pop().split("/").pop() || "";
      } catch (e) {}
    }
    addFile(details.url, "", hint, details.tabId, details.documentUrl || details.initiator || "");
  },
  { urls: ["<all_urls>"] }
);

// 记录页面发起请求时的请求头（token / Authorization 等）；无条件记录，下载时再匹配
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (details.requestHeaders && details.requestHeaders.length) {
      reqHeaders.set(details.url, details.requestHeaders);
      const base = details.url.split("?")[0];
      if (base !== details.url) reqHeaders.set(base, details.requestHeaders);
      if (reqHeaders.size > 300) reqHeaders.delete(reqHeaders.keys().next().value);
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders"]
);

// 从 Content-Disposition / Content-Type 推断文件名
function pickName(url, headers) {
  const get = (n) => (headers.find((h) => h.name.toLowerCase() === n) || {}).value || "";
  let cd = get("content-disposition");
  let m = /filename\*?=(?:UTF-8''|")?([^";]+)/i.exec(cd);
  if (m) {
    try { return decodeURIComponent(m[1].replace(/"/g, "")); } catch (e) { return m[1].replace(/"/g, ""); }
  }
  const ct = get("content-type");
  const extMap = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/vnd.ms-powerpoint": ".ppt",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/msword": ".doc",
    "application/zip": ".zip",
  };
  const ext = extMap[ct.split(";")[0].trim()] || "";
  const base = decodeURIComponent(url.split("/").pop().split("?")[0] || "file");
  return ext && !base.toLowerCase().endsWith(ext) ? base + ext : base || "file" + ext;
}

// 调试日志声明已提前到文件前部（见文件开头），此处不再重复声明
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const h = details.responseHeaders || [];
    const get = (n) => (h.find((x) => x.name.toLowerCase() === n) || {}).value || "";
    // 跳过静态资源噪音
    const url = details.url;
    if (/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff2?|ttf|map)(\?|$)/i.test(url)) return;
    const len = parseInt(get("content-length")) || 0;
    debugLog.push({ url, ct: get("content-type"), len, time: Date.now(), status: details.statusCode });
    if (debugLog.length > 300) debugLog = debugLog.slice(-300);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

// 与 popup / content 通信
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getList") {
    sendResponse({ list: captured.slice().reverse() });
  } else if (msg.action === "getDebug") {
    sendResponse({ list: debugLog.slice().reverse() });
  } else if (msg.action === "clearDebug") {
    debugLog = [];
    sendResponse({ ok: true });
  } else if (msg.action === "logEvent") {
    // 各上下文的日志统一在此落盘（避免并发写坏环形缓冲）
    logEvent(msg.lv, msg.tag, msg.msg, sender);
    sendResponse({ ok: true });
  } else if (msg.action === "getLogs") {
    const min = msg.minLevel || (logViewErrorsOnly ? "warn" : "debug");
    sendResponse({
      list: CDLog.minLevelFilter(logs, min).slice().reverse(),
      total: logs.length,
      errorsOnly: logViewErrorsOnly,
    });
  } else if (msg.action === "clearLogs") {
    logs = [];
    persistLogs();
    logEvent("info", "日志", "日志已清空");
    sendResponse({ ok: true });
  } else if (msg.action === "exportLogs") {
    logEvent("info", "日志", "导出日志");
    chrome.downloads.download(
      {
        url: "data:text/plain;charset=utf-8," + encodeURIComponent(CDLog.toText(CDLog.minLevelFilter(logs, "debug"))),
        filename: "cd-logs-" + new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-") + ".txt",
        saveAs: true,
      },
      (id) => sendResponse({ id, err: chrome.runtime.lastError?.message })
    );
    return true;
  } else if (msg.action === "toggleErrorsOnly") {
    logViewErrorsOnly = !!msg.on;
    sendResponse({ ok: true, errorsOnly: logViewErrorsOnly });
  } else if (msg.action === "clear") {
    captured = [];
    save();
    sendResponse({ ok: true });
  } else if (msg.action === "download") {
    try { new URL(msg.url); } catch (e) {
      sendResponse({ err: "URL无效: " + String(msg.url).slice(0, 120) });
      return true;
    }
    chrome.downloads.download({ url: msg.url, saveAs: msg.saveAs !== false }, (id) => {
      const err = chrome.runtime.lastError?.message;
      logEvent(err ? "error" : "info", "下载", (err ? "直链失败: " + err : "直链已开始") + " · " + CDLog.clampText(msg.url, 100));
      sendResponse({ id, err });
    });
    return true;
  } else if (msg.action === "fetchDownload") {
    try { new URL(msg.url); } catch (e) {
      sendResponse({ err: "URL无效: " + String(msg.url).slice(0, 120) });
      return true;
    }
    // 用页面原始请求头（含 token / Referer 防盗链）+ cookie 抓取文件
    const headers = {};
    (reqHeaders.get(msg.url) || reqHeaders.get(msg.url.split("?")[0]) || []).forEach((h) => {
      if (!/^(host|content-length|origin|cookie)$/i.test(h.name)) headers[h.name] = h.value;
    });
    // ow365 端点有防盗链：无记录头时补 Referer
    if (/x1\.ow365\.cn/.test(msg.url) && !headers.Referer) headers.Referer = "https://x1.ow365.cn/";
    fetch(msg.url, { credentials: "include", headers })
      .then(async (r) => {
        if (!r.ok) {
          const t = await r.text().catch(() => "");
          throw new Error("HTTP " + r.status + " " + (new URL(msg.url).host) + " : " + t.slice(0, 180));
        }
        return { blob: await r.blob(), headers: [...r.headers.entries()] };
      })
      .then(async ({ blob, headers: hentries }) => {
        // 魔数校验：PDF=%PDF，Office/ZIP=PK，MP4=ftyp；不匹配则为错误响应
        const head = new Uint8Array(await blob.slice(0, 8).arrayBuffer());
        const sig = Array.from(head).map((b) => String.fromCharCode(b)).join("");
        const magicOk = sig.startsWith("%PDF") || sig.startsWith("PK") || /^.{4}ftyp/.test(sig) || sig.startsWith("\x1f\x8b");
        const ct = (hentries.find(([n, v]) => n.toLowerCase() === "content-type") || [])[1] || "";
        if (!magicOk) {
          const text = await blob.slice(0, 400).text();
          throw new Error(`响应不是有效文件 (${ct || "未知类型"}, ${blob.size}B): ` + text.slice(0, 200));
        }
        const hdrs = hentries.map(([name, value]) => ({ name, value }));
        const name = pickName(msg.url, hdrs) || msg.filename || "file";
        const dataUrl = await new Promise((res, rej) => {
          const fr = new FileReader();
          fr.onload = () => res(fr.result);
          fr.onerror = rej;
          fr.readAsDataURL(blob);
        });
        chrome.downloads.download(
          { url: dataUrl, filename: name, saveAs: msg.saveAs !== false },
          (id) => {
            const err = chrome.runtime.lastError?.message;
            logEvent(err ? "error" : "info", "下载", (err ? "抓取保存失败: " + err : "抓取保存已开始") + " · " + CDLog.clampText(name, 100));
            sendResponse({ id, err });
          }
        );
      })
      .catch((e) => {
        logEvent("error", "下载", "抓取失败: " + CDLog.clampText(String(e.message || e), 200));
        sendResponse({ err: String(e.message || e) });
      });
    return true;
  } else if (msg.action === "downloadData") {
    // 接收页面主世界抓到的 base64 数据并保存
    chrome.downloads.download(
      { url: msg.dataUrl, filename: msg.filename || "file", saveAs: msg.saveAs !== false },
      (id) => {
        const err = chrome.runtime.lastError?.message;
        logEvent(err ? "error" : "info", "下载", (err ? "数据保存失败: " + err : "数据保存已开始") + " · " + CDLog.clampText(msg.filename || "", 100));
        sendResponse({ id, err });
      }
    );
    return true;
  } else if (msg.action === "saveCaptured") {
    // 保存主世界自动捕获的文件（带 dataUrl，可直接保存到磁盘）
    // 主世界只截获 %PDF/PK 魔数内容，这里再确认请求来源属于学习页面
    let learnTab = true;
    try {
      if (captureScoped && sender && sender.tab && sender.tab.url) {
        learnTab = S.isLearningPage(sender.tab.url, [], "", extraHosts);
      }
    } catch (e) {}
    if (!learnTab) {
      reportReject("data:" + (msg.name || ""), "不在课程学习页面上下文");
      sendResponse({ ok: false, reason: "范围外" });
      return true;
    }
    // 去重：同名字节条目已存在则跳过（不再依赖 name+size 严格相等——名字可能先后被映射修正）
    const byteName = String(msg.name || "").trim() || placeholderName("", "bin");
    const already = captured.some((c) => c.dataUrl && normNameKey(c.name) === normNameKey(byteName));
    if (!already) {
      const entry = {
        name: byteName,
        type: guessType(byteName),
        size: msg.size || 0,
        time: Date.now(),
        url: "捕获: " + byteName,
        dataUrl: "data:application/octet-stream;base64," + msg.b64,
      };
      applyName(entry);
      captured.push(entry);
      // 与直链条目做关联合并（占位名借用真名 / 同名合并），避免"数学.pptx + 空名pdf"并存
      captured = dedupeAll(captured);
      save();
      // 字节捕获也要留痕：否则用户在日志里看不到"为什么多了一条"
      logEvent("info", "捕获", "新增 字节 " + entry.type + " · " + CDLog.clampText(entry.name, 100) +
        (msg.size ? " · " + (msg.size / 1048576).toFixed(2) + "MB" : ""));
    } else {
      logEvent("debug", "捕获", "字节重复，已跳过 · " + CDLog.clampText(byteName, 100));
    }
    sendResponse({ ok: true });
  } else if (msg.action === "debugNote") {
    debugLog.push({ url: msg.text, ct: "调试", len: 0, time: Date.now(), status: "MAP" });
    if (debugLog.length > 300) debugLog = debugLog.slice(-300);
    sendResponse({ ok: true });
  } else if (msg.action === "rename") {
    // 手动改名（按捕获时间定位条目）
    const it = captured.find((c) => c.time === msg.time);
    if (it) it.name = msg.name;
    save();
    sendResponse({ ok: true });
  } else if (msg.action === "nameMaps") {
    // 主世界同步的 ID→文件名映射 + 视频转码名映射 + 阿里云 videoId 映射，合并后回溯改名
    mergeNameMap(msg.maps);
    transMaps = Object.assign({}, transMaps, msg.transMaps || {});
    videoIdMaps = mergeVideoMaps(videoIdMaps, msg.videoMaps);
    refreshNames();
    tryPairVideos();
    sendResponse({ ok: true });
  } else if (msg.action === "reportFile") {
    // 由 content script 上报发现的课件链接（可带真实文件名）
    // 上报者已在学习页面上下文，但仍过一次统一规则，保证后台是唯一裁决点
    let tabId = -1;
    let pageUrl = "";
    try {
      tabId = sender && sender.tab ? sender.tab.id : -1;
      // sender.url 是发消息的框架地址（预览 iframe 也准），优先于标签页地址
      pageUrl = (sender && (sender.url || (sender.tab && sender.tab.url))) || "";
    } catch (e) {}
    addFile(msg.url, msg.mime || "", msg.name || "", tabId, pageUrl);
    sendResponse({ ok: true });
  } else if (msg.action === "getScopeStats") {
    sendResponse({ ok: true, captured: captured.length, filtered: debugLog.filter((d) => d.status === "SKIP").length });
  } else if (msg.action === "videoEnded") {
    // 视频常在内嵌 iframe 里播放，结束信号需要广播给同一标签页的所有框架
    // （"完成"按钮和提示通常在顶层页面）
    let tabId = -1;
    try { tabId = sender && sender.tab ? sender.tab.id : -1; } catch (e) {}
    if (tabId >= 0) {
      try { chrome.tabs.sendMessage(tabId, { action: "videoEnded", at: Date.now() }); } catch (e) {}
    }
    logEvent("info", "自动完成", "视频已播放完毕（来自内嵌播放器），等待提交");
    sendResponse({ ok: true, tabId });
  } else if (msg.action === "ping") {
    sendResponse({ ok: true, version: (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || "", logs: logs.length });
  } else {
    // 兜底应答：避免弹窗因"无人应答"而误报"服务未就绪"
    sendResponse({ ok: false, error: "未知指令: " + String(msg.action || msg.type || "") });
  }
});
