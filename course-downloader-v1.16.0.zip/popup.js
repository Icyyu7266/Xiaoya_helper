const listEl = document.getElementById("list");
const errEl = document.getElementById("err");
const progEl = document.getElementById("prog");
const fileCountEl = document.getElementById("fileCount");
const debugDotEl = document.getElementById("debugDot");
const logDotEl = document.getElementById("logDot");

let view = "list"; // "list" | "debug" | "logs"
let batchRunning = false;
let errorsOnly = false;

/* ===================== 视图切换 ===================== */
function setView(next) {
  if (view === next) return;
  view = next;
  document.querySelectorAll("#tabs .tab").forEach((t) => {
    t.classList.toggle("active", t.dataset.view === next);
  });
  // 重新触发进入动画
  listEl.classList.remove("view-anim");
  void listEl.offsetWidth;
  listEl.classList.add("view-anim");
  refresh();
}

document.querySelectorAll("#tabs .tab").forEach((t) => {
  t.onclick = () => setView(t.dataset.view);
});

/* ===================== 下载链 ===================== */
// mode: "single"（弹另存为）| "batch"（直接保存到下载目录）
function downloadOne(it, name, btn, mode, cb) {
  const finish = (r) => {
    if (btn) {
      if (r && r.err) {
        errEl.textContent = "下载失败：" + r.err;
        errEl.hidden = false;
      }
      btn.classList.remove("busy");
      btn.textContent = r && r.err ? "重试" : "下载";
    }
    cb && cb(r || {});
  };
  const saveAs = mode !== "batch";
  // 自动捕获的文件：直接用已存的数据保存
  if (it.dataUrl) {
    return chrome.runtime.sendMessage(
      { action: "downloadData", dataUrl: it.dataUrl, filename: name, saveAs },
      finish
    );
  }
  // HLS(m3u8) 视频：主世界分片下载拼接保存 .ts（长任务）
  if (/\.m3u8(\?|$)/i.test(it.url)) {
    return chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return finish({ err: "未找到活动标签页" });
      chrome.tabs.sendMessage(tab.id, { action: "pageHls", url: it.url, name }, (r) => {
        if (chrome.runtime.lastError) return finish({ err: "页面未就绪，请刷新课程页后重试" });
        if (r && r.err) return finish(r);
        if (r && r.text && mode !== "batch") {
          errEl.textContent = r.text;
          errEl.hidden = false;
        }
        finish({ ok: true, text: r && r.text });
      });
    });
  }
  // ow365 地址：派发给预览 iframe 内的脚本抓取（分区 Cookie 只有 iframe 内部能带上）
  const iframeFetch = (url, cb2) => {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return cb2({ err: "未找到活动标签页" });
      chrome.webNavigation.getAllFrames({ tabId: tab.id }, (frames) => {
        if (!frames || !frames.length) return cb2({ err: "无可用frame" });
        const sorted = frames.slice().sort(
          (a, b) => (/ow365\.cn/.test(b.url) ? 1 : 0) - (/ow365\.cn/.test(a.url) ? 1 : 0)
        );
        const tryOne = (i) => {
          if (i >= sorted.length) return cb2({ err: "所有frame均抓取失败（请先打开一次课件预览再下载）" });
          chrome.tabs.sendMessage(
            tab.id,
            { action: "pageFetch", url },
            { frameId: sorted[i].frameId },
            (r) => {
              if (chrome.runtime.lastError || !r || r.err) return tryOne(i + 1);
              cb2(r);
            }
          );
        };
        tryOne(0);
      });
    });
  };

  // 校验 base64 内容是真实文件（防保存空白/错误页）
  const validMagic = (b64) => {
    try {
      const head = atob(b64.slice(0, 12)).slice(0, 8);
      return head.startsWith("%PDF") || head.startsWith("PK") || head.startsWith("ftyp") || head.startsWith("\x1f\x8b");
    } catch (e) { return false; }
  };

  // 主路径：后台直接抓取（有 host_permissions，不受 CORS 限制）
  chrome.runtime.sendMessage(
    { action: "fetchDownload", url: it.url, filename: name, saveAs },
    (r) => {
      if (r && !r.err) return finish(r);
      const owFail = () =>
        finish({ err: "该文件需要先在页面上打开它的预览（预览后插件会自动捕获完整文件，再点下载即可）" });
      if (/x1\.ow365\.cn/.test(it.url)) {
        iframeFetch(it.url, (r3) => {
          if (r3 && !r3.err && r3.b64 && validMagic(r3.b64)) {
            return chrome.runtime.sendMessage(
              { action: "downloadData", dataUrl: "data:application/octet-stream;base64," + r3.b64, filename: r3.name || name, saveAs },
              finish
            );
          }
          owFail();
        });
        return;
      }
      // 非 ow365：备用浏览器直接下载（公开 CDN 链接）
      chrome.runtime.sendMessage({ action: "download", url: it.url, saveAs }, (r2) => {
        if (r2 && !r2.err) return finish(r2);
        finish({ err: (r && r.err ? r.err : "") + (r2 && r2.err ? "（浏览器下载也未成功: " + r2.err + "）" : "") });
      });
    }
  );
}

/* ===================== 小工具 ===================== */
function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function typeChipClass(type) {
  const t = String(type || "");
  if (t === "PPT") return "chip ppt";
  if (t === "PDF") return "chip pdf";
  if (t === "Word") return "chip word";
  if (t === "Excel") return "chip excel";
  if (t === "视频" || t === "视频HLS") return "chip video";
  return "chip";
}
function iconFor(it) {
  const t = it.type || "";
  if (t === "PDF") return "📕";
  if (t === "PPT") return "📊";
  if (t === "Word") return "📄";
  if (t === "Excel") return "📈";
  if (t === "压缩包") return "🗜️";
  if (t === "视频" || t === "视频HLS") return "🎬";
  return "📄";
}
function iconClass(it) {
  if (it.dataUrl) return "ico data";
  if (it.type === "视频" || it.type === "视频HLS") return "ico video";
  return "ico";
}
function fmtSize(n) {
  const b = Number(n) || 0;
  if (!b) return "";
  if (b < 1024) return b + " B";
  if (b < 1048576) return (b / 1024).toFixed(0) + " KB";
  return (b / 1048576).toFixed(2) + " MB";
}
function timeStr(t) {
  const d = new Date(t || Date.now());
  const p = (n) => String(n).padStart(2, "0");
  return p(d.getHours()) + ":" + p(d.getMinutes());
}
function setProgress(ratio, show) {
  if (!progEl) return;
  progEl.classList.toggle("on", !!show);
  const bar = progEl.firstElementChild;
  if (bar) bar.style.width = Math.max(0, Math.min(1, ratio || 0)) * 100 + "%";
}
function toast(msg) {
  errEl.textContent = msg;
  errEl.hidden = false;
}

/* ===================== 文件视图 ===================== */
function skeleton() {
  listEl.innerHTML =
    '<div class="skel"><i class="a"></i><div class="b"><i style="width:70%"></i><i style="width:40%;margin-top:6px"></i></div></div>' +
    '<div class="skel"><i class="a"></i><div class="b"><i style="width:60%"></i><i style="width:35%;margin-top:6px"></i></div></div>';
}

function render(list) {
  errEl.hidden = true;
  if (fileCountEl) fileCountEl.textContent = String(list.length);

  if (!list.length) {
    listEl.innerHTML =
      '<div class="empty"><span class="big">📭</span>暂未捕获到文件<br />' +
      '在页面上打开某个课件的预览，这里就会出现可下载的文件' +
      '<div class="tips"><span>PPT</span><span>PDF</span><span>Word</span><span>Excel</span><span>视频</span></div></div>';
    return;
  }
  // 已捕获字节的条目排前面（最可靠）
  list = list.slice().sort((a, b) => (b.dataUrl ? 1 : 0) - (a.dataUrl ? 1 : 0));
  const itemMap = {};
  list.forEach((it) => (itemMap[it.time] = it));

  listEl.innerHTML = "";

  // 工具栏
  const bar = document.createElement("div");
  bar.className = "toolbar";
  bar.innerHTML =
    '<label><input type="checkbox" id="selall" /> 全选</label>' +
    '<button id="batchdl" class="btn primary" disabled>下载选中</button>' +
    '<span class="sp"></span>' +
    '<span class="cnt" id="selinfo">' + list.length + ' 个</span>' +
    '<button id="clearList" class="btn ghost">清空</button>';
  listEl.appendChild(bar);
  const selAll = bar.querySelector("#selall");
  const batchBtn = bar.querySelector("#batchdl");
  const selInfo = bar.querySelector("#selinfo");

  const refreshSel = () => {
    const boxes = [...listEl.querySelectorAll(".ck")];
    const n = boxes.filter((b) => b.checked).length;
    const all = boxes.length > 0 && n === boxes.length;
    selAll.checked = all;
    selAll.indeterminate = n > 0 && !all;
    batchBtn.textContent = n ? "下载选中（" + n + "）" : "下载选中";
    batchBtn.disabled = !n || batchRunning;
    selInfo.textContent = n ? n + "/" + list.length + " 个" : list.length + " 个";
  };

  list.forEach((it, idx) => {
    const div = document.createElement("div");
    div.className = "item";
    div.style.animationDelay = Math.min(idx * 38, 380) + "ms";
    const name = it.name || decodeURIComponent(it.url.split("/").pop().split("?")[0] || "file");
    const size = fmtSize(it.size);
    div.innerHTML =
      '<input type="checkbox" class="ck" />' +
      '<div class="' + iconClass(it) + '">' + iconFor(it) + '</div>' +
      '<div class="body">' +
        '<div class="name" title="' + escapeHtml(it.url) + '\n双击可改名">' + escapeHtml(name) + '</div>' +
        '<div class="meta">' +
          (it.dataUrl ? '<span class="chip data">已捕获</span>' : '') +
          '<span class="' + typeChipClass(it.type) + '">' + escapeHtml(it.type || "文件") + '</span>' +
          (size ? '<span class="chip">' + size + '</span>' : '') +
          '<span class="chip">' + timeStr(it.time) + '</span>' +
        '</div>' +
      '</div>' +
      '<button class="dl">下载</button>';

    const nameEl = div.querySelector(".name");
    nameEl.ondblclick = () => {
      const n = prompt("修改文件名：", name);
      if (n && n.trim()) {
        chrome.runtime.sendMessage({ action: "rename", time: it.time, name: n.trim() }, refresh);
      }
    };

    const ck = div.querySelector(".ck");
    ck.dataset.t = it.time;
    ck.onclick = refreshSel;

    div.querySelector(".dl").onclick = () => {
      const btn = div.querySelector(".dl");
      btn.classList.add("busy");
      btn.innerHTML = '<span class="spinner"></span>下载中';
      downloadOne(it, name, btn, "single");
    };
    listEl.appendChild(div);
  });

  selAll.onclick = () => {
    listEl.querySelectorAll(".ck").forEach((b) => (b.checked = selAll.checked));
    refreshSel();
  };
  refreshSel();

  bar.querySelector("#clearList").onclick = () => {
    chrome.runtime.sendMessage({ action: "clear" }, () => {
      setProgress(0, false);
      refresh();
    });
  };

  // 批量下载：顺序执行，直接保存到默认下载目录
  batchBtn.onclick = () => {
    const targets = [...listEl.querySelectorAll(".ck")]
      .filter((b) => b.checked)
      .map((b) => itemMap[b.dataset.t])
      .filter(Boolean);
    if (!targets.length || batchRunning) return;
    batchRunning = true;
    batchBtn.disabled = true;
    selAll.disabled = true;
    errEl.hidden = true;
    setProgress(0, true);
    let i = 0, ok = 0;
    const failed = [];
    const step = () => {
      if (i >= targets.length) {
        batchRunning = false;
        batchBtn.disabled = false;
        selAll.disabled = false;
        setProgress(1, true);
        selInfo.textContent = "完成：" + ok + " 成功" + (failed.length ? "，" + failed.length + " 失败" : "");
        if (failed.length) toast("批量下载失败项：\n" + failed.join("\n"));
        setTimeout(() => setProgress(0, false), 1600);
        refreshSel();
        return;
      }
      const it = targets[i];
      const nm = it.name || decodeURIComponent(it.url.split("/").pop().split("?")[0] || "file");
      selInfo.textContent = "下载中 " + (i + 1) + "/" + targets.length;
      setProgress(i / targets.length, true);
      downloadOne(it, nm, null, "batch", (r) => {
        if (r && r.err) failed.push(nm + "（" + r.err + "）");
        else ok++;
        i++;
        setProgress(i / targets.length, true);
        step();
      });
    };
    step();
  };
}

/* ===================== 调试视图 ===================== */
function renderDebug(rawList) {
  const list = (rawList || []).map((d) => ({
    url: d.url,
    status: String(d.status || ""),
    ct: d.ct || "",
    len: d.len || 0,
    time: d.time,
  }));

  listEl.innerHTML = "";
  const skippedCount = list.filter((x) => x.status === "SKIP").length;
  if (debugDotEl) debugDotEl.classList.toggle("on", skippedCount > 0);

  const bar = document.createElement("div");
  bar.className = "toolbar";
  bar.innerHTML =
    '<span class="cnt">请求 ' + list.length + ' 条 · 已过滤 ' + skippedCount + ' 条</span>' +
    '<span class="sp"></span>' +
    '<button id="clearDbg" class="btn ghost">清空记录</button>';
  listEl.appendChild(bar);
  bar.querySelector("#clearDbg").onclick = () =>
    chrome.runtime.sendMessage({ action: "clearDebug" }, refresh);

  if (!list.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.innerHTML = '<span class="big">🛰️</span>暂无请求记录<br />请先操作页面（刷新 / 打开预览），再回到这里查看';
    listEl.appendChild(empty);
    return;
  }

  list.forEach((it, idx) => {
    const div = document.createElement("div");
    div.className = "dbgitem";
    div.style.animationDelay = Math.min(idx * 22, 320) + "ms";
    const skipped = it.status === "SKIP";
    if (skipped) div.classList.add("skip");
    else if (/^(200|206|304)$/.test(it.status)) div.classList.add("ok");

    let reason = "";
    let statusText = it.status || "—";
    if (skipped && it.ct.indexOf("已过滤:") === 0) {
      reason = it.ct.slice("已过滤:".length).trim();
      statusText = "已过滤";
    }
    const sizeText = it.len ? " · " + (it.len / 1024).toFixed(0) + "KB" : (it.ct && !skipped ? " · " + it.ct : "");

    div.innerHTML =
      '<div class="line1">' +
        '<span class="st">' + escapeHtml(statusText) + '</span>' +
        '<span class="chip">' + timeStr(it.time) + '</span>' +
        (sizeText ? '<span class="chip">' + escapeHtml(sizeText.replace(/^ · /, "")) + '</span>' : '') +
      '</div>' +
      '<div class="raw">' + escapeHtml(it.url) + '</div>' +
      (reason ? '<div class="reason"><span>🚫 ' + escapeHtml(reason) + '</span></div>' : '');
    listEl.appendChild(div);
  });
}

/* ===================== 日志视图 ===================== */
function renderLogs(list, total) {
  listEl.innerHTML = "";
  const errCount = list.filter((e) => e.lv === "error" || e.lv === "warn").length;
  if (logDotEl) logDotEl.classList.toggle("on", errCount > 0);

  const bar = document.createElement("div");
  bar.className = "toolbar";
  bar.innerHTML =
    '<button id="lvAll" class="btn' + (errorsOnly ? "" : " on") + '">全部</button>' +
    '<button id="lvErr" class="btn' + (errorsOnly ? " on" : "") + '">警告/错误</button>' +
    '<span class="sp"></span>' +
    '<span class="cnt">' + list.length + (total != null && total !== list.length ? "/" + total : "") + ' 条</span>' +
    '<button id="expLogs" class="btn">⬇ 导出</button>' +
    '<button id="clrLogs" class="btn ghost">清空</button>';
  listEl.appendChild(bar);

  bar.querySelector("#lvAll").onclick = () => { errorsOnly = false; sendLogsQuery(); };
  bar.querySelector("#lvErr").onclick = () => { errorsOnly = true; sendLogsQuery(); };
  bar.querySelector("#expLogs").onclick = () =>
    chrome.runtime.sendMessage({ action: "exportLogs" }, (r) => {
      if (r && r.err) toast("导出失败：" + r.err);
    });
  bar.querySelector("#clrLogs").onclick = () =>
    chrome.runtime.sendMessage({ action: "clearLogs" }, sendLogsQuery);

  if (!list.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.innerHTML =
      '<span class="big">🗒️</span>' + (errorsOnly ? "没有警告或错误记录" : "暂无日志") +
      '<br />捕获、过滤、下载与 HLS 事件都会记录在这里，便于排查问题';
    listEl.appendChild(empty);
    return;
  }

  list.forEach((e, idx) => {
    const div = document.createElement("div");
    div.className = "logitem " + (e.lv === "error" ? "error" : e.lv === "warn" ? "warn" : "");
    div.style.animationDelay = Math.min(idx * 18, 280) + "ms";
    const isSource = (e.msg || "").indexOf("↳ 来源") === 0;
    const d = new Date(e.t);
    const p = (n) => String(n).padStart(2, "0");
    const hh = p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
    div.innerHTML =
      '<div class="head">' +
        '<span class="lv">' + (isSource ? "└" : escapeHtml(String(e.lv).toUpperCase())) + '</span>' +
        (isSource ? "" : '<span class="tag">' + escapeHtml(e.tag || "") + '</span>') +
        '<span class="t">' + hh + '</span>' +
      '</div>' +
      '<div class="msg' + (isSource ? " src" : "") + '">' + escapeHtml(e.msg || "") + '</div>';
    listEl.appendChild(div);
  });
}

/* ===================== 日志读取（带存储兜底） ===================== */
const LV_RANK = { debug: 10, info: 20, warn: 30, error: 40 };

// 本地兜底：直接从 storage 读环形日志（后台消息失败时也能看到日志）
function readLogsFromStorage(cb) {
  try {
    chrome.storage.local.get({ eventLogs: [] }, (d) => {
      const all = ((d && d.eventLogs) || []).filter(
        (e) => e && typeof e.t === "number" && e.msg && LV_RANK[e.lv]
      );
      const min = LV_RANK[errorsOnly ? "warn" : "debug"];
      const filtered = all.filter((e) => (LV_RANK[e.lv] || 0) >= min).slice(-600);
      cb(filtered.slice().reverse(), all.length);
    });
  } catch (e) {
    cb([], 0);
  }
}

function sendLogsQuery() {
  chrome.runtime.sendMessage({ action: "getLogs", minLevel: errorsOnly ? "warn" : "debug" }, (r) => {
    const failed = !!chrome.runtime.lastError || !r || !Array.isArray(r.list);
    if (!failed) {
      renderLogs(r.list, r.total);
      return;
    }
    // 后台没响应（Service Worker 休眠/更新中）→ 直读本机存储，保证日志始终可见
    readLogsFromStorage((list, total) => {
      if (!list.length && !total) {
        listEl.innerHTML =
          '<div class="empty"><span class="big">🗒️</span>暂无日志<br />捕获、过滤、下载与 HLS 事件都会记录在这里';
        return;
      }
      renderLogs(list, total);
    });
  });
}

/* ===================== 刷新入口 ===================== */
function refresh() {
  if (view === "logs") return sendLogsQuery();
  if (view === "debug") {
    return chrome.runtime.sendMessage({ action: "getDebug" }, (r) => {
      renderDebug(r ? r.list : []);
    });
  }
  chrome.runtime.sendMessage({ action: "getList" }, (r) => render(r ? r.list : []));
}

/* ===================== 启动 ===================== */
try {
  const m = chrome.runtime.getManifest();
  const v = document.getElementById("ver");
  if (m && m.version && v) v.textContent = "v" + m.version;
} catch (e) {}

document.getElementById("opts").onclick = () => chrome.runtime.openOptionsPage();

// 首次加载先给骨架屏，避免"空白一闪"
skeleton();
listEl.classList.add("view-anim");
refresh();
// 后台计数（即使用户停在调试/日志页，也把文件数显示出来）
chrome.runtime.sendMessage({ action: "getList" }, (r) => {
  if (fileCountEl && r && r.list) fileCountEl.textContent = String(r.list.length);
});